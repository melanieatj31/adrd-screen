from pathlib import Path
from collections import Counter
import csv,json,hashlib,datetime,zipfile,openpyxl,re
P=Path('/workspace/adrd-rebuilt-v2');I=P/'inputs';R=P/'reviewer';O=P/'original_sources'
S=json.load(open(R/'synthetic_records.json'));D=json.load(open(R/'BUILD_MANIFEST.json'));C=json.load(open(R/'scheduling_constraints.json'))
CHECKS=[]
def check(label,yes,detail=''):
 CHECKS.append({'check':label,'result':'PASS' if yes else 'FAIL','detail':detail})
 if not yes:print('FAIL',label,detail)
def recordrows(ws):
 values=list(ws.values);h=values[0];return [dict(zip(h,r)) for r in values[1:]]
def dt(x):
 if isinstance(x,datetime.datetime):return x.date()
 return datetime.date.fromisoformat(x[:10])
def writecsv(path,rows):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
F=list(csv.DictReader(open(R/'SOURCE_FILES.csv',encoding='utf-8-sig')))
B={f.name:openpyxl.load_workbook(f,data_only=True) for f in I.glob('*.xlsx')}
for r in F:
 original=Path(r['supplied_path']);copy=O/r['supplied_filename']
 check(r['supplied_filename']+' original archived byte-identically',hashlib.sha256(original.read_bytes()).hexdigest()==r['SHA256']==hashlib.sha256(copy.read_bytes()).hexdigest())
 if original.suffix=='.xlsx':
  w=openpyxl.load_workbook(original,data_only=True);out=B[r['output_filename']];diff=[]
  for ws in w:
   check(r['output_filename']+' preserves '+ws.title+' headings',[c.value for c in out[ws.title][1]][:ws.max_column]==[c.value for c in ws[1]])
   for row in ws:
    for cell in row:
     if cell.value!=out[ws.title][cell.coordinate].value:diff.append(ws.title+'!'+cell.coordinate)
  check(r['output_filename']+' all original cell values preserved',not diff,str(diff[:5]))
 else:check(r['output_filename']+' expanded manual matches latest source',hashlib.sha256((I/r['output_filename']).read_bytes()).hexdigest()==r['SHA256'])
# Check original formula definitions as well as the values cached for display.
formula_count=0
for r in F:
 if not r['output_filename'].endswith('.xlsx'):continue
 original=openpyxl.load_workbook(r['supplied_path'],data_only=False)
 output=openpyxl.load_workbook(I/r['output_filename'],data_only=False)
 changed=[]
 for ws in original:
  for row in ws:
   for cell in row:
    if cell.data_type=='f':
     formula_count+=1
     if output[ws.title][cell.coordinate].value!=cell.value:changed.append(ws.title+'!'+cell.coordinate)
 check(r['output_filename']+' source formulas retained',not changed,str(changed[:5]))
check('All381 original formulas retained with cached values',formula_count==381,str(formula_count))
# Lyle deliberately retains both source dates; this is a conflict to resolve, not an edit.
r=list(B['applicant_demographics.xlsx']['applicant_demographics'].values)[1]
check('Lyle application preserved at row2',r[0]=='mc-0022' and r[2]=='lyle preston' and dt(r[3])==datetime.date(1963,6,12))
r=list(B['ADRD_Call_Log.xlsx']['call_log'].values)[23]
check('Lyle call preserved at row24 with conflicting1971DOB',r[1]=='lyle preston' and '1971-06-12' in r[3])
MC=recordrows(B['applicant_demographics.xlsx']['applicant_demographics']);mcids=[r['applicant_id'] for r in MC if r['applicant_id']]
check('Expanded MC count250 and no duplicated IDs',len(mcids)==len(set(mcids))==250)
prior=[]
for f,w in B.items():
 if f.startswith('ADRD_Study_'):prior += [r for r in recordrows(w['applicants']) if r.get('applicant_id') and r.get('name')]
check('Expanded prior-list count99 and no duplicated IDs',len(prior)==len({r['applicant_id'] for r in prior})==99)
check('No MC/prior ID overlap; total349',not(set(mcids)&{r['applicant_id'] for r in prior}) and len(prior)+len(mcids)==349)
for f in ['mindcrowd_assessment_other.xlsx','past_medical_and_surgical_history.xlsx']:
 for ws in B[f]:
  ids=[r['applicant_id'] for r in recordrows(ws) if r['applicant_id']]
  expected=set(mcids)-({'mc-0063'} if ws.title=='medications' else set())
  check(f+'!'+ws.title+' exact expected applicant coverage',set(ids)==expected)
  if ws.title in ['mindcrowd_assessment','other_questions','eye_clearance','metal_clearance']:check(ws.title+' has one row per applicant',len(ids)==len(set(ids)))
check('Added IDs exactly121..270 plus1001..1050',set(p['id'] for p in S)=={f'mc-{i:04}' for i in range(121,271)}|{f'mc{i:04}' for i in range(1001,1051)})
check('Added names and DOBs individually unique',len({p['name'] for p in S})==len({p['dob'] for p in S})==200)
check('Most added MC eligible',sum(p['expected']=='Eligibility' for p in S if p['group']=='mc')==104)
check('Most added prior eligibility rows remain eligible after calls',sum(p['expected']=='Eligibility' for p in S if p['group']=='prior' and p['baseline']=='Eligibility')==32)
# New prior scenarios must not recreate current-MC-only challenges; originals remain authoritative.
bad=[]
for f,w in B.items():
 if not f.startswith('ADRD_'):continue
 for ws in w:
  for r in recordrows(ws):
   id=r.get('applicant_id')
   if id and str(id).startswith('mc10'):
    for v in r.values():
     if isinstance(v,str) and re.search(r'jaw[ -]?wire|\bk[ -]?wire\b|\biud\b|mirena|spanish.only',v,re.I):bad.append((f,ws.title,id,v))
check('No restricted duplicate challenges in added prior rows/calls',not bad,str(bad[:3]))
start=datetime.date(2027,1,1);end=datetime.date(2027,10,30)
def age(b,t):return t.year-b.year-((t.month,t.day)<(b.month,b.day))
for p in S:
 if p['expected']=='Eligibility':
  assert age(dt(p['dob']),start)<=85 and age(dt(p['dob']),end)>=60 and p['score']>22 and p['completion']=='completed'
 if p['expected']=='Wait':
  assert start<=dt(p['recontact'])<=end
  if 'age 59' in p['challenge']:assert dt(p['dob']).replace(year=2027)==dt(p['recontact'])
check('Eligible root criteria and32 true in-recruitment wait cases',sum(p['expected']=='Wait' for p in S)==32)
# Validate feasibility for new ready-in-phase cases; do not claim the whole349-person queue is booked.
by={p['id']:p for p in S};finite={};holds=[]
for id,c in C.items():
 if by[id]['expected'] not in ['Eligibility','Wait']:continue
 if c['type']=='after_phase':holds.append(id);continue
 dates=sorted(set(c['preferred_dates']+c['alternate_dates'])-set(c['blocked_dates']))
 for x in dates:assert dt(x).weekday() in [0,1,2,5] and datetime.date(2027,10,31)<=dt(x)<=datetime.date(2028,11,1)
 finite[id]=dates
matched={}
def fit(id,seen):
 for ds in finite[id]:
  for n in range(1 if dt(ds).weekday()==5 else 3):
   slot=(ds,n)
   if slot in seen:continue
   seen.add(slot)
   if slot not in matched or fit(matched[slot],seen):matched[slot]=id;return True
 return False
unmatched=[id for id in sorted(finite,key=lambda x:len(finite[x])) if not fit(id,set())]
check('Feasibility of all152 new in-phase ready cases under revised NIS caps',not unmatched,f'{len(finite)-len(unmatched)}/{len(finite)}; unmatched {unmatched}')
check('16 eligible additions have availability beyond first phase',len(holds)==16)
example=[{'applicant_id':id,'example_MRI_date':ds,'day_limit':1 if dt(ds).weekday()==5 else 3,'status':'REVIEWER EXAMPLE FOR ADDITIONS ONLY; NOT BOOKED; final times8AM-3PM must be confirmed'} for (ds,n),id in sorted(matched.items())]
check('Scheduling example one slot per person',len(example)==len({x['applicant_id'] for x in example}))
count=Counter(x['example_MRI_date'] for x in example)
check('Scheduling example no Friday/Thursday and Saturday max1',all(dt(d).weekday() in [0,1,2,5] and n<=(1 if dt(d).weekday()==5 else 3) for d,n in count.items()))
writecsv(R/'SCHEDULING_FEASIBILITY_EXAMPLE.csv',example);writecsv(R/'VALIDATION_REPORT.csv',CHECKS)
print('Validation results',Counter(c['result'] for c in CHECKS))
assert all(c['result']=='PASS' for c in CHECKS)
# Reviewer workbook separates the answer key from exercise inputs.
w=openpyxl.Workbook();w.remove(w.active)
for title,path in [('Added applicants','ADDED_APPLICANTS_REVIEW.csv'),('Source issues','SOURCE_REVIEW_ISSUES.csv'),('Source files','SOURCE_FILES.csv'),('Added calls','ADDED_CALLS_REVIEW.csv'),('Validation','VALIDATION_REPORT.csv'),('Feasible dates','SCHEDULING_FEASIBILITY_EXAMPLE.csv')]:
 s=w.create_sheet(title)
 for row in csv.reader(open(R/path,encoding='utf-8-sig')):s.append(row)
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 from openpyxl.styles import Font,PatternFill,Alignment
 for c in s[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
 for col in s.columns:
  s.column_dimensions[col[0].column_letter].width=40
  for c in col:c.alignment=Alignment(wrap_text=True,vertical='top')
w.save(R/'ADDITION_REVIEW_V2.xlsx')
print('Review workbook saved. Expected dispositions of additions:',dict(Counter(p['expected'] for p in S)))
