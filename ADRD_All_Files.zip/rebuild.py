from pathlib import Path
from copy import deepcopy
from collections import Counter,defaultdict
import openpyxl,csv,json,datetime,hashlib,re,zipfile,shutil,random
from openpyxl.styles import Font,PatternFill,Alignment
P=Path('/workspace/adrd-rebuilt-v2');I=P/'inputs';O=P/'original_sources';R=P/'reviewer'
for x in [I,O,R]:x.mkdir(exist_ok=True)
ROOT=Path('/workspace/attachments')
SOURCES={
 'ADRD_Study_Wait_List.xlsx':ROOT/'0827b623-08d8-49f4-9052-acd294846f83/ADRD_Study_Wait_List.xlsx',
 'ADRD_Call_Log.xlsx':ROOT/'f7540b60-9b1f-4d7d-be53-66a76a00d8d8/ADRD_Call_Log not this onw.xlsx',
 'ADRD_Study_Eligibility_List.xlsx':ROOT/'3baf801c-2ec2-4f94-8726-97c5e007d3b0/ADRD_Study_Eligibility_List.xlsx',
 'mindcrowd_assessment_other.xlsx':ROOT/'477255a6-da29-4e23-9b94-050978d9b9fa/mindcrowd_assessment_other.xlsx',
 'ADRD_Study_Followup_List.xlsx':ROOT/'c0969530-02a1-4658-8b3d-25439448d7de/ADRD_Study_Followup_List.xlsx',
 'past_medical_and_surgical_history.xlsx':ROOT/'3558e0e3-6acd-4889-9309-07654f51228e/past_medical_and_surgical_history.xlsx',
 'applicant_demographics.xlsx':ROOT/'9ef73900-1b20-491a-945b-bd71fe169429/applicant_demographics.xlsx',
 'ADRD_Study_Ineligibility_List.xlsx':ROOT/'6cf1326e-dd01-4e59-adaa-913086141bcf/ADRD_Study_Ineligibility_List.xlsx',
 'NIS_MRI_Screening_Manual.pdf':ROOT/'ca2d70a1-a00d-4a30-afe8-f9e7e5c83096/NIS_MRI_Screening_Manual.pdf',
 'ADRD_Study_Information_Sheet_and_Screening_Manual.pdf':ROOT/'a81cd560-67cb-410c-a8b7-98922e185f54/ADRD_Study_Information_Sheet_and_Screening_Manual.pdf'}
manifest=[]
for out,p in SOURCES.items():
 shutil.copy2(p,O/p.name)
 manifest.append({'output_filename':out,'supplied_filename':p.name,'supplied_path':str(p),'SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'note':'Canonical output filename only; original preserved verbatim' if out!=p.name else 'Original preserved verbatim'})
BOOKS={k:openpyxl.load_workbook(v,data_only=False) for k,v in SOURCES.items() if k.endswith('.xlsx')}
def headers(ws):return [c.value for c in ws[1]]
def rows(ws):
 h=headers(ws);return [dict(zip(h,[c.value for c in row])) for row in list(ws)[1:]]
def extend(ws,fields):
 h=headers(ws)
 for f in fields:
  if f not in h:ws.cell(1,len(h)+1,f);h.append(f)
 return h

def dt(x):
 if isinstance(x,datetime.datetime):return x.date()
 if isinstance(x,datetime.date):return x
 return datetime.date.fromisoformat(str(x)[:10])
def excel(x):
 if isinstance(x,datetime.datetime):return x
 if isinstance(x,datetime.date):return datetime.datetime.combine(x,datetime.time())
 if isinstance(x,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',x):return datetime.datetime.combine(dt(x),datetime.time())
 return x

def add(ws,r):ws.append([excel(r.get(f,'n/a')) for f in headers(ws)]);return ws.max_row

def csvout(path,data):
 if not data:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
source_ids=set();source_names=set();source_dobs=set();source_counts={}
for f,w in BOOKS.items():
 if f=='applicant_demographics.xlsx' or f.startswith('ADRD_Study_'):
  ws=w.active;valid=[r for r in rows(ws) if r.get('applicant_id') and r.get('name')]
  source_counts[f]=len(valid)
  for r in valid:
   assert r['applicant_id'] not in source_ids
   source_ids.add(r['applicant_id']);source_names.add(r['name'].strip().lower());source_dobs.add(dt(r['dob']).isoformat())
assert len(source_ids)==149
# Retain only the clearly identified synthetic additions from the previous generation, never its old source rows.
S=deepcopy(json.load(open('/workspace/synthetic-expanded/reviewer/synthetic_records.json')))
IDMAP={p['id']:f"mc-{121+p['j']:04d}" for p in S if p['group']=='mc'}
oldids={p['id']:p['id'] for p in S}
for p in S:
 p['old_id']=p['id'];p['id']=IDMAP.get(p['id'],p['id'])
 for k in ['demo_row','prior_row','prior_file']:p.pop(k,None)
 assert p['id'] not in source_ids
 assert p['name'].strip().lower() not in source_names
# Only added identities may be adjusted to avoid a duplicated birthdate in the new authoritative source.
all_dates=set(source_dobs);DOBEDITS=[]
for p in S:
 original=p['dob'];b=dt(original)
 while b.isoformat() in all_dates:b-=datetime.timedelta(days=1)
 if b.isoformat()!=original:DOBEDITS.append({'applicant_id':p['id'],'old_synthetic_DOB':original,'new_synthetic_DOB':b.isoformat(),'reason':'Avoid duplicate date with authoritative source; original source never changed'})
 p['dob']=b.isoformat();all_dates.add(p['dob'])
# Build source availability extensions additively without filling or rewriting original cells.
extend(BOOKS['mindcrowd_assessment_other.xlsx']['other_questions'],['mri_availability_notes'])
for f,w in BOOKS.items():
 if f.startswith('ADRD_Study_'):
  extend(w['applicants'],['diagnoses','diagnosis_date','medications','medication_duration','medication_start_date','mri_availability_notes','mri_tentative_date'])
  for title,h in [('diagnoses',['applicant_id','diagnoses','diagnosis_date']),('medications',['applicant_id','medications','medication_start_date','medication_duration_years']),('surgery_history',['applicant_id','past_surgical_history','conditional_past_surgical_history_date','scheduled_surgery','conditional_scheduled_surgical_date'])]:
   assert title not in w.sheetnames;w.create_sheet(title).append(h)
# Revised policy: research Monday-Thursday, Saturday exception1; ADRD staffing Monday-Wednesday,Friday,Saturday.
# Intersection: Monday,Tuesday,Wednesday,Saturday with Saturday capacity1. Hours8AM-3PM; durations not invented.
starts=['2027-11-01','2027-11-15','2027-12-06','2028-01-10','2028-02-07','2028-03-06','2028-04-03','2028-05-08']
CONSTRAINTS={}
for p in S:
 j=p['j'];id=p['id']
 if p['baseline'] not in ['Eligibility','Wait']:p['availability']='n/a';continue
 if (p['group']=='mc' and 92<=j<104) or (p['group']=='prior' and j in [28,29,30,31]):
  begin=datetime.date(2028,11,3)+datetime.timedelta(days=(j*3)%30)
  note=f'I will be away caring for a relative until {begin.isoformat()}. Please contact me after I get back; I cannot come earlier.'
  CONSTRAINTS[id]={'type':'after_phase','preferred_dates':[],'alternate_dates':[],'blocked_dates':[],'available_from':begin.isoformat(),'note':note};p['availability']=note;continue
 start=dt(starts[j%8]);days=[start+datetime.timedelta(days=k) for k in range(29) if (start+datetime.timedelta(days=k)).weekday() in [0,1,2,5]]
 first=days[:2] if j%5 else [days[1]];alts=days[2:14]
 alt=sorted(set([alts[j%len(alts)],alts[(j+3)%len(alts)],alts[(j+5)%len(alts)],alts[(j+8)%len(alts)]]))
 transport=['my daughter drives me','I need to change a work shift','I need to arrange my caregiver','my son has to take time off','I use the community ride service'][j%5]
 p['availability']=f"My first choices are {' or '.join(d.isoformat() for d in first)}. If those are full, I could do {', '.join(d.isoformat() for d in alt)}; {transport}."
 CONSTRAINTS[id]={'type':'finite_dates','preferred_dates':[d.isoformat() for d in first],'alternate_dates':[d.isoformat() for d in alt],'blocked_dates':[],'note':p['availability']}
p=next(p for p in S if p['id']=='mc1034')
p['availability']='I can come2027-11-01,2027-11-02,2027-11-03,2027-11-06 or2027-11-08. Please call to confirm.'
CONSTRAINTS[p['id']]={'type':'finite_dates','preferred_dates':['2027-11-03'],'alternate_dates':['2027-11-01','2027-11-02','2027-11-06','2027-11-08'],'blocked_dates':['2027-11-03','2028-11-03'],'dob_in_list':p['dob'],'dob_in_call':'1962-11-03','note':p['availability']}
# New raw answers are natural; no safety conclusions are inserted into patient text.
newmc=[p for p in S if p['group']=='mc'];random.Random(349).shuffle(newmc)
for p in newmc:
 id=p['id']
 p['source_row']=add(BOOKS['applicant_demographics.xlsx']['applicant_demographics'],{'applicant_id':id,'screening_date_yyyy_mm_dd':p['screening'],'name':p['name'],'dob':p['dob'],'sex':p['sex'],'living_place':p['living'],'language':p['language'],'race_ethnicity':p['race'],'mri_availability_notes':p['availability']})
 add(BOOKS['mindcrowd_assessment_other.xlsx']['mindcrowd_assessment'],{'applicant_id':id,'assessment_date':p['assessment'],'mc_score':p['score'],'completion_status':p['completion']})
 add(BOOKS['mindcrowd_assessment_other.xlsx']['other_questions'],{'applicant_id':id,'ad_diagnosis':p['ad'],'mri_ability':p['mri'],'mri_availability_notes':p['availability']})
 add(BOOKS['mindcrowd_assessment_other.xlsx']['eye_clearance'],{'applicant_id':id,'eye_injury':p['eye'],'conditional_eye_injury_agent':p['eye_agent']})
 add(BOOKS['past_medical_and_surgical_history.xlsx']['metal_clearance'],{'applicant_id':id,'metal_in_body':p['metal'],'metal_in_eye':p['metal_eye'],'conditional_explain_metal_in_body':p['metal_text'],'conditional_explain_metal_in_body_date':p['metal_date'],'conditional_metal_in_eye_removed':p['removed']})
 for key,sheet in [('hist','medical_history'),('med','medications'),('surg','surgery_clearance')]:
  for r in p[key]:
   data={'applicant_id':id,**r}
   if key=='med':data['screening_date_yyyy_mm_dd']=p['screening']
   add(BOOKS['past_medical_and_surgical_history.xlsx'][sheet],data)
# Prior additions use original supplied headings, with complete supporting sheets for their own histories.
for p in [p for p in S if p['group']=='prior']:
 f=f"ADRD_Study_{p['baseline']}_List.xlsx";w=BOOKS[f];id=p['id']
 priornotes='n/a'
 if p['baseline']=='Wait':priornotes='recontact '+p['recontact']+'; turns60 then' if 'age 59' in p['challenge'] else 'recontact '+p['recontact']+' after the frame removal appointment'
 elif p['baseline']=='Followup':priornotes={'mc1045':'clarify medication indication','mc1046':'original ICD implantation date not supplied','mc1047':'assessment result is an error','mc1048':'clarify previous neck operation'}[id]
 elif p['baseline']=='Ineligibility':priornotes='pacemaker excludes MRI at NIS' if id=='mc1049' else 'currently lives outside Florida'
 data={'applicant_id':id,'name':p['name'],'dob':p['dob'],'sex':p['sex'],'race_ethnicity':p['race'],'living_place':p['living'],'language':p['language'],'screening_date':p['screening'],'ad_diagnosis':p['ad'],'metal_in_body':p['metal'],'eye_injury':p['eye'],'metal_in_eye':p['metal_eye'],'conditional_explain_metal_in_body':p['metal_text'],'conditional_explain_metal_in_body_date':p['metal_date'],'conditional_eye_injury_agent':p['eye_agent'],'conditional_metal_in_eye_removed':p['removed'],'mri_ability':p['mri'],'dose':'n/a','diagnoses':'see diagnoses sheet','diagnosis_date':'see diagnoses sheet','medications':'see medications sheet','medication_duration':'see medications sheet','medication_start_date':'see medications sheet','past_surgical_history':'see surgery_history sheet','conditional_past_surgical_history_date':'see surgery_history sheet','assessment_date':p['assessment'],'mc_score':p['score'],'completion_status':p['completion'],'scheduled_surgery':'see surgery_history sheet','conditional_surgery_date':'see surgery_history sheet','initial_screening_notes':priornotes,'mri_availability_notes':p['availability'],'mri_tentative_date':p['tentative']}
 p['source_file']=f;p['source_row']=add(w['applicants'],data)
 for key,sheet in [('hist','diagnoses'),('med','medications'),('surg','surgery_history')]:
  for r in p[key]:add(w[sheet],{'applicant_id':id,**r})
# Reuse only the added calls, not any calls from the earlier wrong source set.
oldcalls=list(csv.DictReader(open('/workspace/synthetic-expanded/reviewer/ADDED_CALLS_REVIEW.csv',encoding='utf-8-sig')))
newcalls=[]
for r in oldcalls:
 r={k:v for k,v in r.items() if k!='source_row'}
 # Scheduling additions are refreshed from the new NIS-compatible availability notes.
 if r['what_was_discussed'].startswith('Scheduling query only:'):
  p=next(p for p in S if p['id']==r['applicant_id']);r['what_was_discussed']='Scheduling query only: '+p['availability']+' No appointment was booked.'
 r['source_row']=add(BOOKS['ADRD_Call_Log.xlsx']['call_log'],r);newcalls.append(r)
# Formatting only; original source values remain exactly as supplied, including blanks, case and spelling.
for f,w in BOOKS.items():
 for ws in w:
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D');c.alignment=Alignment(wrap_text=True,vertical='top')
  for col in ws.columns:
   h=str(col[0].value or '');ws.column_dimensions[col[0].column_letter].width=55 if any(k in h for k in ['notes','history','discussed','explain']) else 22
   for c in col[1:]:
    c.alignment=Alignment(wrap_text=True,vertical='top')
    if isinstance(c.value,(datetime.datetime,datetime.date)):c.number_format='yyyy-mm-dd'
  for t in ws.tables.values():t.ref=ws.dimensions
 w.save(I/f)
# Restore cached values for unchanged source formulas after openpyxl writes formula definitions.
from formula_cache import restore_formula_cache
for f,source in SOURCES.items():
 if f.endswith('.xlsx'):restore_formula_cache(source,I/f)
for f,p in SOURCES.items():
 if f.endswith('.pdf'):shutil.copy2(p,I/f)
# Reviewer-only source issues, kept out of patient answers.
issues=[
 {'applicant_id':'mc-0022','name':'lyle preston','issue':'DOB and identity discrepancy','evidence':'Demographics row2 DOB1963-06-12; call row24 same name, no linked ID, reports DOB1971-06-12 and age55.','required_action':'Confirm caller/application identity and full DOB before age determination. Do not silently choose either date.','provisional_disposition':'Followup if the call is linked to this applicant; relationship must be verified'},
 {'applicant_id':'MC-00H','name':'marcus hill','issue':'Call references prior applicant absent from current source lists','evidence':'Call row3 identifies a pacemaker; no applicant row in supplied current MC or four prior lists.','required_action':'Preserve call and request missing applicant record. Do not invent demographics or import an older person by fuzzy ID.','provisional_disposition':'Unmatched call; confirmed pacemaker would exclude the corresponding applicant once identified'},
 {'applicant_id':'MC-00D','name':'henry brown','issue':'Call references prior applicant absent from current source lists','evidence':'Call row5 includes caller and separately Elaine Brown own statements. Caller is not in current source applications.','required_action':'Preserve full call; obtain missing applicant record. Cross-reference Elaine Brown by confirmed identity for her own history disclosures.','provisional_disposition':'Unmatched caller; Elaine history clarification remains relevant'},
 {'applicant_id':'MC-00N','name':'elaine brown','issue':'Additional history in sibling call','evidence':'Call row5 records her own unspecified dementia and omitted diabetes/metformin history.','required_action':'Clarify dementia subtype and reconcile full medical/medication history; do not equate all dementia with Alzheimer disease.','provisional_disposition':'Followup concern; original list placement preserved in raw exercise'},
 {'applicant_id':'unassigned','name':'','issue':'Orphan medication text','evidence':'Original eligibility applicants!AA26 contains atorvostatin with no ID/name.','required_action':'Preserve original cell, flag as unassigned and do not count as applicant or attach to new row.','provisional_disposition':'Unassigned source entry'},
 {'applicant_id':'mc-0063','name':'','issue':'No medication rows in supplied MC source','evidence':'Current medical workbook has no medication rows for mc-0063.','required_action':'Preserve missingness; do not invent a negative medication history.','provisional_disposition':'History clarification needed if otherwise eligible'}]
additions=[]
for p in S:
 calls=[str(c['source_row']) for c in newcalls if c['applicant_id']==p['id']]
 additions.append({'applicant_id':p['id'],'old_synthetic_id':p['old_id'],'name':p['name'],'batch':'current MC' if p['group']=='mc' else 'previous MC','initial_location':'MC export' if p['group']=='mc' else p['baseline'],'expected_after_review':p['expected'],'challenge':p['challenge'],'reason_and_next_steps':p['reason'],'DOB':p['dob'],'recontact_date':p['recontact'],'file':'applicant_demographics.xlsx' if p['group']=='mc' else p['source_file'],'sheet':'applicant_demographics' if p['group']=='mc' else 'applicants','row':p['source_row'],'added_call_rows':'; '.join(calls),'mri_availability_notes':p['availability']})
csvout(R/'ADDED_APPLICANTS_REVIEW.csv',additions);csvout(R/'SOURCE_REVIEW_ISSUES.csv',issues);csvout(R/'SOURCE_FILES.csv',manifest);csvout(R/'SYNTHETIC_DOB_ADJUSTMENTS.csv',DOBEDITS);csvout(R/'ADDED_CALLS_REVIEW.csv',newcalls)
json.dump(S,open(R/'synthetic_records.json','w'),indent=2,default=str);json.dump(CONSTRAINTS,open(R/'scheduling_constraints.json','w'),indent=2)
json.dump({'counts':source_counts,'original_source_total':149,'added_total':200,'expanded_total':349,'old_to_new_synthetic_IDs':IDMAP},open(R/'BUILD_MANIFEST.json','w'),indent=2)
print('Sources',source_counts,'total',len(source_ids))
print('Expanded',149+len(S),'Lyle preserved row2/call24; addition IDs',min(IDMAP.values()),'through',max(IDMAP.values()))
print('New DOB adjustments',len(DOBEDITS),'newcallrows',len(newcalls))
