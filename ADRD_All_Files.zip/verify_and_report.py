from pathlib import Path
from collections import Counter,defaultdict
import openpyxl,csv,json,datetime,hashlib,zipfile,re,shutil
from openpyxl.styles import Font,PatternFill,Alignment
P=Path('/workspace/adrd-complete-v3');I=P/'inputs';R=P/'reviewer';O=P/'original_sources'
manifest=list(csv.DictReader(open(R/'SOURCE_FILES.csv',encoding='utf-8-sig')))
CHECKS=[];ADDED_CHECKS=[]
def check(name,result,detail=''):
 CHECKS.append({'check':name,'result':'PASS' if result else 'FAIL','details':detail})
 if not result:print('FAIL',name,detail)
def head(ws):return [c.value for c in ws[1]]
def rows(ws):
 h=head(ws);return [(n,dict(zip(h,r))) for n,r in enumerate(list(ws.values)[1:],2)]
def norm(x):
 if isinstance(x,(datetime.datetime,datetime.date)):return x.strftime('%Y-%m-%d')
 if x is None:return ''
 return str(x).strip()
def atom(x):
 if isinstance(x,(datetime.datetime,datetime.date)):return ('date',x.strftime('%Y-%m-%d'))
 if isinstance(x,(int,float)):return ('number',float(x))
 return ('value',x)
def rowtuple(r,h):return tuple(atom(r.get(k)) for k in h)
def isref(x):return isinstance(x,str) and re.match(r'^see\b.*\bsheet\b',x,re.I)
def readcsv(p):return list(csv.DictReader(open(p,encoding='utf-8-sig')))
def writecsv(path,rs):
 if not rs:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
B={f.name:openpyxl.load_workbook(f,data_only=False) for f in I.glob('*.xlsx')}
all_ids=[];all_persons=[];alias_lookup={};original_count=0;newcounts={}
for m in manifest:
 f=m['filename'];src=Path(m['source_path'])
 check(f+' original archive exact',hashlib.sha256(src.read_bytes()).hexdigest()==m['SHA256']==hashlib.sha256((O/f).read_bytes()).hexdigest())
 if f not in B:
  check(f+' manual unchanged',hashlib.sha256((I/f).read_bytes()).hexdigest()==m['SHA256']);continue
 with zipfile.ZipFile(I/f) as z:check(f+' workbook archive valid',z.testzip() is None)
 if not f.startswith('ADRD_Study_'):
  check(f+' unchanged byte-for-byte',hashlib.sha256((I/f).read_bytes()).hexdigest()==m['SHA256'])
  if f=='applicant_demographics.xlsx':
   for n,r in rows(B[f].active):
    if r.get('applicant_id'):
     all_ids.append(r['applicant_id']);all_persons.append((norm(r['name']).lower(),norm(r['dob'])))
  continue
 w=B[f];srcw=openpyxl.load_workbook(src,data_only=False);apps=[(n,r) for n,r in rows(w['applicants']) if r.get('applicant_id') and r.get('name')]
 sourceapps=[(n,r) for n,r in rows(srcw['applicants']) if r.get('applicant_id') and r.get('name')]
 original_count+=len(sourceapps);newcounts[f]=len(apps)
 check(f+' original applicant headings retained',head(w['applicants'])==head(srcw['applicants']))
 diffs=[]
 for row in srcw['applicants']:
  for cell in row:
   if cell.value!=w['applicants'][cell.coordinate].value:diffs.append(cell.coordinate)
 check(f+' every original applicant cell retained',not diffs,str(diffs[:5]))
 ids=[r['applicant_id'] for n,r in apps]
 check(f+' no duplicate applicant IDs',len(ids)==len(set(ids)))
 for n,r in apps:
  all_ids.append(r['applicant_id']);all_persons.append((norm(r['name']).lower(),norm(r['dob'])))
  alias_lookup[(norm(r['name']).lower(),norm(r['dob']))]=(f,n,r['applicant_id'])
 for sheet in ['diagnoses','medications','surgery_history']:
  ws=w[sheet];source=srcw[sheet];current=[r for n,r in rows(ws) if any(v is not None for v in r.values())];h=head(ws)
  check(f+'!'+sheet+' original headings retained',h==head(source))
  original=[r for n,r in rows(source) if any(v is not None for v in r.values())]
  before=Counter(rowtuple(r,h) for r in original);after=Counter(rowtuple(r,h) for r in current)
  check(f+'!'+sheet+' all existing records preserved',all(after[k]>=n for k,n in before.items()))
  actual={r.get('applicant_id') for r in current}
  check(f+'!'+sheet+' exact applicant coverage',actual==set(ids),f'{len(actual)}/{len(ids)}')
  check(f+'!'+sheet+' no blank clinical cells',all(v is not None and str(v).strip()!='' for r in current for v in r.values()))
  check(f+'!'+sheet+' no dangling see-sheet references',all(not isref(v) for r in current for v in r.values()))
  order=[]
  for r in current:
   if not order or order[-1]!=r['applicant_id']:order.append(r['applicant_id'])
  check(f+'!'+sheet+' grouped in applicant order',order==ids)
  duplicate_excess={k:v for k,v in after.items() if v>max(1,before[k])}
  check(f+'!'+sheet+' no new identical duplicate records',not duplicate_excess)
  # Every concrete inline value must correspond to a structured record for that ID.
  byid=defaultdict(list)
  for r in current:byid[r['applicant_id']].append(r)
  for n,a in apps:
   field={'diagnoses':'diagnoses','medications':'medications','surgery_history':'past_surgical_history'}[sheet]
   text=a.get(field)
   if isref(text):continue
   values=[] if text is None else [x.strip() for x in str(text).replace('\r','').split('\n') if x.strip()]
   if not values:values=['not supplied']
   actual_values=[norm(r[field]) for r in byid[a['applicant_id']]]
   if actual_values!=values:ADDED_CHECKS.append((f,sheet,a['applicant_id'],values,actual_values))
check('All concrete inline clinical items match supporting tabs',not ADDED_CHECKS,str(ADDED_CHECKS[:3]))
# Verify all351 populations, including new baseline records, with no fuzzy merging.
check('99 original study-list applicants retained',original_count==99)
check('Study-list counts58/13/17/13',newcounts=={'ADRD_Study_Eligibility_List.xlsx':58,'ADRD_Study_Ineligibility_List.xlsx':13,'ADRD_Study_Followup_List.xlsx':17,'ADRD_Study_Wait_List.xlsx':13},str(newcounts))
check('351 unique applicant IDs overall',len(all_ids)==len(set(all_ids))==351)
check('351 unique full name plusDOB identities',len(all_persons)==len(set(all_persons))==351)
for a in readcsv(R/'ID_CROSSWALK.csv'):
 k=(a['name'].lower(),a['DOB']);check('Identity resolution '+a['supplied_numeric_id'],alias_lookup.get(k)==(a['workbook'],int(a['applicants_row']),a['current_applicant_id']))
# Precise dates/medication duration alignment for the newly created records, traced in the audit.
for a in readcsv(R/'POPULATION_AUDIT.csv'):
 expected=json.loads(a['record']);sheet=B[a['workbook']][a['supporting_sheet']]
 candidates=[r for n,r in rows(sheet) if r.get('applicant_id')==a['applicant_id']]
 expected_norm={k:norm(v) for k,v in expected.items()}
 if not any({k:norm(v) for k,v in r.items()}==expected_norm for r in candidates):ADDED_CHECKS.append(('audit mismatch',a['workbook'],a['applicant_id'],expected))
check('All351 newly populated records have correct field/date alignment',not ADDED_CHECKS,str(ADDED_CHECKS[:3]))
fu=B['ADRD_Study_Followup_List.xlsx'];fuid={r['applicant_id'] for n,r in rows(fu['applicants']) if r.get('applicant_id')}
check('Marcus and Henry restored with current call-log IDs',{'MC-00H','MC-00D'}<=fuid)
check('Old numeric aliases do not create duplicate applicants',not({'mc009','mc0006','mc0001','mc0012','mc0002'}&set(all_ids)))
# Original formula definitions in the unchanged MC export are retained exactly, not just their displayed values.
clinical=B['past_medical_and_surgical_history.xlsx'];source_clinical=openpyxl.load_workbook(next(Path(x['source_path']) for x in manifest if x['filename']=='past_medical_and_surgical_history.xlsx'),data_only=False)
original_formulas=[(s.title,c.coordinate,c.value) for s in source_clinical for row in s for c in row if c.data_type=='f']
check('All original MC clinical formulas preserved',all(clinical[s][c].value==v for s,c,v in original_formulas),str(len(original_formulas))+' formulas')
# Lyle's application and mismatching call DOB survive the correction.
demo=B['applicant_demographics.xlsx'].active;dr=next(r for n,r in rows(demo) if r['applicant_id']=='mc-0022')
lylecalls=[r for n,r in rows(B['ADRD_Call_Log.xlsx'].active) if str(r.get('name','')).lower()=='lyle preston']
check('Lyle retains source1963DOB and conflicting1971callerDOB',dr['name']=='lyle preston' and norm(dr['dob'])=='1963-06-12' and any('1971-06-12' in str(r['what_was_discussed']) for r in lylecalls))
# Preserve the known MC medication source gap rather than inventing an empty/no-medication history.
ids={r['applicant_id'] for n,r in rows(clinical['medications']) if r.get('applicant_id')}
check('Original MC medication gap preserved for mc-0063','mc-0063' not in ids)
writecsv(R/'VALIDATION_REPORT.csv',CHECKS)
assert all(c['result']=='PASS' for c in CHECKS),[c for c in CHECKS if c['result']=='FAIL']
# Refresh reviewer addition source rows against this exact output, not a previous sorted version.
old=Path('/workspace/adrd-rebuilt-v2/reviewer');inventory=readcsv(old/'ADDED_APPLICANTS_REVIEW.csv')
positions={}
for f,w in B.items():
 if f=='applicant_demographics.xlsx' or f.startswith('ADRD_Study_'):
  sh=w['applicant_demographics'] if f=='applicant_demographics.xlsx' else w['applicants']
  for n,r in rows(sh):
   if r.get('applicant_id') and r.get('name'):positions[r['applicant_id']]=(f,sh.title,n,r)
call_positions=defaultdict(list)
for n,r in rows(B['ADRD_Call_Log.xlsx'].active):
 if r.get('applicant_id'):call_positions[r['applicant_id']].append(str(n))
for a in inventory:
 f,sh,n,r=positions[a['applicant_id']]
 assert norm(r['name']).lower()==a['name'].lower() and norm(r['dob'])==a['DOB']
 a.update(file=f,sheet=sh,row=n,added_call_rows='; '.join(call_positions[a['applicant_id']]))
writecsv(R/'ADDED_APPLICANTS_REVIEW.csv',inventory)
for f in ['SYNTHETIC_DOB_ADJUSTMENTS.csv','MEDICAL_REFERENCES_TO_VERIFY.csv','SCHEDULING_FEASIBILITY_EXAMPLE.csv']:
 if (old/f).exists():shutil.copy2(old/f,R/f)
# Copy immutable generation information only with clear provenance; not an alternate current input set.
shutil.copy2(old/'scheduling_constraints.json',R/'scheduling_constraints.json')
# Update source issues: the two previously missing callers now have restored baseline rows.
issues=[]
for x in readcsv(old/'SOURCE_REVIEW_ISSUES.csv'):
 if x['applicant_id'] in ['MC-00H','MC-00D','unassigned']:continue
 issues.append(x)
issues += [
 {'applicant_id':'MC-00H','name':'marcus hill','issue':'Restored baseline with incomplete clinical history; call confirms pacemaker','evidence':'User table supplies baseline demographics/device history; additional diagnoses and medications are not given. Existing call confirms pacemaker.','required_action':'Keep restored baseline for exercise; use call-confirmed pacemaker for final screening. Do not invent underlying cardiac diagnosis or medicines.','provisional_disposition':'Pre-call Followup entry restored; pacemaker establishes post-call MRI ineligibility'},
 {'applicant_id':'MC-00D','name':'henry brown','issue':'Restored baseline; diagnosis and medication chronology not supplied','evidence':'User table names tamsulosin in initial note; original call confirms BPH/date and Cataflam for recorded osteoarthritis.','required_action':'Preserve baseline missingness; reconcile call during screening. Sister Elaine disclosures belong to her own record.','provisional_disposition':'Pre-call Followup entry restored; call resolves tamsulosin indication'}]
writecsv(R/'SOURCE_REVIEW_ISSUES.csv',issues)
# A readable review workbook accompanies the four populated input workbooks.
rw=openpyxl.Workbook();rw.remove(rw.active)
for title,f in [('Coverage','CLINICAL_COVERAGE.csv'),('Restored applicants','RESTORED_APPLICANTS.csv'),('ID aliases','ID_CROSSWALK.csv'),('Population audit','POPULATION_AUDIT.csv'),('Explicit unknowns','EXPLICIT_UNKNOWNS.csv'),('Retained differences','BASELINE_TABLE_DIFFERENCES.csv'),('Source issues','SOURCE_REVIEW_ISSUES.csv'),('Validation','VALIDATION_REPORT.csv'),('Added applicants','ADDED_APPLICANTS_REVIEW.csv'),('Medical references','MEDICAL_REFERENCES_TO_VERIFY.csv')]:
 path=R/f
 if not path.exists():continue
 s=rw.create_sheet(title)
 for line in csv.reader(path.open(encoding='utf-8-sig')):s.append(line)
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 for c in s[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D');c.alignment=Alignment(wrap_text=True,vertical='top')
 for col in s.columns:
  s.column_dimensions[col[0].column_letter].width=45
  for c in col:c.alignment=Alignment(wrap_text=True,vertical='top')
rw.save(R/'CLINICAL_COMPLETION_REVIEW.xlsx')
print('Validation:',Counter(x['result'] for x in CHECKS))
print('Study counts:',newcounts,'overall',len(all_ids))
print('Original formula count',len(original_formulas),'population audit rows',len(readcsv(R/'POPULATION_AUDIT.csv')))
