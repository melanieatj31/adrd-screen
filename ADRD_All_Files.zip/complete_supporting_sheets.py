from pathlib import Path
from collections import Counter,defaultdict
from copy import copy,deepcopy
import openpyxl,csv,json,datetime,hashlib,re,shutil
from openpyxl.styles import Font,PatternFill,Alignment
P=Path('/workspace/adrd-complete-v3');I=P/'inputs';O=P/'original_sources';R=P/'reviewer'
for p in [I,O,R]:p.mkdir(exist_ok=True)
A=Path('/workspace/attachments')
SOURCES={
 'ADRD_Call_Log.xlsx':A/'b234dac7-0f33-4c51-bb30-bce3f4c8f2f4/ADRD_Call_Log.xlsx',
 'ADRD_Study_Eligibility_List.xlsx':A/'1f4947c2-abaf-4928-b63f-86fb57eaa6ce/ADRD_Study_Eligibility_List.xlsx',
 'ADRD_Study_Ineligibility_List.xlsx':A/'2089afad-69e3-4994-bd5e-eaeae379d48a/ADRD_Study_Ineligibility_List.xlsx',
 'ADRD_Study_Followup_List.xlsx':A/'bf2ce583-ba80-40e0-996a-a9d353e808e4/ADRD_Study_Followup_List.xlsx',
 'ADRD_Study_Wait_List.xlsx':A/'9e315f01-13eb-4536-a237-452650b2d5d5/ADRD_Study_Wait_List.xlsx',
 'mindcrowd_assessment_other.xlsx':A/'9d621dea-d819-4715-9bef-972b3317b886/mindcrowd_assessment_other.xlsx',
 'applicant_demographics.xlsx':A/'219a10c3-574b-4beb-b0ab-4ca0e8d31a88/applicant_demographics.xlsx',
 'past_medical_and_surgical_history.xlsx':A/'2c53f882-a7db-4fe2-af41-8bd0d8d7742c/past_medical_and_surgical_history.xlsx'}
MANIFEST=[]
for f,src in SOURCES.items():
 shutil.copy2(src,O/f)
 MANIFEST.append({'filename':f,'source_path':str(src),'SHA256':hashlib.sha256(src.read_bytes()).hexdigest()})
for f in ['NIS_MRI_Screening_Manual.pdf','ADRD_Study_Information_Sheet_and_Screening_Manual.pdf']:
 src=Path('/workspace/adrd-rebuilt-v2/inputs')/f;shutil.copy2(src,I/f);shutil.copy2(src,O/f)
 MANIFEST.append({'filename':f,'source_path':str(src),'SHA256':hashlib.sha256(src.read_bytes()).hexdigest()})
EDITED=[f for f in SOURCES if f.startswith('ADRD_Study_')]
B={f:openpyxl.load_workbook(SOURCES[f],data_only=False) for f in EDITED}
# These25 baseline fields are exactly those provided in the user's five-row table.
BASE_HEADERS=['applicant_id','name','dob','sex','race_ethnicity','living_place','language','screening_date','ad_diagnosis','metal_in_body','eye_injury','metal_in_eye','conditional_explain_metal_in_body','conditional_eye_injury_agent','conditional_metal_in_eye_removed','mri_ability','dose','past_surgical_history','conditional_past_surgical_history_date','assessment_date','mc_score','completion_status','scheduled_surgery','conditional_surgery_date','initial_screening_notes']
PASTED=[
 ['mc009','marcus hill','1951-08-10','male','black','orlando, florida','english (native)','2026-12-08','no','yes','no','no','implanted cardiac device; type not entered on questionnaire','n/a','n/a','yes','n/a','cardiac device implantation','2020-09-11','2026-12-15',78,'completed','no','n/a','implanted cardiac device reported without the device type; request the device card.'],
 ['mc0001','peta nguyen','1957-05-06','female','asian','miami, florida','english (native)','2026-12-08','no','no','no','no','n/a','n/a','n/a','yes','n/a','no past surgery reported','n/a','2026-12-15',83,'completed','no','n/a','propranalol is listed but the only documented diagnosis is asthma; clarify its indication.'],
 ['mc0012','sharon bell','1961-09-22','female','white','miami, florida','english (native)','2026-12-08','no','no','no','no','n/a','n/a','n/a','yes','n/a','no past surgery reported','n/a','2026-12-15',88,'completed','no','n/a','levothyroxine is listed but only hyperlipidemia is documented; clarify its indication.'],
 ['mc0002','beatrice james','1955-08-14','female','black','miami, florida','english (native)','2026-12-08','no','no','yes','no','n/a','never had an eye injury','n/a','yes','n/a','no past surgery reported','n/a','2026-12-15',81,'completed','no','n/a','eye-injury checkbox is yes but the explanation says never had an eye injury; clarify the contradiction.'],
 ['mc0006','henry brown','1954-03-07','male','black','miami, florida','english (native)','2026-12-08','no','no','no','no','n/a','n/a','n/a','yes','n/a','no past surgery reported','n/a','2026-12-10',86,'completed','no','n/a','tamsulosin reported but its indication is not in the diagnosis list; request clarification.']]
PRESENT=[dict(zip(BASE_HEADERS,r)) for r in PASTED]
CANONICAL={'mc009':'MC-00H','mc0006':'MC-00D'}
AUDIT=[];RESTORE=[];MISSING=[];COUNT=[];ALIASES=[];BASELINE_DIFF=[]

def headers(ws):return [c.value for c in ws[1]]
def entries(ws):
 h=headers(ws);return [(n,dict(zip(h,[c.value for c in row]))) for n,row in enumerate(list(ws)[1:],2)]
def iso(v):
 if isinstance(v,(datetime.datetime,datetime.date)):return v.strftime('%Y-%m-%d')
 return str(v).strip() if v is not None else ''
def val(v):
 if isinstance(v,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',v.strip()):return datetime.datetime.fromisoformat(v.strip())
 return v

def append(ws,r):ws.append([val(r.get(k,'not supplied')) for k in headers(ws)]);return ws.max_row

def normname(s):return ' '.join(str(s).lower().split())
def key(r):return normname(r.get('name','')),iso(r.get('dob'))
# Check all source applicants first: exact IDs and names, never match similar profiles.
all_existing={};all_ids=set()
for f,w in B.items():
 for rn,r in entries(w['applicants']):
  if not r.get('applicant_id') or not r.get('name'):continue
  assert r['applicant_id'] not in all_ids;all_ids.add(r['applicant_id'])
  assert key(r) not in all_existing;all_existing[key(r)]=(f,rn,r)
assert len(all_existing)==99
for p in PRESENT:
 old=p['applicant_id']
 if key(p) in all_existing:
  f,rn,existing=all_existing[key(p)];canonical=existing['applicant_id'];action='Existing row retained; richer current data preserved'
  for h in BASE_HEADERS:
   if h=='applicant_id':continue
   if iso(existing.get(h))!=iso(p[h]):BASELINE_DIFF.append({'applicant_id':canonical,'old_numeric_id':old,'field':h,'current_value_retained':iso(existing.get(h)),'user_table_value':iso(p[h]),'action':'Current uploaded applicant row retained; user table used for identity restoration, not to overwrite richer data'})
 else:
  assert old in CANONICAL,old
  canonical=CANONICAL[old];assert canonical not in all_ids
  f='ADRD_Study_Followup_List.xlsx';ws=B[f]['applicants'];r=deepcopy(p);r['applicant_id']=canonical
  for h in headers(ws):
   if h not in r:r[h]='not supplied'
  r['mri_tentative_date']=None
  # Tamsulosin is explicitly named in Henry's supplied baseline note. No indication/date is invented.
  if old=='mc0006':r['medications']='tamsulosin'
  rn=append(ws,r);all_existing[key(r)]=(f,rn,r);all_ids.add(canonical)
  action='Missing baseline restored from user-provided table; canonical ID matches latest call log'
  RESTORE.append({'applicant_id':canonical,'original_numeric_id':old,'name':r['name'],'workbook':f,'applicants_row':rn,'source':'User-provided five-row baseline table','unknown_fields':'Additional diagnoses, medications (except named tamsulosin for Henry), dates/durations and availability were not supplied; explicitly marked unknown'})
 ALIASES.append({'supplied_numeric_id':old,'current_applicant_id':canonical,'name':p['name'],'DOB':p['dob'],'workbook':f,'applicants_row':rn,'action':action})
assert len(all_ids)==101

# Expand parallel multiline cells by position, preserving unknownness and source-reported negatives.
REFERENCE=re.compile(r'^see\b.*\bsheet\b',re.I)
def lines(x):
 if x is None or (isinstance(x,str) and not x.strip()):return []
 if isinstance(x,str):return [a.strip() for a in x.replace('\r\n','\n').replace('\r','\n').split('\n') if a.strip()]
 return [x]
def one_or_unknown(values,index):return values[index] if index<len(values) else 'not supplied'
def parse_duration(x):
 if isinstance(x,(int,float)):return x
 text=str(x).strip()
 m=re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)\s*(?:years?|yrs?)?',text,re.I)
 if m:
  v=float(m.group(1));return int(v) if v.is_integer() else v
 return text

def expand(f,rn,r,section):
 id=r['applicant_id']
 if section=='diagnoses':
  names=lines(r.get('diagnoses'));dates=lines(r.get('diagnosis_date'))
  if not names:names=['not supplied']
  if any(REFERENCE.search(str(n)) for n in names):raise RuntimeError((f,id,section,'reference points to a missing clinical row'))
  if len(dates)>len(names):raise RuntimeError((f,id,'more diagnosis dates than diagnoses'))
  out=[]
  for i,n in enumerate(names):out.append({'applicant_id':id,'diagnoses':n,'diagnosis_date':one_or_unknown(dates,i)})
  fields=['diagnoses','diagnosis_date']
 elif section=='medications':
  names=lines(r.get('medications'));starts=lines(r.get('medication_start_date'));dur=lines(r.get('medication_duration'))
  if not names:names=['not supplied']
  if any(REFERENCE.search(str(n)) for n in names):raise RuntimeError((f,id,section,'reference points to a missing clinical row'))
  if len(starts)>len(names) or len(dur)>len(names):raise RuntimeError((f,id,'more medication dates/durations than names'))
  out=[]
  for i,n in enumerate(names):out.append({'applicant_id':id,'medications':n,'medication_start_date':one_or_unknown(starts,i),'medication_duration_years':parse_duration(one_or_unknown(dur,i))})
  fields=['medications','medication_start_date','medication_duration']
 elif section=='surgery_history':
  histories=lines(r.get('past_surgical_history'));dates=lines(r.get('conditional_past_surgical_history_date'));planned=lines(r.get('scheduled_surgery'));plans=lines(r.get('conditional_surgery_date'))
  if not histories:histories=['not supplied']
  if any(REFERENCE.search(str(n)) for n in histories+planned):raise RuntimeError((f,id,section,'reference points to a missing clinical row'))
  # Keep the same positional convention used by the MC export: one past surgery per row; repeated shared plan when unambiguous.
  n=max(len(histories),len(planned),1)
  if len(dates)>len(histories) or (len(planned)>1 and len(planned) not in [1,n]) or len(plans)>max(len(planned),1):raise RuntimeError((f,id,'unresolvable surgical alignment'))
  out=[]
  for i in range(n):
   scheduled=planned[0] if len(planned)==1 else one_or_unknown(planned,i)
   scheduled_date=plans[0] if len(plans)==1 else one_or_unknown(plans,i)
   out.append({'applicant_id':id,'past_surgical_history':one_or_unknown(histories,i),'conditional_past_surgical_history_date':one_or_unknown(dates,i),'scheduled_surgery':scheduled,'conditional_scheduled_surgical_date':scheduled_date})
  fields=['past_surgical_history','conditional_past_surgical_history_date','scheduled_surgery','conditional_surgery_date']
 for i,record in enumerate(out,1):
  AUDIT.append({'workbook':f,'applicant_id':id,'name':r['name'],'supporting_sheet':section,'record_number_for_applicant':i,'source_sheet':'applicants','source_row':rn,'source_fields':'; '.join(fields),'record':json.dumps(record,default=iso,ensure_ascii=False),'action':'Populated missing supporting record from existing applicant row'})
  for k,v in record.items():
   if isinstance(v,str) and ('not supplied' in v.lower() or 'not sure' in v.lower()):MISSING.append({'workbook':f,'applicant_id':id,'name':r['name'],'sheet':section,'field':k,'value':v,'source':'Applicant row or restored baseline; no clinical value invented'})
 return out

OLD_SUPPORT={}
for f,w in B.items():
 ws=w['applicants'];apps=[(rn,r) for rn,r in entries(ws) if r.get('applicant_id') and r.get('name')];ids=[r['applicant_id'] for rn,r in apps]
 assert len(ids)==len(set(ids))
 for name in ['diagnoses','medications','surgery_history']:
  assert name in w.sheetnames
  sh=w[name];h=headers(sh);existing=defaultdict(list)
  for oldrn,r in entries(sh):
   if not any(v is not None for v in r.values()):continue
   assert r.get('applicant_id') in ids,(f,name,oldrn,'unmatched supporting row',r)
   existing[r['applicant_id']].append(r)
  OLD_SUPPORT[(f,name)]=deepcopy(existing)
  added=[];ordered=[]
  for rn,r in apps:
   id=r['applicant_id']
   if id in existing:ordered+=existing[id]
   else:
    expanded=expand(f,rn,r,name);added+=expanded;ordered+=expanded
  # Reorder records in applicant-sheet order, preserving every existing supporting record exactly.
  sh.delete_rows(2,max(sh.max_row-1,0))
  for r in ordered:append(sh,r)
  COUNT.append({'workbook':f,'supporting_sheet':name,'applicants':len(ids),'applicants_previously_represented':len(existing),'applicants_newly_populated':len(ids)-len(existing),'records_added':len(added),'final_supporting_rows':len(ordered),'covered_applicant_ids':len({r['applicant_id'] for r in ordered})})
 # Style generated supporting records without changing original applicant cells.
 for sh in w:
  sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
  for c in sh[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D');c.alignment=Alignment(wrap_text=True,vertical='top')
  if sh.title!='applicants':
   for col in sh.columns:
    sh.column_dimensions[col[0].column_letter].width=20 if any(k in str(col[0].value) for k in ['date','year','id']) else 55
    for c in col[1:]:
     c.alignment=Alignment(wrap_text=True,vertical='top')
     if isinstance(c.value,(datetime.datetime,datetime.date)):c.number_format='yyyy-mm-dd'
  for t in sh.tables.values():t.ref=sh.dimensions
 w.save(I/f)
# Unedited MC exports and call log are byte-identical; source formulas and missing-data challenges remain intact.
for f,src in SOURCES.items():
 if f not in EDITED:shutil.copy2(src,I/f)

def writecsv(path,rs):
 if not rs:return
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  cw=csv.DictWriter(f,fieldnames=list(rs[0]));cw.writeheader();cw.writerows(rs)
for name,data in [('SOURCE_FILES.csv',MANIFEST),('POPULATION_AUDIT.csv',AUDIT),('CLINICAL_COVERAGE.csv',COUNT),('RESTORED_APPLICANTS.csv',RESTORE),('ID_CROSSWALK.csv',ALIASES),('EXPLICIT_UNKNOWNS.csv',MISSING),('BASELINE_TABLE_DIFFERENCES.csv',BASELINE_DIFF)]:writecsv(R/name,data)
json.dump({'supporting_sheets_added':COUNT,'restored':RESTORE,'aliases':ALIASES,'applicants_total':351,'study_list_applicants':101,'mc_applicants':250},open(R/'BUILD_MANIFEST.json','w'),indent=2,default=iso)
# Keep the exact table as a provenance record in the reviewer folder.
writecsv(R/'USER_PROVIDED_BASELINE_TABLE.csv',PRESENT)
print('Restored:',[(r['applicant_id'],r['name']) for r in RESTORE])
for row in COUNT:print(row)
print('Explicitly unknown clinical fields:',len(MISSING))
print('New supporting records',len(AUDIT))
