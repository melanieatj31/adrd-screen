import csv,json,datetime,hashlib,copy
from pathlib import Path
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
P=Path('/workspace/eligibility-merge')
SRC=Path('/workspace/attachments/9da47a7f-7b2c-448c-8049-830af346b2c8/ADRD_Study_Eligibility_List.xlsx')
TXT=Path('/workspace/attachments/4e5074a5-2b7a-45ef-8129-82bcebdd9ec4/Pasted text.txt')
D=json.load(open('/workspace/screening-output/source.json'))
incoming=list(csv.DictReader(TXT.open(encoding='utf-8-sig',newline='')))
w=openpyxl.load_workbook(SRC);ws=w['applicants'];old_headers=[c.value for c in ws[1]]
assert len(incoming)==34 and len({r['applicant_id'] for r in incoming})==34
# Recover identity only from the user's earlier original spreadsheets, never from fuzzy name matches.
identity={}
for f,sheets in D.items():
 if f=='applicant_demographics.xlsx' or f.startswith('ADRD_Study_'):
  for sheet,rows in sheets.items():
   for r in rows:
    if r.get('name') and r.get('dob'):identity[r['applicant_id']]={'name':r['name'],'dob':r['dob'],'source':f+'!'+sheet}
assert all(r['applicant_id'] in identity for r in incoming)
def normal_name(x):return ' '.join(str(x).strip().lower().split())
def day(x):
 if isinstance(x,datetime.datetime):return x.date().isoformat()
 if isinstance(x,datetime.date):return x.isoformat()
 return str(x)[:10] if x else ''
def convert(x):
 if x is None:return None
 if isinstance(x,str):
  try:
   if len(x)==10 and x[4]=='-' and x[7]=='-':return datetime.datetime.fromisoformat(x)
  except ValueError:pass
 return x
existing={};oldcells={};blankrows=[];orphanrows=[];orphans=[]
for rn,row in enumerate(ws.iter_rows(min_row=2),2):
 vals=[c.value for c in row]
 if not any(v is not None for v in vals):blankrows.append(rn);continue
 r=dict(zip(old_headers,vals))
 if not r.get('applicant_id'):
  orphanrows.append(rn)
  for c in row:
   if c.value is not None:orphans.append({'source_sheet':ws.title,'source_cell':c.coordinate,'source_header':old_headers[c.column-1],'original_value':c.value,'action':'Preserved separately; no applicant identity supplied'})
  continue
 key=(normal_name(r['name']),day(r['dob']))
 assert key not in existing
 existing[key]=rn
 for c in row:oldcells[c.coordinate]=c.value
old_count=len(existing)
assert old_count==24
# Separate unattributed source text so it is not assigned to an appended applicant.
for rn in sorted(orphanrows,reverse=True):ws.delete_rows(rn)
assert orphanrows==[26]
# Remove only wholly empty trailing formatting rows, not participant data.
for rn in reversed(blankrows):
 if rn==ws.max_row:ws.delete_rows(rn)
metadata_cols=['screening_status','previous_list','age_at_recruitment_start','age_at_recruitment_end','prior_screening_notes','screening_notes','criteria_reference','next_steps','recontact_date','earliest_enrollment_date','earliest_mri_date','tentative_assessment_date','call_log_updates','record_quality_notes','source_references','pasted_applicant_id','merge_action','merge_review_notes']
for h in metadata_cols:
 if h not in old_headers:ws.cell(1,ws.max_column+1,h)
headers=[c.value for c in ws[1]]
def at(row,key):return ws.cell(row,headers.index(key)+1)
def arr(text):
 try:
  obj=json.loads(text)
  return obj if isinstance(obj,list) else []
 except (ValueError,TypeError):return []
def lines(rows,key,fallback='n/a'):
 if not rows:return fallback
 return '\n'.join(str(r.get(key) if r.get(key) not in [None,''] else 'n/a') for r in rows)
def missing(v):return v is None or (isinstance(v,str) and not v.strip())
maplog=[];conflicts=[]
for p in incoming:
 id=p['applicant_id'];ident=identity[id];key=(normal_name(ident['name']),ident['dob']);hist=arr(p.get('medical_history'));med=arr(p.get('medications'));sur=arr(p.get('surgery_history'))
 mapped={k:v for k,v in p.items() if k in old_headers}
 mapped.update(name=ident['name'],dob=ident['dob'],diagnoses=lines(hist,'diagnoses'),diagnosis_date=lines(hist,'diagnosis_date'),medications=lines(med,'medications'),medication_duration=lines(med,'medication_duration_years'),medication_start_date=lines(med,'medication_start_date'),past_surgical_history=lines(sur,'past_surgical_history'),conditional_past_surgical_history_date=lines(sur,'conditional_past_surgical_history_date'),scheduled_surgery=lines(sur,'scheduled_surgery'),conditional_surgery_date='\n'.join(str(s.get('conditional_scheduled_surgical_date',s.get('conditional_surgery_date','n/a'))) for s in sur) or 'n/a',dose='n/a',mri_availability_notes=None,mri_tentative_date=None)
 if not hist:mapped['diagnoses']='not supplied in pasted record';mapped['diagnosis_date']='n/a'
 if not med:mapped['medications']='not supplied in pasted record';mapped['medication_duration']='n/a';mapped['medication_start_date']='n/a'
 # Preserve source scalar values. Structured history is rendered in matching multiline cells, not lost.
 if 'mc_score' in mapped:
  try:mapped['mc_score']=int(mapped['mc_score'])
  except (ValueError,TypeError):pass
 row_conflicts=[]
 if key in existing:
  rn=existing[key];action='Merged existing applicant; retained existing ID and original data'
  existing_id=at(rn,'applicant_id').value
  # These baseline cells are intentionally authoritative for this merge; conflicts are logged, not overwritten.
  for k,v in mapped.items():
   if k in ['applicant_id','name','dob'] or missing(v):continue
   c=at(rn,k)
   if not missing(c.value):
    equal=day(c.value)==v if isinstance(c.value,(datetime.date,datetime.datetime)) else str(c.value).strip()==str(v).strip()
    if k=='past_surgical_history' and str(c.value).strip().lower() in ['none','no past surgery reported','no'] and str(v).strip().lower() in ['none','no past surgery reported','no']:equal=True
    if not equal and v not in ['n/a','not supplied in pasted record']:
     row_conflicts.append(k);conflicts.append({'workbook_applicant_id':existing_id,'pasted_applicant_id':id,'applicants_row':rn,'field':k,'workbook_value_preserved':str(c.value),'pasted_value_not_overwritten':str(v),'resolution':'Existing value retained; verify against sources if needed'})
   # Do not fill existing blanks with clinically interpreted historical values; preserve the existing row exactly.
 else:
  rn=ws.max_row+1;existing_id=id;action='Added new applicant'
  ws.append([None]*len(headers))
  for k in old_headers:
   value=mapped.get(k,'n/a');at(rn,k).value=convert(value)
  existing[key]=rn
 for k in metadata_cols:
  if k in p:at(rn,k).value=convert(p[k])
 at(rn,'pasted_applicant_id').value=id
 at(rn,'merge_action').value=action
 cautions=[]
 if row_conflicts:cautions.append('Existing workbook values retained; conflicting pasted fields: '+', '.join(row_conflicts)+'. See Merge_conflicts and Pasted_source.')
 if not hist:cautions.append('Detailed medical history unavailable in pasted record; no diagnosis invented.')
 if not med:cautions.append('Detailed medication history unavailable in pasted record; no medication invented.')
 if action=='Added new applicant':cautions.append('Name/DOB recovered by exact applicant ID from earlier user-supplied workbook; availability not supplied in pasted record. Tentative MRI text retained separately and not adopted as an appointment.')
 at(rn,'merge_review_notes').value=' '.join(cautions) or 'No original fields changed.'
 maplog.append({'pasted_applicant_id':id,'workbook_applicant_id':existing_id,'action':action,'applicants_row':rn,'identity_match':'Exact name and DOB from earlier supplied applicant ID' if action.startswith('Merged') else 'New ID; identity recovered from earlier user-supplied source','identity_source':ident['source'],'conflicting_fields':', '.join(row_conflicts)})
# Leave existing applicants not included in the pasted list untouched; no new eligibility assessment was requested.
for name in ['Pasted_source','Merge_audit','Merge_conflicts','Merge_readme']:
 assert name not in w.sheetnames
s=w.create_sheet('Pasted_source');s.append(list(incoming[0]))
for r in incoming:s.append([r[k] for k in incoming[0]])
for title,rs in [('Merge_audit',maplog),('Merge_conflicts',conflicts),('Unassigned_source_data',orphans)]:
 s=w.create_sheet(title)
 if rs:
  s.append(list(rs[0]))
  for r in rs:s.append(list(r.values()))
 else:s.append(['result']);s.append(['No conflicts'])
s=w.create_sheet('Merge_readme')
notes=[('Purpose','Merge34 pasted screening records into the attached eligibility workbook without duplicates; not a new clinical screening exercise.'),('Counts',f'Original applicants:{old_count}; existing people matched:5; new people added:29; final applicants:53.'),('Identity rule','Exact name and full DOB from earlier user-supplied workbooks bridge old numeric IDs to changed alphanumeric workbook IDs. Similar profiles alone were not used.'),('Preservation','All original applicant cells were preserved. Original IDs, clinical details, availability notes and tentative MRI cells are not overwritten. All pasted rows are retained verbatim on Pasted_source.'),('Conflicts','Fields differing between matched records are reported on Merge_conflicts; current workbook values take precedence during this merge.'),('New identities','The pasted CSV omits names and DOBs; for29 appended records these were recovered by exact original ID from earlier user-supplied spreadsheets.'),('No rescreening','Applicants already in the workbook but absent from the pasted list remain untouched. The existing workbook may contain unresolved screening challenges; this merge does not validate their eligibility.'),('Availability and MRI dates','No availability or MRI appointment is invented for appended rows. Pasted tentative dates remain in tentative_assessment_date; current mri_tentative_date is preserved or left blank for new records.'),('Pasted information limitations','Some prior-batch histories were unavailable in the pasted record. Those gaps remain explicitly marked; they were not inferred from similar applicants.'),('Recruitment end','The pasted age calculations assume2027-10-30; that pre-existing assumption has not been independently confirmed by this merge.'),('Unassigned source text','Original row26 contains only atorvostatin in medications, without an applicant ID or name. This was preserved on Unassigned_source_data rather than assigned to a person or counted as an applicant.'),('Original files','Uploaded workbook and pasted text remain unchanged. This is a new output file.')]
s.append(['Topic','Details'])
for n in notes:s.append(n)
# Style the added columns, data rows and audit tabs while retaining existing cell values.
for sh in w:
 sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
 for c in sh[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D');c.alignment=Alignment(wrap_text=True,vertical='top')
 for col in sh.columns:
  h=str(col[0].value or '');width=20 if any(x in h for x in ['id','date','dob','score']) else 32
  if any(x in h for x in ['notes','history','value','Details','source','reason','steps','fields']):width=55
  sh.column_dimensions[col[0].column_letter].width=width
  for c in col[1:]:
   c.alignment=Alignment(wrap_text=True,vertical='top')
   if isinstance(c.value,(datetime.date,datetime.datetime)):c.number_format='yyyy-mm-dd'
 sh.row_dimensions[1].height=44
 for t in sh.tables.values():t.ref=sh.dimensions
out=P/'ADRD_Study_Eligibility_List_Merged.xlsx';w.save(out)
# Reopen and prove source cells survived, all incoming records accounted for and no identities duplicated.
v=openpyxl.load_workbook(out,data_only=False);outws=v['applicants']
assert all(outws[a].value==val for a,val in oldcells.items())
assert v['Unassigned_source_data']['D2'].value=='atorvostatin'
rows=[dict(zip([c.value for c in outws[1]],r)) for r in list(outws.values)[1:] if r[0]]
assert len(rows)==53 and len({r['applicant_id'] for r in rows})==53
assert len({(normal_name(r['name']),day(r['dob'])) for r in rows})==53
assert len(maplog)==34 and sum(r['action'].startswith('Merged') for r in maplog)==5
assert len(list(v['Pasted_source'].values))-1==34
with (P/'Merge_Audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
 cw=csv.DictWriter(f,fieldnames=list(maplog[0]));cw.writeheader();cw.writerows(maplog)
print('PASS:24 original applicants +29 additions =53;5existing matches;34 pasted rows preserved; all original values unchanged.')
print('Matched',[(r['pasted_applicant_id'],r['workbook_applicant_id']) for r in maplog if r['action'].startswith('Merged')])
print('Conflicting field comparisons logged:',len(conflicts))
print('Output',out,'bytes',out.stat().st_size)
