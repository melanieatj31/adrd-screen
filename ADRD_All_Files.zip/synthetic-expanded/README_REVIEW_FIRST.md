# Expanded ADRD screening practice dataset

This is an expansion for a synthetic screening/scheduling exercise. It contains copies of the original supplied inputs plus 200 explicitly invented applicants. Original input files and the previously produced screening CSVs were not overwritten. The new people, clinical histories and call notes are fictional. Do not treat additions or tentative dates as real applications, clinical advice or booked appointments.

## Files and totals

The inputs directory contains the same eight XLSX filenames, with their original sheets/headers preserved and added records. Supplemental diagnoses, medications and surgery_history sheets make NEW prior-list cases auditable. They do not invent missing histories for original applicants. Formula-derived original medication durations were retained as their original calculated values so spreadsheet libraries can read them without requiring Excel recalculation.

- Current MC exports:60 original +150 added =210 applicants.
- Prior study lists:16 original +50 added =66 applicants.
- Total distinct source applicants:276.
- Added call-log entries:21 (19 applicant-linked calls and 2 callers who have not formally applied).
- Additional scheduling field: mri_availability_notes in MC other_questions and prior applicants tabs. Prior applicants tabs also include mri_tentative_date; it is usually n/a. The one stale tentative date is deliberate, described below.
- All added medication entries are medication names only. Indications appear in medical history or the call log where appropriate. Clinician safety conclusions are kept in the reviewer key, not patient answers.

## Intended outcomes for the 200 additions

| Added batch | Eligible after review | Wait | Follow-up | Ineligible | Total |
|---|---:|---:|---:|---:|---:|
| Current MC |104|22|16|8|150|
| Prior lists |32|10|6|2|50|
| Total |136|32|22|10|200|

The added prior eligibility sheet starts with 34 people;32 remain eligible and 2 require follow-up after new calls. This deliberately tests updates rather than copying prior labels. Initial file placement is not an answer key. Most new MC applicants (104/150) are eligible, and most additions to the eligibility sheet remain eligible (32/34).

## Requested cases to inspect first

- **mc-0084 — Mirena, current MC only.** Woman born 1966-02-18; evaluated heavy menstrual bleeding in 2024, hysteroscopy/Mirena fitting 2024-06-09, named levonorgestrel (Mirena) medication. Metal response is no. Device brand alone is not grounds to invent a non-exempt permanent-metal exclusion; ordinary device-specific MRI review remains necessary. This example is clinically plausible but its external product reference was not retrieved.
- **mc1046 — original ICD date unknown.** Call distinguishes a defibrillator from a pacemaker and remembers a 2018 battery change but not first implantation. Follow-up for original device records; do not substitute replacement date for initial implant date.
- **mc1045 — unknown medication indication.** Caller reads lamotrigine bottle but does not know why it is taken. No seizure or mood diagnosis is invented; request prescribing/history clarification.
- **mc1033 — colchicine for heart failure.** Initially in eligibility list; caller attributes colchicine to heart failure. Follow-up to reconcile actual indication and diagnoses; do not automatically diagnose gout or assume every cardiac use of colchicine is wrong.
- **mc1049 — ineligible applicant requests no MRI on 2027-12-08.** Pacemaker exclusion still applies. Availability request does not restore eligibility or justify a booking.
- **mc1034 — birthday/DOB conflict.** Eligibility sheet DOB 1954-04-12; call explicitly gives 1962-11-03 and asks not to scan onNovember 3. A stale tentative date of 2027-11-03 is deliberately present to be caught. Identity/DOB requires reconciliation; neither source was silently overwritten. This remains a follow-up case.

## Genuine waits

The 32 new wait cases comprise 22 people reaching age 60 betweenJanuary andOctober 2027 and 10 with explicit plans to remove external fracture frames during recruitment. These are not travel-only deferrals, routine dental/breast-marker exceptions, or histories of penetrating orbital metal injury. Wrist frame intervals were kept short enough to be plausible; lower-leg cases have different operative/removal dates. Confirmation of complete removal and reassessment is required before enrollment. These examples illustrate this study's removal exception, not universal MRI prohibition for external fixation.

New current-MC wait IDs: mc-0185 through mc-0206. New prior wait IDs: mc1035 through mc1044. Recontact dates and reasons are in the reviewer manifest.

## Scheduling difficulty

New applicant outcomes are dispersed in MC row order. Availability windows coverNovember 2027 throughMay 2028, with overlapping preferred dates, transport limitations and alternative dates. Preferred demand exceeds the three-person daily limit, so a scheduler must use alternatives rather than simply assign consecutive slots.

Sixteen otherwise-eligible additions can attend only AFTER the first MRI phase ends 2028-11-01: mc-0173 through mc-0184 and mc1029 through mc1032. These are scheduling holds for a later phase, not invented eligibility wait-list reasons. No next-phase start date is invented.

A reviewer-only feasibility example schedules 152 new eligible-or-wait applicants who have in-phase availability after their wait factors resolve, with at most 3 per day onMonday,Tuesday,Wednesday,Friday orSaturday. It excludes unresolved/ineligible cases and the 16 beyond-phase holds. It is an existence check, not a recommended schedule or actual bookings. The original 76 people are not silently rescreened or scheduled in that example.

## Prior-record edits and prohibited duplicate challenges

Six cells in the expanded copies were intentionally changed. Prior mc 0017's jaw fixation narrative and call update now refer to an ankle frame, preserving the original postponement dates. Prior mc 0014's non-eye jaw fixation narrative now refers to a forearm frame; the independent metallic eye-injury history is unchanged. See EXISTING_RECORD_CHANGES.csv for exact file/sheet/cell and old/new values.

No K-wire, jaw-wire, IUD/Mirena or Spanish-only/English-MC mismatch scenarios were added to previous-MC lists or the call log. Existing current-MC jaw-wire cases remain there. The new Spanish-only passing-MC challenge is mc-0211 and occurs only in current MC.

## Research and date assumptions

The two supplied study manuals were reviewed. Official external medication reference retrieval was blocked by the environment proxy (403), so this dataset must not be described as extensively researched or independently label-verified. MEDICAL_REFERENCES_TO_VERIFY.csv lists official sources and specific points to check. New network-domain additions for DailyMed, Bayer and NHS were saved in the environment configuration draft; they do not apply until review/save and publication in environment settings.

Recruitment end remains assumed 2027-10-30 because the last year digit in the supplied study PDF is unreadable. This assumption affects age waits and removal deadlines. No false assurance of clinical or final MRI clearance is intended.

## Review and validation

ADDITION_REVIEW.xlsx lists all 200 additions, their source row, expected reviewed disposition, reason, dates and linked call rows. It also contains all 6 original-copy edits,21 new calls,27 validation checks and reference-verification status. ADDED_APPLICANTS_REVIEW.csv contains the same addition inventory for filtering.

Validation confirms: original inputs unchanged; expanded-copy edits fully enumerated; all new names/DOBs unique and distinct from originals; unique IDs; complete expected MC sheet joins; no prohibited prior-list scenarios; no classifier jargon in new patient answers; drug-name-only medication cells; majority eligible additions; genuine wait timing; and capacity-feasible in-phase scheduling using alternatives. Common truthful values (no, n/a, standard medication/diagnosis names) and deliberately competing availability dates repeat; full histories and operative dates were not copied as blocks.
