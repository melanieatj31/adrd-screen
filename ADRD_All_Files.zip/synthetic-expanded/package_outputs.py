from pathlib import Path
import json,csv,zipfile,shutil,collections,datetime
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
P=Path('/workspace/synthetic-expanded');R=P/'reviewer';I=P/'inputs'
S=json.load(open(R/'synthetic_records.json'));by={p['id']:p for p in S}
refs=[
('Mirena','https://labeling.bayerhealthcare.com/html/products/pi/Mirena_PI.pdf','Check product composition, indications and device-specific safety documentation; do not confuse levonorgestrel system with a copper device.','Official Bayer reference suggested; retrieval not completed. Near60 use after heavy bleeding is a synthetic scenario, not a recommendation.'),
('Colchicine','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=colchicine','Verify labeled indications and interacting strong CYP3A4/P-gp inhibitors; not all cardiac use is erroneous.','DailyMed access blocked by configured proxy403; specific label not retrieved.'),
('Apixaban','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=apixaban','Verify interaction with combined strong CYP3A4/P-gp inducers such as carbamazepine.','Reference for reviewer verification; not retrieved.'),
('Sildenafil','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=sildenafil','Verify nitrate interaction and hypotension concern.','Reference for reviewer verification; not retrieved.'),
('Sotalol','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=sotalol','Verify concomitant QT-prolonging medication cautions.','Reference for reviewer verification; not retrieved.'),
('Lithium','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=lithium','Verify thiazide-associated lithium concentration/toxicity concerns.','Reference for reviewer verification; not retrieved.'),
('Spironolactone','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=spironolactone','Verify potassium-increasing medication interactions, including trimethoprim context.','Reference for reviewer verification; not retrieved.'),
('Clonazepam','https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=clonazepam','Verify opioid coadministration warning for sedation/respiratory depression.','Reference for reviewer verification; not retrieved.'),
('External fracture frames','https://www.nhs.uk/conditions/broken-arm-or-wrist/','General fracture recovery background; exact frame removal timing is surgeon-specific. Dates are synthetic clinical plans, not universal clearance intervals.','Reference for reviewer verification; not retrieved.'),
('Study and MRI rules','ADRD_Study_Information_Sheet_and_Screening_Manual.pdf; NIS_MRI_Screening_Manual.pdf','Study criteria, device exclusions, age windows and MRI scheduling constraints.','Both supplied manuals read; unchanged supplied copies included in inputs/manuals.')]
with open(R/'MEDICAL_REFERENCES_TO_VERIFY.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['topic','reference','what_to_check','verification_status']);w.writerows(refs)
# Put medical source limitations alongside the review rows so it cannot be mistaken for completed online research.
w=openpyxl.load_workbook(R/'ADDITION_REVIEW.xlsx')
for title,rows in [('References to verify',[['topic','reference','what_to_check','verification_status']]+[list(r) for r in refs]),('Validation',list(csv.reader(open(R/'VALIDATION_REPORT.csv',encoding='utf-8-sig'))))]:
 if title in w:del w[title]
 ws=w.create_sheet(title)
 for row in rows:ws.append(row)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
 for col in ws.columns:
  ws.column_dimensions[col[0].column_letter].width=55
  for c in col:c.alignment=Alignment(wrap_text=True,vertical='top')
w.save(R/'ADDITION_REVIEW.xlsx')
# Include the manuals provided by the user without altering their contents.
(I/'manuals').mkdir(exist_ok=True)
for f in ['ADRD_Study_Information_Sheet_and_Screening_Manual.pdf','NIS_MRI_Screening_Manual.pdf']:
 src=next(Path('/workspace/attachments').glob('*/'+f));shutil.copy2(src,I/'manuals'/f)
summary=f'''# Expanded ADRD screening practice dataset

This is an expansion for a synthetic screening/scheduling exercise. It contains copies of the original supplied inputs plus200 explicitly invented applicants. Original input files and the previously produced screening CSVs were not overwritten. The new people, clinical histories and call notes are fictional. Do not treat additions or tentative dates as real applications, clinical advice or booked appointments.

## Files and totals

The inputs directory contains the same eight XLSX filenames, with their original sheets/headers preserved and added records. Supplemental diagnoses, medications and surgery_history sheets make NEW prior-list cases auditable. They do not invent missing histories for original applicants. Formula-derived original medication durations were retained as their original calculated values so spreadsheet libraries can read them without requiring Excel recalculation.

- Current MC exports:60 original +150 added =210 applicants.
- Prior study lists:16 original +50 added =66 applicants.
- Total distinct source applicants:276.
- Added call-log entries:21 (19 applicant-linked calls and2 callers who have not formally applied).
- Additional scheduling field: mri_availability_notes in MC other_questions and prior applicants tabs. Prior applicants tabs also include mri_tentative_date; it is usually n/a. The one stale tentative date is deliberate, described below.
- All added medication entries are medication names only. Indications appear in medical history or the call log where appropriate. Clinician safety conclusions are kept in the reviewer key, not patient answers.

## Intended outcomes for the200 additions

| Added batch | Eligible after review | Wait | Follow-up | Ineligible | Total |
|---|---:|---:|---:|---:|---:|
| Current MC |104|22|16|8|150|
| Prior lists |32|10|6|2|50|
| Total |136|32|22|10|200|

The added prior eligibility sheet starts with34 people;32 remain eligible and2 require follow-up after new calls. This deliberately tests updates rather than copying prior labels. Initial file placement is not an answer key. Most new MC applicants (104/150) are eligible, and most additions to the eligibility sheet remain eligible (32/34).

## Requested cases to inspect first

- **mc-0084 — Mirena, current MC only.** Woman born1966-02-18; evaluated heavy menstrual bleeding in2024, hysteroscopy/Mirena fitting2024-06-09, named levonorgestrel (Mirena) medication. Metal response is no. Device brand alone is not grounds to invent a non-exempt permanent-metal exclusion; ordinary device-specific MRI review remains necessary. This example is clinically plausible but its external product reference was not retrieved.
- **mc1046 — original ICD date unknown.** Call distinguishes a defibrillator from a pacemaker and remembers a2018 battery change but not first implantation. Follow-up for original device records; do not substitute replacement date for initial implant date.
- **mc1045 — unknown medication indication.** Caller reads lamotrigine bottle but does not know why it is taken. No seizure or mood diagnosis is invented; request prescribing/history clarification.
- **mc1033 — colchicine for heart failure.** Initially in eligibility list; caller attributes colchicine to heart failure. Follow-up to reconcile actual indication and diagnoses; do not automatically diagnose gout or assume every cardiac use of colchicine is wrong.
- **mc1049 — ineligible applicant requests no MRI on2027-12-08.** Pacemaker exclusion still applies. Availability request does not restore eligibility or justify a booking.
- **mc1034 — birthday/DOB conflict.** Eligibility sheet DOB1954-04-12; call explicitly gives1962-11-03 and asks not to scan onNovember3. A stale tentative date of2027-11-03 is deliberately present to be caught. Identity/DOB requires reconciliation; neither source was silently overwritten. This remains a follow-up case.

## Genuine waits

The32 new wait cases comprise22 people reaching age60 betweenJanuary andOctober2027 and10 with explicit plans to remove external fracture frames during recruitment. These are not travel-only deferrals, routine dental/breast-marker exceptions, or histories of penetrating orbital metal injury. Wrist frame intervals were kept short enough to be plausible; lower-leg cases have different operative/removal dates. Confirmation of complete removal and reassessment is required before enrollment. These examples illustrate this study's removal exception, not universal MRI prohibition for external fixation.

New current-MC wait IDs: mc-0185 through mc-0206. New prior wait IDs: mc1035 through mc1044. Recontact dates and reasons are in the reviewer manifest.

## Scheduling difficulty

New applicant outcomes are dispersed in MC row order. Availability windows coverNovember2027 throughMay2028, with overlapping preferred dates, transport limitations and alternative dates. Preferred demand exceeds the three-person daily limit, so a scheduler must use alternatives rather than simply assign consecutive slots.

Sixteen otherwise-eligible additions can attend only AFTER the first MRI phase ends2028-11-01: mc-0173 through mc-0184 and mc1029 through mc1032. These are scheduling holds for a later phase, not invented eligibility wait-list reasons. No next-phase start date is invented.

A reviewer-only feasibility example schedules152 new eligible-or-wait applicants who have in-phase availability after their wait factors resolve, with at most3 per day onMonday,Tuesday,Wednesday,Friday orSaturday. It excludes unresolved/ineligible cases and the16 beyond-phase holds. It is an existence check, not a recommended schedule or actual bookings. The original76 people are not silently rescreened or scheduled in that example.

## Prior-record edits and prohibited duplicate challenges

Six cells in the expanded copies were intentionally changed. Prior mc0017's jaw fixation narrative and call update now refer to an ankle frame, preserving the original postponement dates. Prior mc0014's non-eye jaw fixation narrative now refers to a forearm frame; the independent metallic eye-injury history is unchanged. See EXISTING_RECORD_CHANGES.csv for exact file/sheet/cell and old/new values.

No K-wire, jaw-wire, IUD/Mirena or Spanish-only/English-MC mismatch scenarios were added to previous-MC lists or the call log. Existing current-MC jaw-wire cases remain there. The new Spanish-only passing-MC challenge is mc-0211 and occurs only in current MC.

## Research and date assumptions

The two supplied study manuals were reviewed. Official external medication reference retrieval was blocked by the environment proxy (403), so this dataset must not be described as extensively researched or independently label-verified. MEDICAL_REFERENCES_TO_VERIFY.csv lists official sources and specific points to check. New network-domain additions for DailyMed, Bayer and NHS were saved in the environment configuration draft; they do not apply until review/save and publication in environment settings.

Recruitment end remains assumed2027-10-30 because the last year digit in the supplied study PDF is unreadable. This assumption affects age waits and removal deadlines. No false assurance of clinical or final MRI clearance is intended.

## Review and validation

ADDITION_REVIEW.xlsx lists all200 additions, their source row, expected reviewed disposition, reason, dates and linked call rows. It also contains all6 original-copy edits,21 new calls,27 validation checks and reference-verification status. ADDED_APPLICANTS_REVIEW.csv contains the same addition inventory for filtering.

Validation confirms: original inputs unchanged; expanded-copy edits fully enumerated; all new names/DOBs unique and distinct from originals; unique IDs; complete expected MC sheet joins; no prohibited prior-list scenarios; no classifier jargon in new patient answers; drug-name-only medication cells; majority eligible additions; genuine wait timing; and capacity-feasible in-phase scheduling using alternatives. Common truthful values (no, n/a, standard medication/diagnosis names) and deliberately competing availability dates repeat; full histories and operative dates were not copied as blocks.
'''
# Readability fixes in explanatory notes only.
import re
summary=re.sub(r'(?<=[A-Za-z])(?=\d)',' ',summary)
summary=re.sub(r'(?<=\d)(?=[A-Za-z])',' ',summary)
summary=summary.replace('mc- ','mc-').replace('mc 10','mc10')
(P/'README_REVIEW_FIRST.md').write_text(summary)
# Give input-only users explicit provenance without exposing reviewer answer key.
(I/'READ_ME.txt').write_text('EXPANDED SCREENING PRACTICE INPUTS\n\nThese files copy the supplied inputs and add200 fictional applicants (MC mc-0081..mc-0230; prior mc1001..mc1050) and21 fictional call entries. They are exercise data, not live registrations or appointments. Original source files are unchanged. Six prior-copy narrative edits reserve jaw-wire challenges for current MC; exact changes are documented in the separate reviewer package. Supplemental clinical sheets apply to additions only. Use both supplied manuals; study recruitment end is assumed2027-10-30 pending confirmation. External medical source verification remains incomplete because the network proxy blocked official references. Scheduling preferences are in mri_availability_notes; all dates are tentative until verified.\n')
# Avoid unnecessary internal source-json copies in the downloadable reviewer bundle.
with zipfile.ZipFile(P/'ADRD_Expanded_Inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(I.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(I))
with zipfile.ZipFile(P/'ADRD_Expanded_Reviewer_Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(P/'README_REVIEW_FIRST.md','README_REVIEW_FIRST.md')
 for p in sorted(R.iterdir()):
  if p.is_file() and p.suffix in ['.csv','.xlsx'] or p.name=='scheduling_constraints.json':z.write(p,'reviewer/'+p.name)
print('Packaged inputs and reviewer key separately.')
print('Files:',[(p.name,p.stat().st_size) for p in P.glob('*.zip')])
