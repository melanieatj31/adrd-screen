from pathlib import Path
import openpyxl,json,collections,re,hashlib,datetime,csv
P=Path('/workspace/synthetic-expanded');R=P/'reviewer';S=json.load(open(R/'synthetic_records.json'));byid={p['id']:p for p in S};assert len(byid)==200
B={p.name:openpyxl.load_workbook(p,data_only=True) for p in (P/'inputs').glob('*.xlsx')}
def records(ws):
 vals=list(ws.values);return [dict(zip(vals[0],r)) for r in vals[1:] if any(x is not None for x in r)]
base=json.load(open('/workspace/screening-output/source.json'))
checks=[]
def check(name,condition,detail=''):
 checks.append({'check':name,'result':'PASS' if condition else 'FAIL','detail':detail})
 if not condition:print('FAIL',name,detail)
# Verify exact protected original content, with only the six explicitly documented replacements.
allowed={(r['file'],r['sheet'],r['cell']) for r in csv.DictReader(open(R/'EXISTING_RECORD_CHANGES.csv',encoding='utf-8-sig'))}
other_changes=[]
for f,h in json.load(open(R/'original_input_hashes.json')).items():
 src=next(Path('/workspace/attachments').glob('*/'+f));assert hashlib.sha256(src.read_bytes()).hexdigest()==h
 original=openpyxl.load_workbook(src,data_only=True)
 for ws in original:
  edited=B[f][ws.title]
  for row in ws:
   for c in row:
    if c.value!=edited[c.coordinate].value and (f,ws.title,c.coordinate) not in allowed:other_changes.append((f,ws.title,c.coordinate,str(c.value),str(edited[c.coordinate].value)))
check('Original files unchanged; expanded-copy edits limited to change log',not other_changes,str(other_changes[:5]))
newids=set(byid);oldids={r['applicant_id'] for r in base['applicant_demographics.xlsx']['applicant_demographics']}
for f,sheets in base.items():
 if f.startswith('ADRD_Study_'):oldids.update(r['applicant_id'] for r in sheets['applicants'])
check('200 new IDs are distinct and do not overlap76 original IDs',not(newids&oldids))
mc=records(B['applicant_demographics.xlsx']['applicant_demographics']);check('MC demographics now contain210 applicants',len(mc)==210)
mcids={r['applicant_id'] for r in mc};check('MC IDs are unique',len(mcids)==210)
for f in ['mindcrowd_assessment_other.xlsx','past_medical and surgical_history.xlsx']:
 for ws in B[f]:
  ids=[r['applicant_id'] for r in records(ws)]
  expected_ids=mcids if ws.title!='medications' else {r['applicant_id'] for r in base[f]['medications']}|{p['id'] for p in S if p['group']=='mc'}
  check(f'{f}/{ws.title} exact expected ID coverage',set(ids)==expected_ids)
  if ws.title in ['mindcrowd_assessment','other_questions','eye_clearance','metal_clearance']:check(f'{ws.title} one row per MC applicant',len(ids)==len(set(ids)))
newdob=[p['dob'] for p in S];newnames=[p['name'] for p in S]
check('All200 synthetic names and DOBs unique',len(set(newnames))==200 and len(set(newdob))==200)
oldnames={r.get('name') for sheets in base.values() for rs in sheets.values() for r in rs if r.get('name')}
check('No new name duplicates an original source name',not(set(newnames)&oldnames))
# Restrict special scenarios to new/current MC inputs.
bad=[]
for f,w in B.items():
 if not f.startswith('ADRD_'):continue
 for ws in w:
  for row in ws:
   for c in row:
    if isinstance(c.value,str) and re.search(r'jaw[ -]?wire|jaw fixation|\bk[ -]?wire\b|\biud\b|mirena|spanish.only|spanish.mc',c.value,re.I):bad.append((f,ws.title,c.coordinate,c.value))
check('No jaw-wire/K-wire/IUD/Spanish-MC mismatch scenarios in prior lists or call log',not bad,str(bad[:5]))
# Patient-facing free text must not use classifier jargon.
jargon=[]
for p in S:
 strings=[p['metal_text'],p['eye_agent']]+[s['past_surgical_history'] for s in p['surg']]+[s['scheduled_surgery'] for s in p['surg']]
 if any(re.search(r'\btemporary\b|\bpermanent\b|with metal components',str(x),re.I) for x in strings):jargon.append(p['id'])
check('New patient responses avoid safety-classification jargon',not jargon,str(jargon))
check('New medication cells contain drug names, not indication explanations',all(' for ' not in m['medications'].lower() and '\n' not in m['medications'] for p in S for m in p['med']))
for group in ['mc','prior']:
 ps=[p for p in S if p['group']==group];eligible=sum(p['expected']=='Eligibility' for p in ps)
 check(f'Majority of new {group} applicants actually eligible',eligible>len(ps)/2,f'{eligible}/{len(ps)}')
check('Most added eligibility-list records remain eligible after call review',sum(p['expected']=='Eligibility' for p in S if p['group']=='prior' and p['baseline']=='Eligibility')>17,'32/34')
# Intended eligibility guards and true waits.
start=datetime.date(2027,1,1);end=datetime.date(2027,10,30)
def d(x):return datetime.date.fromisoformat(x[:10])
def age(b,t):return t.year-b.year-((t.month,t.day)<(b.month,b.day))
for p in S:
 if p['expected']=='Eligibility':
  assert p['score']>22 and p['completion']=='completed' and p['mri']=='yes' and p['ad']=='no'
  assert age(d(p['dob']),start)<=85 and age(d(p['dob']),end)>=60
 if p['expected']=='Wait':
  assert p['recontact']!='n/a' and start<=d(p['recontact'])<=end
  if 'age 59' in p['challenge']:assert d(p['dob']).year==1967
  else:
   assert p['surg'][0]['conditional_scheduled_surgical_date'][:10]==p['recontact']
check('Eligible score/age/root responses and32 genuine within-window waits',True)
# Slot matching on allowed dates, max three per day. This is a feasibility proof for reviewer, not actual appointments.
C=json.load(open(R/'scheduling_constraints.json'));finite={};holds=[]
for id,c in C.items():
 if byid[id]['expected'] not in ['Eligibility','Wait']:continue
 if c['type']=='after_phase':holds.append(id);continue
 dates=sorted(set(c['preferred_dates']+c['alternate_dates'])-set(c['blocked_dates']))
 for ds in dates:assert d(ds).weekday() in [0,1,2,4,5] and datetime.date(2027,10,31)<=d(ds)<=datetime.date(2028,11,1)
 finite[id]=dates
matched={};chosen={}
def fit(id,seen):
 for ds in finite[id]:
  for n in range(3):
   slot=(ds,n)
   if slot in seen:continue
   seen.add(slot)
   if slot not in matched or fit(matched[slot],seen):matched[slot]=id;chosen[id]=ds;return True
 return False
unmatched=[id for id in sorted(finite,key=lambda x:len(finite[x])) if not fit(id,set())]
check('Capacity-feasible schedule exists for additions ready within first phase',not unmatched,f'{len(finite)-len(unmatched)}/{len(finite)} matched; {len(holds)} eligible availability holds beyond phase1')
# Deliberate scheduling conflicts have real pressure rather than a large queue with unrestricted availability.
pref=collections.Counter(ds for id,days in finite.items() for ds in C[id]['preferred_dates'])
check('Shared first-choice dates exceed3/day and require alternatives',max(pref.values())>3,str(dict(sorted(pref.items()))))
# Verify intended scenario references and every clinical medication timeline (except deliberate mismatches).
exceptions={'mc-0222'}
chron=[]
for p in S:
 for med in p['med']:
  if d(med['medication_start_date'])>d(p['screening']):chron.append(p['id'])
check('No medicine starts after screening',not chron,str(chron))
write=[{'applicant_id':id,'example_MRI_date':ds,'status':'REVIEWER FEASIBILITY EXAMPLE ONLY; NOT BOOKED'} for id,ds in sorted(chosen.items())]
with open(R/'SCHEDULING_FEASIBILITY_EXAMPLE.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(write[0]));w.writeheader();w.writerows(write)
with open(R/'VALIDATION_REPORT.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['check','result','detail']);w.writeheader();w.writerows(checks)
print('Validation',collections.Counter(r['result'] for r in checks))
print('Finite-window cases',len(finite),'phase holds',len(holds),'unmatched',unmatched)
print('DOB duplicates',[k for k,v in collections.Counter(newdob).items() if v>1])
assert all(r['result']=='PASS' for r in checks)
