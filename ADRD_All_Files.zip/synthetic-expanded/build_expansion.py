from pathlib import Path
import csv,json,random,datetime,calendar,copy,hashlib,zipfile
from collections import Counter,defaultdict
from copy import copy as shallow
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
P=Path('/workspace/synthetic-expanded'); IN=P/'inputs';REV=P/'reviewer';rng=random.Random(2602027)
D=json.load(open('/workspace/screening-output/source.json'))
sourcepaths={p.name:p for p in Path('/workspace/attachments').glob('*/*.xlsx') if p.name in D}
original_hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in sourcepaths.items()}
books={k:openpyxl.load_workbook(p,data_only=True) for k,p in sourcepaths.items()}
changes=[]; manifest=[]; added_calls=[]; synthetic=[]; all_used_dates=set()
for sheets in D.values():
 for rows in sheets.values():
  for r in rows:
   for v in r.values():
    if isinstance(v,str) and len(v)==10 and v[4:5]=='-' and v[7:8]=='-':all_used_dates.add(v)

def date(x):
 if isinstance(x,datetime.datetime):return x.date()
 if isinstance(x,datetime.date):return x
 return datetime.date.fromisoformat(x)
def excel(x):
 if isinstance(x,datetime.date):return datetime.datetime.combine(x,datetime.time())
 return x

def pickdate(lo,hi,avoid_all=True):
 lo=date(lo);hi=date(hi)
 assert lo<=hi,(lo,hi)
 for _ in range(10000):
  x=lo+datetime.timedelta(days=rng.randrange((hi-lo).days+1));s=x.isoformat()
  if not avoid_all or s not in all_used_dates:
   all_used_dates.add(s);return x
 raise RuntimeError('No unique date')

def cols(ws):return [c.value for c in ws[1]]
def extend(ws,names):
 h=cols(ws)
 for name in names:
  if name not in h:
   ws.cell(1,len(h)+1,name);h.append(name)
 return h

def append(ws,r):
 h=cols(ws);ws.append([excel(r.get(k,'n/a')) for k in h]);return ws.max_row

def update(ws,id,key,value,why):
 h=cols(ws)
 for row in ws.iter_rows(min_row=2):
  if row[h.index('applicant_id')].value==id:
   cell=row[h.index(key)];old=cell.value
   if old!=value:
    changes.append({'file':ws.parent._synthetic_filename,'sheet':ws.title,'applicant_id':id,'cell':cell.coordinate,'old_value':str(old),'new_value':str(value),'reason':why})
    cell.value=value
for f,w in books.items():w._synthetic_filename=f
# Only in expanded copies: remove legacy jaw-wire scenarios from previous-batch data.
w=books['ADRD_Study_Wait_List.xlsx']['applicants']
update(w,'mc0017','conditional_explain_metal_in_body','frame around my left ankle after a bad fall','Reserve jaw-wire scenarios for current MC applicants.')
update(w,'mc0017','past_surgical_history','surgery for broken left ankle','Replace prior-batch jaw fixation with an ankle-frame scenario; preserve date logic.')
update(w,'mc0017','scheduled_surgery','taking the ankle frame off','Preserve planned removal challenge without jaw-wire wording.')
update(w,'mc0017','initial_screening_notes','ankle frame removal initially planned for 2027-01-28; compare structured date and subsequent call update before deciding when to recontact','Preserve conflicting-date challenge; remove prior-batch jaw-wire phrase.')
update(w,'mc0014','conditional_explain_metal_in_body','shoulder surgery after a torn rotator cuff and a frame on my right forearm after a fall','Reserve jaw-wire scenarios for current MC; retain independent metallic eye-injury exclusion.')
for row in books['ADRD_Call_Log.xlsx']['call_log'].iter_rows(min_row=2):
 if row[0].value=='mc0017':
  cell=row[3];changes.append({'file':'ADRD_Call_Log.xlsx','sheet':'call_log','applicant_id':'mc0017','cell':cell.coordinate,'old_value':cell.value,'new_value':'ankle-frame removal moved to 2027-11-01','reason':'Match revised prior-list scenario without changing postponement date.'});cell.value='ankle-frame removal moved to 2027-11-01'
# Scheduling data is an additive schema extension, not embedded answer-key text.
extend(books['mindcrowd_assessment_other.xlsx']['other_questions'],['mri_availability_notes'])
for row in books['mindcrowd_assessment_other.xlsx']['other_questions'].iter_rows(min_row=2):row[-1].value='n/a'
prior_fields=['diagnoses','diagnosis_date','medications','medication_duration','medication_start_date','mri_availability_notes','mri_tentative_date']
for f,w in books.items():
 if f.startswith('ADRD_Study_'):
  ws=w['applicants'];oldh=cols(ws);extend(ws,prior_fields)
  for row in ws.iter_rows(min_row=2):
   for cell in row[len(oldh):]:cell.value='n/a'
  for title,headers in [('diagnoses',['applicant_id','diagnoses','diagnosis_date']),('medications',['applicant_id','medications','medication_start_date','medication_duration_years']),('surgery_history',['applicant_id','past_surgical_history','conditional_past_surgical_history_date','scheduled_surgery','conditional_scheduled_surgical_date'])]:
   ws2=w.create_sheet(title);ws2.append(headers)
# Broad condition/drug pool. Medicine fields contain names only, not explanatory sentences.
profiles=[
('hypertension',['candesartan'],None),('hyperlipidemia',['pitavastatin'],None),('hypothyroidism',['levothyroxine'],None),
('gout',['allopurinol'],None),('primary open-angle glaucoma',['latanoprost'],None),('allergic rhinitis',['mometasone'],None),
('osteoarthritis',['acetaminophen'],None),('gastroesophageal reflux',['famotidine'],None),('type 2 diabetes',['metformin'],None),
('osteoporosis',['alendronate','cholecalciferol'],None),('psoriasis',['apremilast'],None),('chronic constipation',['linaclotide'],None),
('benign prostatic hyperplasia',['tamsulosin','dutasteride'],'male'),('overactive bladder',['mirabegron'],None),('restless legs syndrome',['ropinirole'],None),
('migraine',['rimegepant'],None),('atopic dermatitis',['dupilumab'],None),('vitamin B12 deficiency',['cyanocobalamin'],None),
('dry eye disease',['cyclosporine eye drops'],None),('ulcerative colitis',['mesalamine'],None),('microscopic colitis',['budesonide'],None),
('Sjogren syndrome',['cevimeline'],None),('trigeminal neuralgia',['oxcarbazepine'],None),('iron deficiency anemia',['ferrous sulfate'],None),
('asthma',['budesonide-formoterol','albuterol'],None),('essential tremor',['primidone'],None),('Parkinson disease',['carbidopa-levodopa'],None),
('rosacea',['azelaic acid'],None),('seborrheic dermatitis',['ketoconazole shampoo'],None),('lichen sclerosus',['clobetasol'],'female'),
('hypertension',['irbesartan'],None),('hyperlipidemia',['rosuvastatin','ezetimibe'],None),('type 2 diabetes',['empagliflozin'],None),
('atrial fibrillation',['apixaban','metoprolol'],None),('chronic urticaria',['cetirizine'],None),('pancreatic insufficiency',['pancrelipase'],None),
('bile acid diarrhea',['cholestyramine'],None),('osteopenia',['cholecalciferol'],None),('hand eczema',['tacrolimus ointment'],None),
('postherpetic neuralgia',['gabapentin'],None),('benign prostatic hyperplasia',['alfuzosin'],'male'),('gastroesophageal reflux',['pantoprazole'],None),
('seasonal allergies',['fexofenadine'],None),('plaque psoriasis',['calcipotriene'],None),('primary open-angle glaucoma',['dorzolamide'],None),
('hypertension',['amlodipine'],None),('type 2 diabetes',['sitagliptin'],None),('osteoporosis',['risedronate'],None),
('lichen planus',['triamcinolone ointment'],None),('chronic constipation',['polyethylene glycol'],None),('psoriatic arthritis',['adalimumab'],None),
('rheumatoid arthritis',['hydroxychloroquine'],None),('acne rosacea',['metronidazole gel'],None),('chronic bronchitis',['tiotropium'],None),
('folate deficiency',['folic acid'],None),('vitamin D deficiency',['ergocalciferol'],None),('neuropathic pain',['pregabalin'],None),
('recurrent herpes simplex',['valacyclovir'],None),('seborrheic dermatitis',['ciclopirox shampoo'],None),('overactive bladder',['vibegron'],None),
('hyperuricemia with gout',['febuxostat'],None),('hypothyroidism',['levothyroxine'],None),('allergic conjunctivitis',['olopatadine eye drops'],None),
('coronary artery disease',['aspirin','rosuvastatin'],None),('hypertension',['telmisartan'],None),('irritable bowel syndrome with constipation',['lubiprostone'],None)]
# Unique synthetic names; no linkage to real individuals is intended.
firstF=['Adrienne','Bianca','Camille','Daphne','Estelle','Francesca','Giselle','Harriet','Imogen','Jacqueline','Keisha','Lucinda','Monique','Nadine','Odette','Patrice','Quinn','Ramona','Simone','Therese','Ursula','Vivienne','Willa','Xiomara','Yvette','Zelda','Anita','Belinda','Corinne','Delphine','Eunice','Florence','Gwendolyn','Helene','Iris','Joanna','Karina','Lenora','Marisol','Noelle','Opal','Priscilla','Rosalind','Sylvia','Tatiana','Veronica','Wilma','Yolanda','Zora','Althea']
firstM=['Alfred','Bennett','Cedric','Dorian','Emilio','Fabian','Graham','Hector','Ismael','Jasper','Kendall','Lorenzo','Malcolm','Nathaniel','Orlando','Preston','Quentin','Rafael','Sterling','Tobias','Ulises','Vernon','Wallace','Xavier','Yuri','Zachary','Ambrose','Bernard','Conrad','Dominic','Everett','Francisco','Gilbert','Hugo','Ignacio','Jerome','Kenneth','Lionel','Maurice','Nelson','Osvaldo','Percival','Reuben','Solomon','Terrence','Victor','Warren','Yosef','Alonzo','Basil']
surnames=['Archer','Baptiste','Castillo','Delaney','Espinosa','Fairchild','Galloway','Hawthorne','Ibarra','Jefferson','Kendrick','Laurent','Mendoza','Norwood','Okafor','Pennington','Quinones','Rosario','Salazar','Talbot','Underwood','Valdez','Whitfield','Yamamoto','Zimmerman','Aguirre','Bennett','Cabrera','Dunbar','Escobar','Figueroa','Goodwin','Holloway','Ingram','Jamison','Kaufman','LeBlanc','Macias','Nakamura','Ortega','Paredes','Rutherford','Serrano','Thorne','Vargas','Westbrook','Yates','Zuniga','Ashford','Barrett']
places=['miami, florida','delray beach, florida','palm coast, florida','ocala, florida','lakeland, florida','vero beach, florida','port st. lucie, florida','winter park, florida','cape coral, florida','st. augustine, florida','bradenton, florida','melbourne, florida','clearwater, florida','pembroke pines, florida','doral, florida','coral springs, florida','homestead, florida','plantation, florida','north miami, florida','aventura, florida','sunrise, florida','miramar, florida','wellington, florida','boynton beach, florida','palm bay, florida','bonita springs, florida','winter haven, florida','dunedin, florida','tamarac, florida','cooper city, florida','hallandale beach, florida','key west, florida','palm beach gardens, florida','coral gables, florida','coconut creek, florida','weston, florida','altamonte springs, florida','largo, florida','sanford, florida','royal palm beach, florida']
races=['black','white','asian','latin/hispanic','indigenous/native']
# Scheduling cohorts deliberately compete for a small first-choice window but have alternatives.
def weekdays_between(a,b):
 a=date(a);b=date(b);return [a+datetime.timedelta(days=k) for k in range((b-a).days+1) if (a+datetime.timedelta(days=k)).weekday() in [0,1,2,4,5]]
window_starts=['2027-11-01','2027-11-15','2027-12-06','2028-01-10','2028-02-07','2028-03-06','2028-04-03','2028-05-08']
constraints={}
def availability(id,index,kind='mc'):
 if (kind=='mc' and index>=92 and index<104) or (kind=='prior' and index in [28,29,30,31]):
  begin=datetime.date(2028,11,3)+datetime.timedelta(days=(index*3)%30)
  note=f'I will be away caring for a relative until {begin.isoformat()}. Please contact me after I get back; I cannot come earlier.'
  constraints[id]={'type':'after_phase','available_from':begin.isoformat(),'preferred_dates':[],'alternate_dates':[],'blocked_dates':[],'note':note};return note
 g=index%8; seq=weekdays_between(window_starts[g],date(window_starts[g])+datetime.timedelta(days=16));pref=seq[:2];alt=seq[2:8]
 # Most want first two dates; longer alternatives make a solvable scheduling exercise.
 use_pref=pref if index%5 else [pref[1]]
 pick=alt[index%len(alt)];alt2=alt[(index+1)%len(alt)];alt3=alt[(index+3)%len(alt)]
 accepted=sorted(set([pick,alt2,alt3]))
 loc=['my daughter drives me','I have to swap a work shift','I need to arrange my caregiver','my son has to take time off','I use the community ride service'][index%5]
 template=[
  'My first choices are {p}. If those are full, I could do {a}; {loc}.',
  'Please try {p}. I can make {a} as backup dates, but I need notice because {loc}.',
  '{loc}. We are free on {p}; if necessary we can also manage {a}.',
  'I checked my calendar: {p} would be best. {a} could work instead. Other dates will be difficult because {loc}.'][index%4]
 note=template.format(p=' or '.join(x.isoformat() for x in use_pref),a=', '.join(x.isoformat() for x in accepted),loc=loc)
 constraints[id]={'type':'finite_dates','available_from':'','preferred_dates':[x.isoformat() for x in use_pref],'alternate_dates':[x.isoformat() for x in accepted],'blocked_dates':[],'note':note};return note

# Build records in logical order, then shuffle actual MC rows so outcomes are dispersed.
for group,n in [('mc',150),('prior',50)]:
 for j in range(n):
  index=j if group=='mc' else 150+j
  id=f'mc-{81+j:04d}' if group=='mc' else f'mc{1001+j:04d}'
  sex='female' if index%2==0 else 'male';names=firstF if sex=='female' else firstM
  name=names[(index//2)%50].lower()+' '+surnames[(index*17+index//50)%50].lower()
  dob=pickdate('1944-02-01','1966-01-01')
  if group=='mc':status='Eligibility' if j<104 else 'Wait' if j<126 else 'Followup' if j<142 else 'Ineligibility'
  else:status='Eligibility' if j<34 else 'Wait' if j<44 else 'Followup' if j<48 else 'Ineligibility'
  screening=datetime.date(2026,12,16)+datetime.timedelta(days=j%13) if group=='mc' else datetime.date(2026,12,1)+datetime.timedelta(days=j%9)
  ass=screening-datetime.timedelta(days=j%3)
  profile=profiles[(index*7)%len(profiles)]
  while profile[2] and profile[2]!=sex:profile=profiles[(profiles.index(profile)+1)%len(profiles)]
  p={'id':id,'group':group,'j':j,'name':name,'sex':sex,'dob':dob,'screening':screening,'assessment':ass,'score':35+(index*19)%64,'completion':'completed','race':races[(index*3)%5],'living':places[(index*11)%len(places)],'language':['english (native)','english (advanced)','english (native); french (intermediate)','english (native); haitian creole (native)','english (advanced); portuguese (native)'][index%5],'ad':'no','mri':'yes','eye':'no','eye_agent':'n/a','metal':'no','metal_eye':'no','metal_text':'n/a','metal_date':'n/a','removed':'n/a','hist':[],'med':[],'surg':[],'baseline':status,'expected':status,'reason':'Meets recorded study criteria; no independent exclusion or unresolved safety/history issue.','challenge':'routine eligible profile','recontact':'n/a','availability':'n/a','tentative':'n/a','docs':[]}
  dxdate=pickdate('2009-01-01','2023-12-31');p['hist'].append({'diagnoses':profile[0],'diagnosis_date':dxdate})
  for med in profile[1]:
   md=pickdate(max(dxdate,datetime.date(2024,2,1)),'2026-05-31');p['med'].append({'medications':med,'medication_start_date':md})
  synthetic.append(p)
# Catalog assignment handled after special cases: no artificial surgery is forced on every applicant.
lookup={p['id']:p for p in synthetic}
def resetclinical(p,diagnoses,meds):
 p['hist']=[];p['med']=[]
 # Intentional scenarios may use a specific chronology; default dates remain coherent.
 for k,condition in enumerate(diagnoses):
  d=pickdate('2012-01-01','2023-10-31');p['hist'].append({'diagnoses':condition,'diagnosis_date':d})
 for drug in meds:
  d=pickdate('2024-02-01','2026-06-30');p['med'].append({'medications':drug,'medication_start_date':d})
def surgery(p,description,d,scheduled='no',scheduled_date='n/a'):
 p['surg'].append({'past_surgical_history':description,'conditional_past_surgical_history_date':date(d),'scheduled_surgery':scheduled,'conditional_scheduled_surgical_date':date(scheduled_date) if scheduled_date!='n/a' else 'n/a'})
def call(p,d,text,initials='l.a.'):
 added_calls.append({'applicant_id':p['id'],'name':p['name'],'date_of_call':date(d),'what_was_discussed':text,'researcher_initials':initials})
# Current MC Mirena case only: recent treatment for heavy bleeding, without invented metal wording.
p=lookup['mc-0084'];p.update(sex='female',name='adriana bellamy',dob=datetime.date(1966,2,18),challenge='Mirena named in medication and surgical histories; no automatic metal-timing exclusion',reason='Otherwise meets criteria; Mirena brand alone is not a non-exempt metal implantation. Confirm actual device in routine MRI safety review.')
resetclinical(p,['history of heavy menstrual bleeding'],['levonorgestrel (Mirena)'])
p['hist'][0]['diagnosis_date']=datetime.date(2024,5,21);p['med'][0]['medication_start_date']=datetime.date(2024,6,9)
surgery(p,'hysteroscopy and Mirena fitted',datetime.date(2024,6,9))
# Genuine age waits: distinct birthdays across the whole recruitment period.
birthdays=['1967-01-19','1967-02-04','1967-02-27','1967-03-16','1967-04-08','1967-04-29','1967-05-13','1967-06-02','1967-06-28','1967-07-17','1967-08-06','1967-08-25','1967-09-14','1967-10-07','1967-10-26','1967-01-31','1967-03-05','1967-05-25','1967-07-08','1967-08-19','1967-09-27','1967-10-18']
agewait=[p for p in synthetic if p['baseline']=='Wait' and ((p['group']=='mc' and p['j']<119) or (p['group']=='prior' and p['j']<41))]
assert len(agewait)==22
for p,b in zip(agewait,birthdays):
 p['dob']=date(b);turns=p['dob'].replace(year=2027);all_used_dates.add(turns.isoformat())
 p.update(reason=f'Otherwise eligible; turns 60 on {turns.isoformat()}, during recruitment. Recontact at that time; do not enroll before 60th birthday.',recontact=turns.isoformat(),challenge='age 59 at screening; reaches 60 during recruitment')
frames=[
('I broke my left wrist falling off a step. There is still a frame on it.','left wrist fracture','left wrist frame fitted','taking the frame off my left wrist'),
('There is a ring-shaped frame around my right shin after a bad break.','right tibial fracture','operation for my broken right shin','removal of the frame around my right shin'),
('My left ankle was broken in a car crash and the outside frame is still there.','left ankle fracture','left ankle fracture surgery','taking off the left ankle frame'),
('The bones in my right forearm broke when I fell. I still have the outside frame.','right radius and ulna fractures','right forearm operation after a fall','right forearm frame removal'),
('My left shin did not join after a fracture. I have a frame around that leg now.','left tibial fracture with delayed union','second operation on my left shin','taking the frame off my left leg'),
('I fell from a ladder and broke my right ankle. The frame has not come off yet.','right ankle fracture','right ankle repair after ladder fall','right ankle frame removal'),
('There is a frame on my left forearm after a cycling accident.','left forearm fracture','left forearm surgery after cycling accident','taking off the left forearm frame'),
('I broke my right wrist in a fall. The frame is due to come off at the fracture clinic.','right distal radius fracture','right wrist fracture operation','removal of right wrist frame'),
('My right lower leg has an outside frame after I slipped on wet stairs.','right lower-leg fracture','right lower-leg fracture surgery','right lower-leg frame removal'),
('I still have the frame on my left ankle from a hiking accident.','left ankle fracture after hiking injury','operation on left ankle after hiking fall','removal of left ankle frame')]
framewait=[p for p in synthetic if p['baseline']=='Wait' and p not in agewait]
assert len(framewait)==10
for k,(p,fr) in enumerate(zip(framewait,frames)):
 text,dx,operation,removal=fr
 if 'wrist' in dx:
  placed=pickdate('2026-11-10','2026-11-15');removed=pickdate('2027-01-04','2027-01-12')
 else:
  placed=pickdate('2026-09-23','2026-10-27');removed=pickdate('2027-01-18','2027-03-04')
 p.update(metal='yes',metal_text=text,metal_date=placed,challenge='external fracture frame; confirmed removal planned within recruitment',reason='Otherwise eligible; disclosed frame is scheduled for complete removal within recruitment. Confirm all frame parts/pins removed and no retained hardware before changing to eligible. No injury to eye is reported.',recontact=removed.isoformat())
 resetclinical(p,[dx],['acetaminophen']);p['hist'][0]['diagnosis_date']=placed-datetime.timedelta(days=2)
 p['med'][0]['medication_start_date']=placed
 surgery(p,operation,placed,removal,removed)
# Current-MC follow-up challenges dispersed in the actual files.
currentFU=[p for p in synthetic if p['group']=='mc' and p['baseline']=='Followup']
assert len(currentFU)==16
p=currentFU[0];p.update(mri='unsure',challenge='uncertain MRI tolerance',reason='Clarify ability and willingness to complete required MRI; uncertainty is not a confirmed refusal.')
p=currentFU[1];p.update(mri=None,challenge='MRI ability response genuinely blank',reason='Required MRI ability response is blank; obtain the missing answer before final disposition.')
p=currentFU[2];p.update(score='error',completion='error',challenge='assessment error without independent exclusion',reason='No valid completed MC result; retrieve or repeat baseline assessment and verify score >22.')
p=currentFU[3];surgery(p,'operation on my upper arm after a road accident',datetime.date(2026,11,23));p.update(challenge='recent operation details unclear; checkbox denies metal',reason='Clarify operation details, retained hardware and dates; surgery wording alone does not establish metal or the permanent-implant timing exclusion.')
p=currentFU[4];p.update(language='spanish (native)',score=88,challenge='Spanish-only answer despite passing English-only MC; current batch only',reason='Clarify English proficiency and test validity: language answer omits English despite passing the English-only assessment. Do not duplicate this challenge in prior-batch records or calls.')
p=currentFU[5];p.update(eye='yes',eye_agent='I clicked the wrong box. I have never hurt either eye.',challenge='eye checkbox and explanation disagree',reason='Clarify whether any eye injury actually occurred before applying MRI injury rules; contradictory responses are not a confirmed injury.')
p=currentFU[6];resetclinical(p,['hypertension'],['losartan','rivastigmine']);p.update(challenge='unexplained cognitive medication with AD denied',reason='Confirm rivastigmine indication, dementia subtype/history, prescriber and dates; medication alone does not confirm Alzheimer disease.')
interactions=[
(7,['atrial fibrillation','major depressive disorder'],['sotalol','escitalopram'],'QT-prolongation concern','Verify prescriber awareness, indication, doses and monitoring for sotalol with escitalopram; route clinical concern for review, without diagnosing harm.'),
(8,['coronary artery disease with angina','erectile dysfunction'],['isosorbide mononitrate','sildenafil'],'nitrate/PDE5 inhibitor hypotension concern','Clarify current nitrate and sildenafil use and timing; combination poses potentially severe hypotension risk requiring prompt clinician review.'),
(9,['gout','current bacterial sinusitis'],['colchicine','clarithromycin'],'colchicine/macrolide interaction concern','Confirm concurrent colchicine and clarithromycin and prescription timing; CYP3A4/P-gp inhibition can increase colchicine toxicity. Obtain clinician/pharmacist review.'),
(10,['bipolar disorder','hypertension'],['lithium','hydrochlorothiazide'],'lithium/thiazide interaction concern','Reconcile lithium and hydrochlorothiazide prescriptions, timing and monitoring because thiazides can raise lithium concentrations.'),
(11,['heart failure with reduced ejection fraction','current urinary tract infection'],['spironolactone','trimethoprim-sulfamethoxazole'],'hyperkalemia concern','Confirm concurrent spironolactone and trimethoprim-sulfamethoxazole, renal function/monitoring and prescriber plan; possible hyperkalemia warrants clinical review.'),
(12,['atrial fibrillation','trigeminal neuralgia'],['apixaban','carbamazepine'],'anticoagulant enzyme-induction concern','Confirm apixaban with carbamazepine and prescriber plan; induction may reduce anticoagulant exposure and effectiveness.'),
(13,['chronic low back pain','panic disorder'],['oxycodone','clonazepam'],'opioid/benzodiazepine respiratory and sedation concern','Verify actual use, doses and prescribing oversight for oxycodone with clonazepam; additive sedation and respiratory depression merit clinical review.')]
for num,dx,meds,challenge,reason in interactions:
 p=currentFU[num]
 if 'erectile dysfunction' in dx:p['sex']='male';p['name']='rolando fenton'
 resetclinical(p,dx,meds);p.update(challenge=challenge,reason=reason)
 if num in [9,11]:
  p['hist'][1]['diagnosis_date']=p['screening']-datetime.timedelta(days=5)
  p['med'][1]['medication_start_date']=p['screening']-datetime.timedelta(days=3)
p=currentFU[14];p.update(metal='yes',metal_text='I had filler put in my cheeks.',metal_date=datetime.date(2026,11,26),challenge='cosmetic filler reported under metal checkbox',reason='Clarify filler type, actual implant/material and procedures; do not infer recent non-exempt metal merely from a yes checkbox explained by filler.');surgery(p,'cheek filler injections',datetime.date(2026,11,26))
p=currentFU[15];resetclinical(p,['type 2 diabetes'],['insulin glargine']);p['hist'][0]['diagnosis_date']=datetime.date(2025,10,14);p['med'][0]['medication_start_date']=datetime.date(2017,9,6);p.update(challenge='diabetes/insulin chronology mismatch',reason='Insulin reportedly began years before recorded diabetes diagnosis; reconcile diabetes history and dates without inferring treatment error.')
# Current-MC confirmed exclusions.
currentI=[p for p in synthetic if p['group']=='mc' and p['baseline']=='Ineligibility']
p=currentI[0];p.update(metal='yes',metal_text='pacemaker under my left collarbone',metal_date=datetime.date(2016,8,19),challenge='pacemaker despite MRI willingness',reason='NIS excludes all cardiac pacemakers, regardless of implant age or conditional labeling.');surgery(p,'pacemaker fitted',datetime.date(2016,8,19))
p=currentI[1];p.update(metal='yes',metal_text='defibrillator in my chest',metal_date=datetime.date(1999,2,11),challenge='ICD implanted before 2000',reason='ICD first implanted 1999-02-11, before the NIS 2000 cutoff.');surgery(p,'heart defibrillator fitted',datetime.date(1999,2,11));resetclinical(p,['history of ventricular fibrillation'],['metoprolol']);p['hist'][0]['diagnosis_date']=datetime.date(1999,1,26)
p=currentI[2];p.update(eye='yes',eye_agent='Something hit my eye when I was working in the garage. I do not know what it was.',challenge='eye injury with unknown agent',reason='Unknown material/agent of prior eye injury meets study/NIS initial-screen exclusion; do not route solely to follow-up.')
p=currentI[3];p.update(ad='yes',challenge='confirmed Alzheimer diagnosis',reason='Reported Alzheimer disease is a specific study exclusion.');resetclinical(p,['Alzheimer disease'],['donepezil'])
p=currentI[4];p.update(score=22,challenge='exact MC threshold',reason='Completed baseline MC score is exactly22; required score is greater than22.')
p=currentI[5];p.update(living='san juan, puerto rico',challenge='residence outside Florida',reason='Puerto Rico residence does not meet current Florida-state residence criterion.')
p=currentI[6];p.update(dob=datetime.date(1940,11,21),challenge='age86 at recruitment start',reason='Applicant is86 on2027-01-01, above maximum age85 at recruitment start.')
p=currentI[7];p.update(challenge='planned hip replacement during fixed exclusion interval',reason='Planned non-exempt hip replacement on2027-02-23 falls within study implant exclusion interval, independent of present MRI willingness.');surgery(p,'no previous operations',datetime.date(2020,6,24),'left hip replacement',datetime.date(2027,2,23));p['surg'][-1]['conditional_past_surgical_history_date']='n/a';resetclinical(p,['left hip osteoarthritis'],['acetaminophen'])
# Prior-list challenges are different from current-MC-only device/language scenarios.
p=lookup['mc1033'];resetclinical(p,['heart failure with reduced ejection fraction'],['carvedilol','dapagliflozin','colchicine']);p.update(expected='Followup',challenge='call says colchicine for heart failure',reason='Call reports colchicine for heart failure; verify actual prescription indication and other cardiac/inflammatory diagnoses. Do not infer gout, pericarditis or coronary disease, and do not label all cardiac colchicine use erroneous.')
call(p,'2026-12-12','Called back about the medicine list. Says, "I take colchicine for my heart failure." Does not recall being told they have gout or pericarditis. Could not explain why it was added; asked us to check with the heart doctor. No further diagnosis was confirmed.','s.n.')
p=lookup['mc1034'];p.update(dob=datetime.date(1954,4,12),expected='Followup',challenge='birthday request conflicts with eligibility-list DOB',reason='Call gives DOB1962-11-03 while eligibility sheet has1954-04-12. Reconcile identity and DOB before final screening/scheduling; retain both source values and avoid requested birthday.')
call(p,'2026-12-13','Please do not book my MRI on November 3 because that is my birthday. When asked to confirm the full date of birth, said 1962-11-03. I read back the date and the caller confirmed it. The date currently on the eligibility sheet was not changed.','l.a.')
p=lookup['mc1045'];resetclinical(p,['hypertension'],['valsartan','lamotrigine']);p.update(challenge='caller does not know medication indication',reason='Lamotrigine has no recorded indication; caller explicitly does not know why it is prescribed. Verify prescription and diagnosis with treating clinician without inferring epilepsy or bipolar disorder.')
call(p,'2026-12-14','Read the bottle and confirmed the medicine is lamotrigine. Says, "I honestly do not know why I take it; the doctor told me to keep taking it." Could not name a seizure or mood diagnosis. Will ask the prescriber for the indication.','r.k.')
p=lookup['mc1046'];resetclinical(p,['dilated cardiomyopathy'],['bisoprolol','spironolactone']);p.update(metal='yes',metal_text='defibrillator in my chest',metal_date='not sure',challenge='unknown original ICD implant date',reason='ICD type reported, but original implantation date is unknown. Need device card/records to determine whether pre-2000 exclusion applies; a later battery replacement is not the original implant date.')
p['surg']=[{'past_surgical_history':'my cardiologist fitted a defibrillator','conditional_past_surgical_history_date':'not sure','scheduled_surgery':'no','conditional_scheduled_surgical_date':'n/a'}]
call(p,'2026-12-15','Knows the chest device is a defibrillator, not a pacemaker, but cannot remember when it was first put in. Remembers the battery being changed in2018. No device card available during the call. Agreed to request the first implantation record; no original date was established.','s.n.')
p=lookup['mc1047'];p.update(score='error',completion='error',challenge='prior-batch MC error remains unresolved',reason='Prior assessment result is an error; no independent exclusion. Obtain valid completed MC result rather than treating error as low score.')
p=lookup['mc1048'];p.update(metal='no',challenge='prior neck operation lacks implant detail',reason='Reported neck operation may or may not have involved implanted hardware; reconcile retained device/material and date, without assuming a contraindication.');surgery(p,'an operation on my neck after nerve pain in my arm',datetime.date(2015,7,29))
p=lookup['mc1049'];p.update(metal='yes',metal_text='pacemaker on the right side of my chest',metal_date=datetime.date(2013,3,7),challenge='ineligible applicant asks to avoid one MRI date',reason='NIS pacemaker exclusion remains determinative; request not to attend on2027-12-08 does not restore eligibility.');surgery(p,'pacemaker operation',datetime.date(2013,3,7))
call(p,'2026-12-16','Asks us not to book an MRI on2027-12-08 because of a family memorial. Applicant remains on the ineligibility list for the pacemaker; no appointment was offered or made.','r.k.')
p=lookup['mc1050'];p.update(living='savannah, georgia',challenge='prior-batch non-Florida resident',reason='Current residence is Georgia, not Florida; study residence criterion fails.')
# Add diverse, coherent historical surgical histories where no scenario already specifies one.
catalog=json.load(open('/workspace/synthetic_surgery_catalog.json'));rng.shuffle(catalog);used_desc=set()
for p in synthetic:
 if p['surg']:continue
 # A minority genuinely report no surgery, rather than padding records with invented operations.
 if p['j']%9==6:
  p['surg']=[{'past_surgical_history':['none','no operations so far','never had an operation'][(p['j']//9)%3],'conditional_past_surgical_history_date':'n/a','scheduled_surgery':'no','conditional_scheduled_surgical_date':'n/a'}];continue
 suitable=[s for s in catalog if s['description'] not in used_desc and (not s['sex'] or s['sex']==p['sex']) and p['dob'].year+s['min_age']<=2024]
 assert suitable,p['id']
 # Orthopedic hardware is assigned only with a positive and matching implant disclosure.
 s=suitable[0];used_desc.add(s['description'])
 lo=max(datetime.date(1995,1,2),datetime.date(p['dob'].year+s['min_age'],min(p['dob'].month,12),min(p['dob'].day,28)))
 d=pickdate(lo,'2025-09-30');surgery(p,s['description'],d)
 p['hist'].append({'diagnoses':'history of '+s['diagnosis'],'diagnosis_date':d-datetime.timedelta(days=3+(p['j']%23))})
 if s['implant'] in ['orthopedic','dental','breast_marker']:
  p.update(metal='yes',metal_text=s['description'],metal_date=d)
  p['challenge']+='; disclosed older '+s['implant']+' implant'
# Audit corrections: endocrine replacement and credible ages for historical procedures.
for p in synthetic:
 for op in p['surg']:
  desc=op['past_surgical_history'].lower()
  if 'total thyroidectomy' in desc:
   sd=op['conditional_past_surgical_history_date']
   p['hist'].append({'diagnoses':'postsurgical hypothyroidism','diagnosis_date':sd})
   if not any(m['medications']=='levothyroxine' for m in p['med']):p['med'].append({'medications':'levothyroxine','medication_start_date':sd+datetime.timedelta(days=1)})
  if 'fallopian tubes tied' in desc or 'vasectomy' in desc:
   old=op['conditional_past_surgical_history_date'];new=pickdate('1995-01-03','1998-12-30')
   op['conditional_past_surgical_history_date']=new
   for h in p['hist']:
    if h['diagnosis_date']>=old-datetime.timedelta(days=30) and h['diagnosis_date']<=old:h['diagnosis_date']=new-datetime.timedelta(days=10)
  if 'adenoid' in desc:
   op['past_surgical_history']='had a cyst taken off the outside of my right elbow'
   for h in p['hist']:
    if 'adenoid' in h['diagnoses']:h['diagnoses']='history of right elbow skin cyst'
  if 'tonsils out when' in desc:op['past_surgical_history']='had my tonsils removed'
# Clinical date plausibility: ensure no diagnosis predates birth, and modern drugs not assigned before approval era.
for p in synthetic:
 for h in p['hist']:
  assert h['diagnosis_date']>p['dob']
 for m in p['med']:
  m['medication_duration_years']=round((p['screening']-m['medication_start_date']).days/365.25,1)
  assert m['medication_duration_years']>=0
# Add availability to eligible and wait records; other statuses retain no scheduling entitlement.
for p in synthetic:
 if p['baseline'] in ['Eligibility','Wait']:
  ix=p['j'] if p['group']=='mc' else p['j']
  p['availability']=availability(p['id'],ix,p['group'])
# Birthday case: two separate sources, explicitly unresolved, not a silently updated DOB.
p=lookup['mc1034'];p['availability']='I can come2027-11-01,2027-11-02,2027-11-03,2027-11-05 or2027-11-06. Please call to confirm.'
constraints[p['id']]={'type':'finite_dates','preferred_dates':['2027-11-03'],'alternate_dates':['2027-11-01','2027-11-02','2027-11-05','2027-11-06'],'blocked_dates':['2027-11-03','2028-11-03'],'note':p['availability'],'dob_in_list':'1954-04-12','dob_in_call':'1962-11-03'}
p['tentative']=datetime.date(2027,11,3) # Deliberate stale tentative date to reconcile with the subsequent call, not a real booking.
# Prior eligible participants make their own transport and availability updates by phone.
for j in [0,2,5,7,10,13,17,20,24,27,28,29,30,31]:
 p=lookup[f'mc{1001+j:04d}'];call(p,datetime.date(2026,12,10)+datetime.timedelta(days=j%8),'Scheduling query only: '+p['availability']+' No appointment was booked.',['l.a.','r.k.','s.n.'][j%3])
# Two inquirers have no formal application and should not become invented screened applicants.
added_calls.extend([
 {'applicant_id':'n/a','name':'brigitte morrow','date_of_call':datetime.date(2026,12,17),'what_was_discussed':'Called to ask how long the first visit takes. Has not completed a MindCrowd application or assessment. Sent the application instructions; no screening outcome or appointment assigned.','researcher_initials':'l.a.'},
 {'applicant_id':'n/a','name':'carmelo vega','date_of_call':datetime.date(2026,12,18),'what_was_discussed':'Asked whether a spouse could drive them and wait at the visit. No completed online application could be identified; caller said they had not applied yet. Provided general study information only.','researcher_initials':'r.k.'}])
# Write shuffled MC data with complete cross-sheet joins.
new_mc=[p for p in synthetic if p['group']=='mc'];rng.shuffle(new_mc)
for p in new_mc:
 id=p['id'];dem={'applicant_id':id,'screening_date_yyyy_mm_dd':p['screening'],'name':p['name'],'dob':p['dob'],'sex':p['sex'],'living_place':p['living'],'language':p['language'],'race_ethnicity':p['race']}
 p['demo_row']=append(books['applicant_demographics.xlsx']['applicant_demographics'],dem)
 append(books['mindcrowd_assessment_other.xlsx']['mindcrowd_assessment'],{'applicant_id':id,'assessment_date':p['assessment'],'mc_score':p['score'],'completion_status':p['completion']})
 append(books['mindcrowd_assessment_other.xlsx']['other_questions'],{'applicant_id':id,'ad_diagnosis':p['ad'],'mri_ability':p['mri'],'mri_availability_notes':p['availability']})
 append(books['mindcrowd_assessment_other.xlsx']['eye_clearance'],{'applicant_id':id,'eye_injury':p['eye'],'conditional_eye_injury_agent':p['eye_agent']})
 append(books['past_medical and surgical_history.xlsx']['metal_clearance'],{'applicant_id':id,'metal_in_body':p['metal'],'metal_in_eye':p['metal_eye'],'conditional_explain_metal_in_body':p['metal_text'],'conditional_explain_metal_in_body_date':p['metal_date'],'conditional_metal_in_eye_removed':p['removed']})
 for h in p['hist']:append(books['past_medical and surgical_history.xlsx']['medical_history'],{'applicant_id':id,**h})
 for m in p['med']:append(books['past_medical and surgical_history.xlsx']['medications'],{'applicant_id':id,**m,'screening_date_yyyy_mm_dd':p['screening']})
 for s in p['surg']:append(books['past_medical and surgical_history.xlsx']['surgery_clearance'],{'applicant_id':id,**s})
# Preserve all original prior-list column headings, then append useful original-style fields.
for p in [p for p in synthetic if p['group']=='prior']:
 f=f"ADRD_Study_{p['baseline']}_List.xlsx";ws=books[f]['applicants'];id=p['id']
 clinical={
  'applicant_id':id,'name':p['name'],'dob':p['dob'],'sex':p['sex'],'race_ethnicity':p['race'],'living_place':p['living'],'language':p['language'],'screening_date':p['screening'],
  'ad_diagnosis':p['ad'],'metal_in_body':p['metal'],'eye_injury':p['eye'],'metal_in_eye':p['metal_eye'],'conditional_explain_metal_in_body':p['metal_text'],'conditional_eye_injury_agent':p['eye_agent'],'conditional_metal_in_eye_removed':p['removed'],'mri_ability':p['mri'],'dose':'n/a',
  'diagnoses':'see diagnoses sheet','diagnosis_date':'see diagnoses sheet','medications':'see medications sheet','medication_duration':'see medications sheet','medication_start_date':'see medications sheet',
  'past_surgical_history':'see surgery_history sheet','conditional_past_surgical_history_date':'see surgery_history sheet','assessment_date':p['assessment'],'mc_score':p['score'],'completion_status':p['completion'],'scheduled_surgery':'see surgery_history sheet','conditional_surgery_date':'see surgery_history sheet',
  'initial_screening_notes':('turns60 during recruitment; recontact '+p['recontact'] if p in agewait else 'awaiting frame removal; recontact '+p['recontact'] if p in framewait else 'medication indication needs clarification' if id=='mc1045' else 'ICD date not supplied; clarify first implantation date' if id=='mc1046' else 'no valid MC score; resolve assessment error' if id=='mc1047' else 'clarify details of previous neck operation' if id=='mc1048' else 'pacemaker excludes MRI at NIS' if id=='mc1049' else 'currently lives outside Florida' if id=='mc1050' else 'n/a'),
  'mri_availability_notes':p['availability'],'mri_tentative_date':p['tentative']}
 p['prior_row']=append(ws,clinical);p['prior_file']=f
 for h in p['hist']:append(books[f]['diagnoses'],{'applicant_id':id,**h})
 for m in p['med']:append(books[f]['medications'],{'applicant_id':id,**m})
 for s in p['surg']:append(books[f]['surgery_history'],{'applicant_id':id,**s})
# Dates and IDs remain structured; late call updates are not silently copied over baseline answers.
for c in sorted(added_calls,key=lambda x:(x['date_of_call'],x['applicant_id'])):
 c['row']=append(books['ADRD_Call_Log.xlsx']['call_log'],c)
# Clean text spacing so patient answers and phone notes look natural.
import re
for w in books.values():
 for ws in w:
  for row in ws:
   for cell in row:
    if isinstance(cell.value,str) and cell.row>1:
     cell.value=re.sub(r'(?<=[A-Za-z])(?=\d{4}-\d{2}-\d{2})',' ',cell.value)
     cell.value=re.sub(r'(?<=\d)(?=[A-Za-z])',' ',cell.value)
# Reviewer-only addition manifest and scheduling key, not mixed into applicant input tabs.
for p in synthetic:
 source=f"applicant_demographics.xlsx!applicant_demographics:{p['demo_row']}" if p['group']=='mc' else f"{p['prior_file']}!applicants:{p['prior_row']}"
 calls=[c for c in added_calls if c['applicant_id']==p['id']]
 manifest.append({'applicant_id':p['id'],'synthetic_name':p['name'],'batch':'current MC' if p['group']=='mc' else 'previous MC','baseline_list':'MC export; not preassigned' if p['group']=='mc' else p['baseline'],'expected_reviewed_list':p['expected'],'challenge':p['challenge'],'why_and_what_to_check':p['reason'],'dob_in_baseline':p['dob'].isoformat(),'recontact_date':p['recontact'],'source_location':source,'call_log_rows':'; '.join(str(c['row']) for c in calls),'MRI_constraint':p['availability'],'research_status':'Known clinical plausibility; new external reference retrieval blocked by network policy'})
# Plain values, simple formatting and filters; no macros, formulas or external workbook links.
navy='17365D';light='E8F0F8'
def format_book(w):
 for ws in w:
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.zoomScale=85
  for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor=navy);c.alignment=Alignment(wrap_text=True,vertical='top')
  ws.row_dimensions[1].height=42
  for j,col in enumerate(ws.columns,1):
   heading=str(ws.cell(1,j).value or '')
   width=18 if any(x in heading for x in ['date','dob','applicant_id','score']) else 27
   if any(x in heading for x in ['notes','discussed','explain','history','challenge','reason','concern','source','constraint','check']):width=55
   ws.column_dimensions[get_column_letter(j)].width=width
   for c in col[1:]:
    c.alignment=Alignment(vertical='top',wrap_text=True)
    if isinstance(c.value,(datetime.date,datetime.datetime)):c.number_format='yyyy-mm-dd'
  for table in ws.tables.values():table.ref=ws.dimensions
for f,w in books.items():format_book(w);w.save(IN/f)

def writecsv(path,rows):
 if not rows:return
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  cw=csv.DictWriter(f,fieldnames=list(rows[0]));cw.writeheader();cw.writerows(rows)
writecsv(REV/'ADDED_APPLICANTS_REVIEW.csv',manifest);writecsv(REV/'EXISTING_RECORD_CHANGES.csv',changes)
writecsv(REV/'ADDED_CALLS_REVIEW.csv',[{**{k:v for k,v in c.items() if k!='row'},'source_row':c['row']} for c in added_calls])
json.dump(constraints,open(REV/'scheduling_constraints.json','w'),indent=2)
json.dump(synthetic,open(REV/'synthetic_records.json','w'),indent=2,default=str)
json.dump(original_hashes,open(REV/'original_input_hashes.json','w'),indent=2)
# Self-contained reviewer workbook.
rw=openpyxl.Workbook();rw.remove(rw.active)
for title,rows in [('Added applicants',manifest),('Existing edits',changes),('New calls',[{**{k:v for k,v in c.items() if k!='row'},'source_row':c['row']} for c in added_calls])]:
 ws=rw.create_sheet(title)
 if rows:
  ws.append(list(rows[0]));
  for row in rows:ws.append([excel(v) if isinstance(v,(datetime.date,datetime.datetime)) else v for v in row.values()])
format_book(rw);rw.save(REV/'ADDITION_REVIEW.xlsx')
print('Added',len(synthetic),'applicants')
for group in ['mc','prior']:
 print(group,'baseline',dict(Counter(p['baseline'] for p in synthetic if p['group']==group)),'expected after review',dict(Counter(p['expected'] for p in synthetic if p['group']==group)))
print('Call additions',len(added_calls),'existing changed cells',len(changes),'unique historical surgery descriptions used',len(used_desc))
