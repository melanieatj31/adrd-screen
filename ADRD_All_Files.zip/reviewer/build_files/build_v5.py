from pathlib import Path
from collections import defaultdict,Counter
from copy import deepcopy
import openpyxl,json,csv,datetime,re,hashlib,shutil
from openpyxl.styles import Font,PatternFill,Alignment
P=Path(__file__).parent;I=P/'inputs';O=P/'original_sources';R=P/'reviewer'
for p in [I,O,R]:p.mkdir(exist_ok=True)
paths=json.load(open(P/'source_paths.json'));B={}
for key,p in paths.items():
 p=Path(p);shutil.copy2(p,O/p.name);B[key]=openpyxl.load_workbook(p,data_only=False)
for name in ['ADRD_Study_Information_Sheet_and_Screening_Manual.pdf','NIS_MRI_Screening_Manual.pdf']:
 src=Path('/workspace/adrd-challenge-v4/inputs')/name;shutil.copy2(src,I/name);shutil.copy2(src,O/name)
def h(s):return [c.value for c in s[1]]
def rows(s):return [(n,dict(zip(h(s),r))) for n,r in enumerate(list(s.values)[1:],2)]
def ex(x):
 if isinstance(x,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',x):return datetime.datetime.fromisoformat(x)
 return x

def add(s,r):s.append([ex(r.get(k,'n/a')) for k in h(s)]);return s.max_row

def rewrite(s,rs):
 s.delete_rows(2,s.max_row-1)
 for r in rs:add(s,r)

def put(s,id,k,v):
 found=[n for n,r in rows(s) if str(r.get('applicant_id','')).lower()==id];assert len(found)==1,(s.title,id,found);s.cell(found[0],h(s).index(k)+1,ex(v))
def clean(x):
 if not isinstance(x,str) or x.startswith('='):return x
 return x.strip().lower()
# Source latest uploads are authoritative; retain all original records and lowercase entries.
for w in B.values():
 for s in w:
  for row in s:
   for c in row:
    if isinstance(c.value,str) and not c.value.startswith('='):c.value=clean(c.value)
NEW=[];OLDIDS=set()
for key in ['eligible','ineligible','followup','wait','demo']:
 s=B[key]['applicants'] if key!='demo' else B[key].active
 OLDIDS.update(r['applicant_id'] for n,r in rows(s) if r.get('applicant_id'))
assert len(OLDIDS)==352

def patient(id,name,dob,sex,dx,med,surgery,score=82,race='white',place='ocala, florida',screen='2026-12-20',notes='n/a'):
 # dx=(name,date); med=(name,start); surgery=(past,date,planned,planned_date)
 d=datetime.date.fromisoformat(screen)
 dur=[round((d-datetime.date.fromisoformat(t)).days/365.25,1) if t not in [None,'n/a'] else 'n/a' for drug,t in med]
 return {'applicant_id':id,'name':name,'dob':dob,'sex':sex,'race_ethnicity':race,'living_place':place,'language':'english (native)','screening_date':screen,'ad_diagnosis':'no','metal_in_body':'no','eye_injury':'no','metal_in_eye':'no','conditional_explain_metal_in_body':'n/a','conditional_eye_injury_agent':'n/a','conditional_metal_in_eye_removed':'n/a','mri_ability':'yes','dose':'n/a','past_surgical_history':'\n'.join(x[0] for x in surgery),'conditional_past_surgical_history_date':'\n'.join(x[1] or '' for x in surgery),'assessment_date':screen,'mc_score':score,'completion_status':'completed','scheduled_surgery':'\n'.join(x[2] for x in surgery),'conditional_surgery_date':'\n'.join(x[3] or '' for x in surgery),'initial_screening_notes':notes,'diagnoses':'\n'.join(x[0] for x in dx),'diagnosis_date':'\n'.join(x[1] or '' for x in dx),'medications':'\n'.join(x[0] for x in med),'medication_start_date':'\n'.join(x[1] or '' for x in med),'medication_duration':'\n'.join(str(x)+' years' if isinstance(x,(float,int)) else x for x in dur),'conditional_explain_metal_in_body_date':'n/a','visit_availability_notes':'n/a','visit1_tentative_date':'n/a','mri_tentative_date':'n/a','_dx':dx,'_med':[(m,t,dur[j]) for j,(m,t) in enumerate(med)],'_surg':surgery}
NO=[('no','n/a','no','n/a')]
female=patient('mc1052','lesley houston','1958-09-14','female',[('hypothyroidism','2014-08-21')],[('levothyroxine','2014-09-04')],NO,84,place='venice, florida',screen='2026-12-19')
female['visit_availability_notes']='please avoid 6-14 and june 18.'
male=patient('mc1053','lesley houston','1958-09-14','male',[('osteoarthritis','2016-03-24')],[('acetaminophen','2016-04-02')],[('no','n/a','left hip replacement','2027-03-23'),('no','n/a','right hip replacement','2027-05-18')],79,place='deland, florida',screen='2026-12-21',notes='hip operations booked')
male['visit_availability_notes']='not available on 5-06.'
unfilled=patient('mc1054','ruthann fielder','1956-02-08','female',[('depression','2017-01-19'),('low back pain','2024-09-11')],[('sertraline','2017-02-06'),('tramadol','2026-12-16')],NO,87,place='palmetto, florida',notes='medication check')
unfilled['visit_availability_notes']='i wont be around july 9 through the 12th.'
card=patient('mc1055','graeme pollard','1954-06-21','male',[('cardiomyopathy','2011-05-12'),('hypertension','2007-10-04')],[('bisoprolol','2011-06-03'),('losartan','2007-10-18')],[('pacemaker',None,'no','n/a')],83,place='port orange, florida',notes='check device record')
card.update(metal_in_body='yes',conditional_explain_metal_in_body='pacemaker',conditional_explain_metal_in_body_date=None,visit_availability_notes='june 28 is my daughters wedding, cant do that day.')
marker=patient('mc1056','meryl penrose','1951-07-09','female',[('heart block','2018-08-23'),('knee arthritis','2010-11-09'),('breast lump','2026-11-03'),('hypertension','2005-04-23')],[('amlodipine','2005-05-12'),('acetaminophen','2010-12-02')],[('pacemaker','2018-09-19','no','n/a'),('right knee replacement','2011-04-12','no','n/a'),('biopsy','2026-11-17','no','n/a')],81,place='north port, florida',notes='check marker')
marker.update(metal_in_body='yes',conditional_explain_metal_in_body='marker',conditional_explain_metal_in_body_date='2018-09-19\n2011-04-12\n2026-11-17',visit_availability_notes='leave 09/22 off my dates.')
finger=patient('mc1057','della fenwick','1957-01-23','female',[('right middle finger fracture','2026-11-13'),('hypothyroidism','2016-04-21')],[('acetaminophen','2026-11-13'),('levothyroxine','2016-05-09')],[('finger plate','2026-11-18','finger plate removal','2027-09-27')],83,race='black',place='palm harbor, florida',screen='2026-12-22',notes='removal booked 27 september')
finger.update(metal_in_body='yes',conditional_explain_metal_in_body='plate in my finger',conditional_explain_metal_in_body_date='2026-11-18',visit_availability_notes='i have a family thing on 8-17. no visits then.')
NORMALS=[
 patient('mc1060','edna morrell','1950-02-17','female',[('allergic rhinitis','2012-06-11')],[('fexofenadine','2014-05-16')],[('left cataract surgery','2019-11-04','no','n/a')],61),
 patient('mc1061','harvey calder','1956-08-09','male',[('reflux','2013-02-21')],[('famotidine','2013-03-04')],[('gallbladder removed','2008-08-15','no','n/a')],74,race='black'),
 patient('mc1062','nadia sutton','1960-12-03','female',[('hypothyroidism','2011-01-27')],[('levothyroxine','2011-02-10')],NO,86,race='asian'),
 patient('mc1063','edwin monroe','1949-06-28','male',[('gout','2009-07-23')],[('allopurinol','2009-08-06')],[('hernia repair','2010-07-08','no','n/a')],69,race='latin/hispanic'),
 patient('mc1064','lillian price','1953-03-19','female',[('osteoporosis','2018-12-11')],[('risedronate','2019-01-08')],[('wrist arthroscopy','2006-05-17','no','n/a')],95,race='indigenous/native'),
 patient('mc1065','irving swann','1955-11-02','male',[('hypertension','2015-04-14')],[('telmisartan','2015-05-07')],[('colonoscopy','2017-02-13','no','n/a')],83),
 patient('mc1066','faye matlock','1962-05-24','female',[('migraine','2005-08-18')],[('rimegepant','2024-04-09')],NO,72,race='black'),
 patient('mc1067','orlando bowen','1958-10-18','male',[('dry eyes','2021-03-25')],[('artificial tears','2021-04-12')],[('skin lesion removed','2016-12-08','no','n/a')],90,race='asian')]
normalnotes=['not free 10-06.','my trip is may 8 to may 12.','i cant come on 7/22.','please leave april 27 clear.','off visiting my niece on 6-21.','no appointments august 27 please.','i will be out of town 9-08 to september 12.','ive already got plans on 05/19.']
for p,n in zip(NORMALS,normalnotes):p['visit_availability_notes']=n
# Add each new prior-list person and complete all three clinical tabs.
def addprior(key,p):
 assert p['applicant_id'] not in OLDIDS
 w=B[key];add(w['applicants'],p)
 for dx,t in p['_dx']:add(w['diagnoses'],{'applicant_id':p['applicant_id'],'diagnoses':dx,'diagnosis_date':t})
 for med,t,yrs in p['_med']:add(w['medications'],{'applicant_id':p['applicant_id'],'medications':med,'medication_start_date':t,'medication_duration_years':yrs})
 for past,t,planned,pt in p['_surg']:add(w['surgery_history'],{'applicant_id':p['applicant_id'],'past_surgical_history':past,'conditional_past_surgical_history_date':t,'scheduled_surgery':planned,'conditional_scheduled_surgical_date':pt})
 NEW.append({'applicant_id':p['applicant_id'],'name':p['name'],'batch':key,'dob':p['dob'],'sex':p['sex'],'type':'ordinary buffer' if p in NORMALS else 'constructed case'})
for key,p in [('eligible',female),('ineligible',male),('followup',unfilled),('followup',card),('followup',marker),('wait',finger)]+[('eligible',p) for p in NORMALS]:addprior(key,p)
# MC sequential-medication control. The explicit stop-date field prevents guessing from a duration alone.
seq=patient('mc-0271','owen braddock','1954-02-26','male',[('depression','2008-09-24')],[('phenelzine','2009-04-15'),('sertraline','2015-05-04')],[('appendix removed','1977-09-19','no','n/a')],78,screen='2026-12-18')
seq['_med'][0]=('phenelzine','2009-04-15',6);seq['_stops']={'phenelzine':'2015-04-15','sertraline':'n/a'};seq['visit_availability_notes']='please keep august 18 clear.'
a1=patient('mc-0272','althea morris','1960-09-05','female',[('hypothyroidism','2010-06-17')],[('levothyroxine','2010-07-01')],[('cataract surgery','2020-05-14','no','n/a')],85,race='black',place='palm bay, florida',screen='2026-12-19')
a1['visit_availability_notes']='could i do aug 1, 2027 for the first visit? its a holiday for me. i have nov 2 off for the scan.'
a2=patient('mc-0273','darren milton','1957-01-28','male',[('hypertension','2012-11-16')],[('amlodipine','2012-12-03')],[('right inguinal hernia repair','2005-03-10','no','n/a')],73,race='latin/hispanic',place='winter springs, florida',screen='2026-12-21')
a2['visit_availability_notes']="can i have 8-1 for visit one, holiday at work then. mri on november 2, my vacation day."
ms=B['history']['medications'];ms.cell(1,ms.max_column+1,'medication_stop_date')
for n,r in rows(ms):ms.cell(n,ms.max_column,'n/a')
for p in [seq,a1,a2]:
 id=p['applicant_id'];assert id not in OLDIDS
 add(B['demo'].active,{'applicant_id':id,'screening_date_yyyy_mm_dd':p['screening_date'],**{k:p[k] for k in ['name','dob','sex','living_place','language','race_ethnicity','visit_availability_notes']}})
 add(B['assessment']['mindcrowd_assessment'],{'applicant_id':id,'assessment_date':p['assessment_date'],'mc_score':p['mc_score'],'completion_status':'completed'})
 add(B['assessment']['other_questions'],{'applicant_id':id,'ad_diagnosis':'no','mri_ability':'yes','visit_availability_notes':p['visit_availability_notes']})
 add(B['assessment']['eye_clearance'],{'applicant_id':id,'eye_injury':'no','conditional_eye_injury_agent':'n/a'})
 for dx,t in p['_dx']:add(B['history']['medical_history'],{'applicant_id':id,'diagnoses':dx,'diagnosis_date':t})
 for med,t,yrs in p['_med']:add(ms,{'applicant_id':id,'medications':med,'medication_start_date':t,'medication_duration_years':yrs,'screening_date_yyyy_mm_dd':p['screening_date'],'medication_stop_date':p.get('_stops',{}).get(med,'n/a')})
 for past,t,planned,pt in p['_surg']:add(B['history']['surgery_clearance'],{'applicant_id':id,'past_surgical_history':past,'conditional_past_surgical_history_date':t,'scheduled_surgery':planned,'conditional_scheduled_surgical_date':pt})
 add(B['history']['metal_clearance'],{'applicant_id':id,**{k:p[k] for k in ['metal_in_body','metal_in_eye','conditional_explain_metal_in_body','conditional_explain_metal_in_body_date','conditional_metal_in_eye_removed']}})
 NEW.append({'applicant_id':id,'name':p['name'],'batch':'mc','dob':p['dob'],'sex':p['sex'],'type':'sequential medication control' if id=='mc-0271' else 'joint date request'})
# Three existing genuinely eligible couples; no A/B/C label is exposed in raw workbooks.
PUZZLE=[{'couple':'a','caller':'mc1001','partner':'mc1002','v1':['2027-08-02','2027-08-03'],'mri':['2027-11-01','2027-11-02'],'v1_solution':'2027-08-03','mri_solution':'2027-11-02'},
 {'couple':'b','caller':'mc1010','partner':'mc1009','v1':['2027-08-02'],'mri':['2027-11-01'],'v1_solution':'2027-08-02','mri_solution':'2027-11-01'},
 {'couple':'c','caller':'mc1017','partner':'mc1018','v1':['2027-08-03','2027-08-04'],'mri':['2027-11-02','2027-11-03'],'v1_solution':'2027-08-04','mri_solution':'2027-11-03'}]
notes={
 'mc1001':"other than aug 2 or 3 for the first visit, i'm not free. for the scan its november 1 or 2.",
 'mc1002':'only 8-2 or 8-3 for visit 1; no scan dates apart from 11-1 and 11-2.',
 'mc1010':'no dates except aug 2 for visit 1 and nov 1 for mri.',
 'mc1009':'i cant make any first visit other than 2 august. november 1 is my one scan day.',
 'mc1017':'first visit has to be aug 3 or 4. nov 2 or 3 for the scan, nothing else works.',
 'mc1018':'not available outside 8-3 or 8-4 for visit 1, and 11-2 or 11-3 for the mri.'}
for id,note in notes.items():
 put(B['eligible']['applicants'],id,'visit_availability_notes',note)
 for col in ['visit1_tentative_date','mri_tentative_date']:put(B['eligible']['applicants'],id,col,'n/a')
# Deliberate arrangement: spread puzzle members; provide two runs of four uncomplicated records.
e=B['eligible']['applicants'];all_e={r['applicant_id']:r for n,r in rows(e) if r.get('applicant_id')}
fixed={2:'mc1001',16:'mc1010',30:'mc1017',43:'mc1009',55:'mc1002',66:'mc1018',23:'mc1052'}
fixed.update({j:'mc'+str(1060+k) for k,j in enumerate([7,8,9,10,35,36,37,38])})
remaining=[r for n,r in rows(e) if r['applicant_id'] not in set(fixed.values())];out=[]
for j in range(68):out.append(all_e[fixed[j]] if j in fixed else remaining.pop(0))
assert not remaining;rewrite(e,out)
# Far-apart MC date-request cases and a quiet historical-drug control between them.
s=B['demo'].active;dm={r['applicant_id']:r for n,r in rows(s)};newmc={'mc-0271','mc-0272','mc-0273'};remaining=[r for n,r in rows(s) if r['applicant_id'] not in newmc]
fixed_mc={24:'mc-0272',137:'mc-0271',229:'mc-0273'}
rewrite(s,[dm[fixed_mc[j]] if j in fixed_mc else remaining.pop(0) for j in range(253)])
# Scatter three new follow-ups among existing records, rather than making a final challenge block.
s=B['followup']['applicants'];fm={r['applicant_id']:r for n,r in rows(s)};newf={'mc1054','mc1055','mc1056'};remaining=[r for n,r in rows(s) if r['applicant_id'] not in newf];fx={4:'mc1054',12:'mc1055',18:'mc1056'}
rewrite(s,[fm[fx[j]] if j in fx else remaining.pop(0) for j in range(20)])
for key,id,position in [('ineligible','mc1053',6),('wait','mc1057',5)]:
 s=B[key]['applicants'];rr=[r for n,r in rows(s)];p=next(r for r in rr if r['applicant_id']==id);rr=[r for r in rr if r['applicant_id']!=id];rr.insert(position,p);rewrite(s,rr)
# Structured clinical tabs track applicant order; preserve every original record and all new clinical detail.
for key in ['eligible','ineligible','followup','wait']:
 w=B[key];ids=[r['applicant_id'] for n,r in rows(w['applicants'])]
 for sh in ['diagnoses','medications','surgery_history']:
  grouped=defaultdict(list)
  for n,r in rows(w[sh]):
   if r.get('applicant_id'):grouped[r['applicant_id']].append(r)
  assert set(grouped)==set(ids),(key,sh,set(ids)-set(grouped))
  rewrite(w[sh],[r for id in ids for r in grouped[id]])
# Add concise calls only under the actual caller; retain original chronology records.
call=B['calls'].active;hh=h(call)
newcalls=[
 ('mc1054','ruthann fielder','2027-01-19','oh i never filled the tramadol and im not going to. just using acetaminophen now.'),
 ('mc1055','graeme pollard','2027-02-11',"im laughing at myself i read my wife's card sorry. shes the one with the pacemaker, mine is an icd."),
 ('mc1056','meryl penrose','2027-01-26','the marker was from my breast biopsy, they said it was benign.'),
 ('mc1053','lesley houston','2027-02-18','ortho called off the march hip operation.'),
 ('mc1057','della fenwick','2027-09-10','ortho cancelled my 27 september surgery.'),
 ('mc1060','edna morrell','2027-02-03','just checking you have the right number to reach me.'),
 ('mc1061','harvey calder','2027-02-08','leave may 8 through 12 out please, im away.'),
 ('mc1063','edwin monroe','2027-02-16','does someone need to drive me back? gave the usual visit information.'),
 ('mc1065','irving swann','2027-03-05','please call in the afternoon, i miss the early calls.'),
 ('mc1067','orlando bowen','2027-03-11','5/19 is still no good, everything else on my form is the same.'),
 ('mc1062','nadia sutton','2027-03-23','do i bring the bottles or just my medication list?'),
 ('mc1001','zelda delaney','2027-04-07','zachary and i checked again. only aug 2 or 3 for visit 1 and nov 1 or 2 for our scans. we need the same dates as each other.'),
 ('mc1010','dominic galloway','2027-04-15','delphine and me can only do august 2 for the first visit, november 1 for the mris. both of us are free those days.'),
 ('mc1017','helene aguirre','2027-04-21',"hugo's calendar matches mine. aug 3 or 4 for the first visit, nov 2 or 3 for the scans. nothing else works for either of us.")]
# Maintain all original calls; insert new challenge calls at dispersed positions separated by routine records.
original=[r for n,r in rows(call) if r.get('name')];insertions={5:[newcalls[5]],11:[newcalls[0]],18:[newcalls[6]],24:[newcalls[3]],30:[newcalls[7]],35:[newcalls[1]],42:[newcalls[8]],47:[newcalls[2]],53:[newcalls[9]],58:[newcalls[10]],63:[newcalls[4]]}
output=[]
for j,r in enumerate(original):
 output.append(r)
 for tup in insertions.get(j,[]):
  id,name,d,text=tup;output.append({'applicant_id':id,'name':name,'date_of_call':d,'what_was_discussed':text,'researcher_initials':'l.a.','visit_availability_notes':'n/a'})
for id,name,d,text in newcalls[11:]:output.append({'applicant_id':id,'name':name,'date_of_call':d,'what_was_discussed':text,'researcher_initials':'r.k.','visit_availability_notes':'n/a'})
rewrite(call,output)
for key,w in B.items():
 for s in w:
  s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
  for c in s[1]:c.font=Font(bold=True,color='ffffff');c.fill=PatternFill('solid',fgColor='17365d');c.alignment=Alignment(wrap_text=True,vertical='top')
  for row in list(s)[1:]:
   for c in row:
    if isinstance(c.value,str) and not c.value.startswith('='):c.value=c.value.lower()
    c.alignment=Alignment(wrap_text=True,vertical='top')
    if isinstance(c.value,(datetime.datetime,datetime.date)):c.number_format='yyyy-mm-dd'
  for t in s.tables.values():t.ref=s.dimensions
 w.save(I/Path(paths[key]).name)
# Cached source formulas stay intact because original MC medication rows were not moved.
import sys
sys.path.insert(0,'/workspace/adrd-rebuilt-v2');from formula_cache import restore_formula_cache
restore_formula_cache(Path(paths['history']),I/Path(paths['history']).name)
# Reviewer metadata is separate from raw human answers.
meta=json.load(open('/workspace/adrd-challenge-v4/reviewer/availability_constraints.json'));meta={r['applicant_id']:r for r in meta}
for p in [female,male,unfilled,card,marker,finger]+NORMALS+[seq,a1,a2]:
 meta[p['applicant_id']]={'applicant_id':p['applicant_id'],'role':None,'notes':p['visit_availability_notes'],'blocked_month_days':[],'blocked_ranges':[],'blocked_weekdays':[],'weekend_only':False}
# Hard dates on added simple records, not merely prose for an optimizer to ignore.
for id,md in {'mc1052':['06-14','06-18'],'mc1053':['05-06'],'mc1056':['09-22'],'mc1057':['08-17'],'mc1060':['10-06'],'mc1062':['07-22'],'mc1063':['04-27'],'mc1064':['06-21'],'mc1065':['08-27'],'mc1067':['05-19'],'mc-0271':['08-18']}.items():meta[id]['blocked_month_days']=md
for id,start,end in [('mc1054','07-09','07-12'),('mc1061','05-08','05-12'),('mc1066','09-08','09-12')]:meta[id]['blocked_ranges']=[{'start':start,'end':end}]
for p in PUZZLE:
 for id in [p['caller'],p['partner']]:
  meta[id].update(notes=notes[id],blocked_month_days=[],blocked_ranges=[],blocked_weekdays=[],weekend_only=False,allowed_visit1=p['v1'],allowed_mri=p['mri'])
json.dump(list(meta.values()),open(R/'availability_constraints.json','w'),indent=2,default=str)
json.dump(PUZZLE,open(R/'couple_puzzle_key.json','w'),indent=2)
def csvout(name,rs):
 with open(R/name,'w',newline='',encoding='utf-8-sig') as f:
  cw=csv.DictWriter(f,fieldnames=list(rs[0]));cw.writeheader();cw.writerows(rs)
csvout('new_applicants.csv',NEW)
csvout('source_files.csv',[{'file':Path(p).name,'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in paths.values()])
json.dump({'source_people':352,'new_people':17,'people_total':369,'counts':{'mc':253,'eligible':68,'ineligible':14,'followup':20,'wait':14}},open(R/'build_manifest.json','w'),indent=2)
print('Built new cases and buffers. Total369unique IDs; calendar allocation remains for the next stage.')
