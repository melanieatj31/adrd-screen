from pathlib import Path
import hashlib,json,shutil,zipfile
P=Path(__file__).parent; R=P/'reviewer'; OUT=Path('/workspace')

def archive(path,files):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for source,name in files:z.write(source,name)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

build=R/'build_files';build.mkdir(exist_ok=True)
for name in ['build_v5.py','finalize_calendar.py','review_and_validate.py','package_v5.py','source_paths.json']:
    shutil.copy2(P/name,build/name)
shutil.copy2('/workspace/adrd-rebuilt-v2/formula_cache.py',build/'formula_cache.py')
archive(R/'original_uploads_reference_only.zip',[(f,f.name) for f in sorted((P/'original_sources').iterdir()) if f.is_file()])
inputs=sorted((P/'inputs').iterdir());assert len(inputs)==10
archive(OUT/'ADRD_Challenge_Inputs_V5.zip',[(f,f.name) for f in inputs])
full=[(P/'README_START_HERE.md','README_START_HERE.md')]+[(f,'inputs/'+f.name) for f in inputs]
full += [(f,str(f.relative_to(P))) for f in sorted(R.rglob('*')) if f.is_file()]
archive(OUT/'ADRD_All_Files_V5.zip',full)
manifest=[]
for name in ['ADRD_Challenge_Inputs_V5.zip','ADRD_All_Files_V5.zip']:
    f=OUT/name;manifest.append({'file':name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
json.dump(manifest,open(P/'package_checksums.json','w'),indent=2)
print(json.dumps(manifest,indent=2))
