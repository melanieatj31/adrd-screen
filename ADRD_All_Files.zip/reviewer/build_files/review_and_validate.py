"""Reviewer-only provenance, case key, and independent consistency checks."""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import product
import calendar,csv,datetime as dt,hashlib,json,openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
P=Path(__file__).parent; I=P/'inputs'; R=P/'reviewer'; OLD=Path('/workspace/adrd-challenge-v4/reviewer')
def rows(s):
    hh=[c.value for c in s[1]]
    return [(n,dict(zip(hh,r))) for n,r in enumerate(list(s.values)[1:],2)]
def readcsv(p):return list(csv.DictReader(open(p,encoding='utf-8-sig')))
def csvout(name,rs,fields=None):
    with open(R/name,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rs[0]));w.writeheader();w.writerows(rs)
def day(x):return x.date() if isinstance(x,dt.datetime) else x
def norm(x):
    if isinstance(x,dt.datetime):return x.isoformat()
    return x.strip().lower() if isinstance(x,str) else x
def months(d,n):
    y,m=divmod(d.year*12+d.month-1+n,12)
    return dt.date(y,m+1,min(d.day,calendar.monthrange(y,m+1)[1]))
def blocked(e,d):
    md=d.strftime('%m-%d')
    return d.weekday() in e['blocked_weekdays'] or md in e['blocked_month_days'] or any(
        b['start']<=md<=b['end'] if b['start']<=b['end'] else md>=b['start'] or md<=b['end']
        for b in e['blocked_ranges'])
CHECK=[]
def ck(name,ok,detail=''):
    CHECK.append({'check':name,'result':'pass' if ok else 'fail','detail':detail})
    if not ok:print('FAIL:',name,detail)
paths=json.load(open(P/'source_paths.json'))
B={key:openpyxl.load_workbook(I/Path(p).name,data_only=True) for key,p in paths.items()}
S={key:openpyxl.load_workbook(p,data_only=True) for key,p in paths.items()}
def applicants(key,w):return w['applicants'] if key!='demo' else w.active
ROSTER=[];ALL={};SOURCEIDS=set();MISSING=[];COVER=[];CHANGES=[]
for key in ['demo','eligible','ineligible','followup','wait']:
    s=applicants(key,B[key]); rr=rows(s)
    ids=[r['applicant_id'] for n,r in rr]
    ck(key+' IDs unique',len(ids)==len(set(ids)))
    for n,r in rr:
        id=r['applicant_id'];ck(id+' in only one input cohort',id not in ALL);ALL[id]=r
        ROSTER.append({'applicant_id':id,'name':r['name'],'dob':str(day(r['dob'])),'sex':r['sex'],'cohort':key,'file':Path(paths[key]).name,'row':n})
    sr={r['applicant_id'].lower():r for n,r in rows(applicants(key,S[key]))}
    SOURCEIDS.update(sr)
    out={r['applicant_id']:r for n,r in rr}
    ck(key+' retains all source people',set(sr)<=set(out))
    for id,r in sr.items():
        for col,v in r.items():
            if norm(out[id].get(col))!=norm(v):
                CHANGES.append({'file':Path(paths[key]).name,'applicant_id':id,'field':col,'before':v,'after':out[id].get(col)})
                ck(id+' intended changed field '+col,col in ['mri_tentative_date','visit1_tentative_date','visit_availability_notes'])
    if key!='demo':
        ck(key+' tentative dates schema',all(k not in [c.value for c in s[1]] for k in ['visit1_tentative_date','mri_tentative_date']) if key!='eligible' else all(k in [c.value for c in s[1]] for k in ['visit1_tentative_date','mri_tentative_date']))
        for sh in ['diagnoses','medications','surgery_history']:
            recs=[r for n,r in rows(B[key][sh]) if r.get('applicant_id')]
            covered={r['applicant_id'] for r in recs}
            ck(key+' '+sh+' exact ID coverage',covered==set(ids))
            COVER.append({'cohort':key,'sheet':sh,'applicants':len(ids),'covered_ids':len(covered),'clinical_rows':len(recs)})
            columns=[c.value for c in S[key][sh][1]]
            original=Counter(tuple(norm(r[k]) for k in columns) for n,r in rows(S[key][sh]) if r.get('applicant_id'))
            actual=Counter(tuple(norm(r[k]) for k in columns) for n,r in rows(B[key][sh]) if r.get('applicant_id'))
            ck(key+' '+sh+' original clinical rows retained',not(original-actual))
        mm=defaultdict(list)
        for n,r in rows(B[key]['medications']):mm[r['applicant_id']].append(r['medications'])
        for n,r in rr:
            if r.get('medications') and not str(r['medications']).startswith('see '):
                ck(r['applicant_id']+' medicine names agree with supporting tab',str(r['medications']).split('\n')==mm[r['applicant_id']])
ck('Exactly 352 source people plus 17 additions',len(SOURCEIDS)==352 and len(ALL)==369 and len(set(ALL)-SOURCEIDS)==17)
expected={'demo':253,'eligible':68,'ineligible':14,'followup':20,'wait':14}
ck('Expected cohort counts',all(sum(r['cohort']==key for r in ROSTER)==num for key,num in expected.items()))
ck('Every added ordinary buffer is eligible',all(ALL['mc'+str(i)]['ad_diagnosis']=='no' for i in range(1060,1068)))
NEW=readcsv(R/'new_applicants.csv');ck('Majority of additions plausibly eligible',sum(r['batch']=='eligible' or r['batch']=='mc' for r in NEW)>len(NEW)/2)
for key,w in B.items():
    for s in w:
        ck(Path(paths[key]).name+' '+s.title+' lowercase text',all(not isinstance(c.value,str) or c.value==c.value.lower() for row in s for c in row))
        ck(Path(paths[key]).name+' '+s.title+' renamed availability header','mri_availability_notes' not in [c.value for c in s[1]])
        for n,r in rows(s):
            for k,v in r.items():
                if v is None:MISSING.append({'file':Path(paths[key]).name,'sheet':s.title,'row':n,'applicant_id':r.get('applicant_id'),'field':k,'reason':'source missing/uncollected or intentionally unknown implant date; not invented'})
    src=Path(paths[key]);ck(src.name+' archived byte-for-byte',src.read_bytes()==(P/'original_sources'/src.name).read_bytes())

# Preserve every prior MC clinical and assessment row, including formula caches.
for key in ['history','assessment']:
    for s in S[key]:
        cols=[c.value for c in s[1]]
        before=Counter(tuple(norm(r[k]) for k in cols) for n,r in rows(s))
        after=Counter(tuple(norm(r[k]) for k in cols) for n,r in rows(B[key][s.title]))
        ck(key+' '+s.title+' original rows retained',not(before-after))
for key,sh in [('assessment','mindcrowd_assessment'),('assessment','other_questions'),('assessment','eye_clearance'),('history','medical_history'),('history','surgery_clearance'),('history','metal_clearance')]:
    ck('MC '+sh+' all 253 IDs represented',{r['applicant_id'] for n,r in rows(B[key][sh])}=={r['applicant_id'] for n,r in rows(B['demo'].active)})
ck('MC medications only original mc-0063 gap retained',{r['applicant_id'] for n,r in rows(B['demo'].active)}-{r['applicant_id'] for n,r in rows(B['history']['medications'])}=={'mc-0063'})
fo=openpyxl.load_workbook(I/Path(paths['history']).name,data_only=False);fs=openpyxl.load_workbook(paths['history'],data_only=False)
FORM=[(s.title,c.coordinate,c.value) for s in fs for row in s for c in row if c.data_type=='f']
ck('All 381 original formula definitions and caches preserved',len(FORM)==381 and all(fo[sh][co].value==v and B['history'][sh][co].value==S['history'][sh][co].value and B['history'][sh][co].value is not None for sh,co,v in FORM))

CALLS=rows(B['calls'].active);cs=[r for n,r in CALLS]
cols=[c.value for c in S['calls'].active[1]]
before=Counter(tuple(norm(r[k]) for k in cols) for n,r in rows(S['calls'].active))
after=Counter(tuple(norm(r[k]) for k in cols) for n,r in CALLS)
ck('All original 69 calls retained',sum(before.values())==69 and not(before-after))
ck('83 call entries after additions',len(CALLS)==83)
CALLAUDIT=[]
for n,r in CALLS:
    id=r.get('applicant_id');linked=id not in [None,'','n/a']
    if linked:ck('Call row '+str(n)+' links existing applicant',id in ALL and r['name']==ALL[id]['name'])
    CALLAUDIT.append({'call_row':n,'applicant_id':id,'name':r['name'],'status':'existing applicant' if linked else 'inquiry only; no invented MC application'})
def call(id,term):return next(r for n,r in CALLS if r.get('applicant_id')==id and term in r['what_was_discussed'])

# New evidence and dates are checked independently of the textual reviewer key.
twins=defaultdict(list)
for r in ROSTER:twins[(r['name'],r['dob'])].append(r)
duplicates=[v for v in twins.values() if len(v)>1]
ck('Only intended name-and-DOB duplicate is Lesley pair',len(duplicates)==1 and {r['applicant_id'] for r in duplicates[0]}=={'mc1052','mc1053'} and {r['sex'] for r in duplicates[0]}=={'female','male'} and {r['cohort'] for r in duplicates[0]}=={'eligible','ineligible'})
ck('Lesley remaining right hip plan retained','right hip replacement' in ALL['mc1053']['scheduled_surgery'] and '2027-05-18' in str(ALL['mc1053']['conditional_surgery_date']) and 'march' in call('mc1053','march')['what_was_discussed'])
ck('Lesley varied left hip date', '2027-03-23' in str(ALL['mc1053']['conditional_surgery_date']))
ck('Unfilled prescription callback explicit','never filled the tramadol' in call('mc1054','tramadol')['what_was_discussed'])
ck('Own ICD correction does not supply implant date','mine is an icd' in call('mc1055','icd')['what_was_discussed'] and ALL['mc1055']['conditional_explain_metal_in_body_date'] is None)
ck('Marker callback does not erase dated pacemaker','breast biopsy' in call('mc1056','marker')['what_was_discussed'] and 'pacemaker' in ALL['mc1056']['past_surgical_history'] and '2018-09-19' in str(ALL['mc1056']['conditional_past_surgical_history_date']))
finger=ALL['mc1057']
ck('Fingerplate insertion within fixed preceding year',dt.date(2026,10,30)<day(finger['conditional_past_surgical_history_date'])<=dt.date(2027,10,30))
ck('Fingerplate removal callback concise and linked','plate' not in call('mc1057','cancelled')['what_was_discussed'] and day(finger['conditional_surgery_date'])==dt.date(2027,9,27))
seq=[r for n,r in rows(B['history']['medications']) if r['applicant_id']=='mc-0271'];a,b=seq
ck('Historical phenelzine ends before sertraline starts',a['medications']=='phenelzine' and a['medication_duration_years']==6 and day(a['medication_stop_date'])==dt.date(2015,4,15) and b['medications']=='sertraline' and day(b['medication_start_date'])-day(a['medication_stop_date'])==dt.timedelta(days=19))
pos={r['applicant_id']:n for n,r in rows(B['demo'].active)}
ck('Two MC date requests widely separated',abs(pos['mc-0272']-pos['mc-0273'])>=200)
for id in ['mc-0272','mc-0273']:
    text=ALL[id]['visit_availability_notes'];ck(id+' concise first/MRI requests','holiday' in text and ('nov 2' in text or 'november 2' in text))
ck('Aug1-Nov2 request violates weekday and calendar interval',dt.date(2027,8,1).weekday()==6 and dt.date(2027,11,2)>=months(dt.date(2027,8,1),3))
epos={r['applicant_id']:n for n,r in rows(B['eligible']['applicants'])}
ck('Two runs of four ordinary people',all(epos['mc'+str(1060+i)]==9+i for i in range(4)) and all(epos['mc'+str(1064+i)]==37+i for i in range(4)))
ir=[r['applicant_id'] for n,r in rows(B['ineligible']['applicants'])]
ck('Two weekend ineligibles remain last with one apart',ir[-3:]==['mc1049','mc1050','mc-00am'])
ck('Lyle retained in applicant and call log',ALL['mc-0022']['name']=='lyle preston' and any(r['name']=='lyle preston' for r in cs))

# Solve all domains rather than merely checking the supplied answer.
PUZZLE=json.load(open(R/'couple_puzzle_key.json'));solutions=[]
domains=[list(product(p['v1'],p['mri'])) for p in PUZZLE]
for choices in product(*domains):
    vc=Counter();mc=Counter();ok=True
    for (v,m),p in zip(choices,PUZZLE):
        v=dt.date.fromisoformat(v);m=dt.date.fromisoformat(m)
        ok &= v.weekday()<5 and m.weekday() in [0,1,2,5] and v<m<months(v,3)
        vc[v]+=2;mc[m]+=2
    if ok and max(vc.values())<=2 and all(n<=(1 if d.weekday()==5 else 3) for d,n in mc.items()):solutions.append(choices)
ck('Couple domains have exactly one feasible solution',len(solutions)==1)
ck('Enumerated solution matches private key',solutions==[tuple((p['v1_solution'],p['mri_solution']) for p in PUZZLE)])
AP={r['applicant_id']:r for n,r in rows(B['eligible']['applicants'])};META={r['applicant_id']:r for r in json.load(open(R/'availability_constraints.json'))}
puzzleids={id for p in PUZZLE for id in [p['caller'],p['partner']]}
ck('No puzzle answers exposed as raw tentative dates',all(AP[id]['visit1_tentative_date']=='n/a' and AP[id]['mri_tentative_date']=='n/a' for id in puzzleids))
PROOF=readcsv(R/'capacity_witness.csv');vc=Counter();mc=Counter();badday=[];badavail=[]
for r in PROOF:
    id=r['applicant_id'];v=dt.date.fromisoformat(r['visit1']);m=dt.date.fromisoformat(r['mri']);e=META[id]
    vc[v]+=1;mc[m]+=1
    ck(id+' proposed window and strict calendar gap',dt.date(2027,1,1)<=v<=dt.date(2028,8,1) and dt.date(2027,10,31)<=m<=dt.date(2028,11,1) and v<m<months(v,3))
    ck(id+' weekday visit1',v.weekday()<5)
    if m.weekday() not in [0,1,2,5]:badday.append(id)
    for visit,d in [('visit1',v),('mri',m)]:
        if blocked(e,d):badavail.append((id,visit))
    if id not in puzzleids:ck(id+' witness agrees with raw proposal',day(AP[id]['visit1_tentative_date'])==v and day(AP[id]['mri_tentative_date'])==m)
ck('Whole roster plus puzzle fits visit1 max2 and MRI3/Saturday1',max(vc.values())<=2 and all(n<=(1 if d.weekday()==5 else 3) for d,n in mc.items()))
ck('Only intended Thursday MRI error remains',badday==['mc1051'],str(badday))
ck('Only intended birthday availability error remains',badavail==[('mc1005','visit1')],str(badavail))
holds=[id for id,r in AP.items() if id not in puzzleids and not isinstance(day(r['visit1_tentative_date']),dt.date)]
ck('Exactly eight source/weekend unresolved holds',len(holds)==8,str(holds))
for id in holds:
    if META[id]['weekend_only']:ck(id+' weekend PI note','contact pi' in AP[id]['visit1_tentative_date'])
ck('Capacity witness includes all others',len(PROOF)==60 and len({r['applicant_id'] for r in PROOF})==60)

# Re-index the seven original spouse calls; new constrained callbacks supersede
# earlier flexibility only for the three puzzle couples.
J=readcsv(OLD/'joint_visit_requests.csv')
for j in J:
    matches=[(n,r) for n,r in CALLS if r.get('applicant_id')==j['caller_id'] and str(day(r['date_of_call']))==j['call_date'] and j['partner_name'] in r['what_was_discussed']]
    ck(j['caller_id']+' spouse call still caller-only',len(matches)==1)
    j['call_row']=matches[0][0]
    if j['caller_id'] in {p['caller'] for p in PUZZLE}:j['review_action']='later april callback narrows joint availability; use three-couple domains'
ck('Seven distinct spouse requests retained',len(J)==7 and len({frozenset([j['caller_id'],j['partner_id']]) for j in J})==7)
csvout('joint_visit_requests.csv',J)

KEY=readcsv(OLD/'case_key.csv')
extras=[
('mc1052 / mc1053','same name and dob; different IDs and sexes','keep two distinct people in different cohorts','female lesley is otherwise eligible. male lesley has a remaining may18 hip implantation plan. sex itself is not an exclusion; do not merge by name and dob.'),
('mc1054','tramadol prescription never dispensed or started','followup concern resolved; eligible if remaining checks clear','jan19 callback means tramadol was not being taken with sertraline. reconcile historical prescribed list with actual use; do not mark the initial prescription as confirmed exposure.'),
('mc-0271','phenelzine six-year course then sertraline','otherwise eligible; no simultaneous maoi/ssri exposure established','phenelzine2009-04-15 through2015-04-15; sertraline starts2015-05-04. explicit stop date and19-day gap prevent a false concurrent-interaction flag.'),
('mc1055','caller read wife pacemaker card; own device icd','remain followup until own implantation date verified','wife device must not be attributed to him. no own implant date supplied, so pre/post2000 criterion remains unresolved.'),
('mc1056','breast-marker clarification; dated pacemaker still present','ineligible under nis pacemaker policy','callback resolves marker site/pathology only; dated2018 pacemaker is independently documented in surgery history. do not erase it or let the marker exception clear everything.'),
('mc1053','march left hip cancelled; may right hip remains','remain ineligible under scheduled-implantation rule','two distinct operations; march23 cancellation does not cancel right hip plannedmay18,2027.'),
('mc1057','september27 fingerplate removal cancelled','waitlist to ineligible on current facts for this phase','plate insertednov18,2026 inside fixed12month period. callback cancels its planned removal. no replacement removal plan documented; do not invent one or claim no future plan could ever change status.'),
('mc-0272 / mc-0273','widely separated aug1 / nov2 requests','discuss alternatives; PI if weekend needed; do not silently book requested pair','aug1,2027 is sunday; nov2 is3calendar months1day later. preferences are requests rather than explicit refusal of every alternative, so do not infer categorical clinical ineligibility.'),
('mc1001 / mc1002','couple a restricted joint dates','both visit1aug3,2027 and mrinov2,2027','couple b consumesaug2/nov1; then couple a forcescouple c toaug4/nov3. answer omitted from raw proposed-date cells.'),
('mc1010 / mc1009','couple b only one joint option','both visit1aug2,2027 and mrinov1,2027','two people consume both visit1 slots. each couple counts as two at MRI; cannot place two couples on one date with capacity3.'),
('mc1017 / mc1018','couple c constrained by other two couples','both visit1aug4,2027 and mrinov3,2027','all three solution intervals are91days yet strictly less than3calendar months; do not substitute90days.'),
('mc1060-mc1067','two short ordinary stretches','eligible if no new information; honor individual unavailability','eight straightforward applicants provide ordinary runs among dispersed challenges. no clinical exclusions deliberately added.')]
KEY += [dict(zip(['id','case','expected','details'],x)) for x in extras]
csvout('case_key.csv',KEY)
for name,data in [('final_validation.csv',CHECK),('clinical_coverage.csv',COVER),('all_applicants_roster.csv',ROSTER),('source_missing_fields.csv',MISSING),('call_identity_audit.csv',CALLAUDIT),('change_audit.csv',CHANGES)]:csvout(name,data)
manifest=json.load(open(R/'build_manifest.json'));manifest.update(validation_pass=sum(x['result']=='pass' for x in CHECK),validation_fail=sum(x['result']=='fail' for x in CHECK),couple_solutions=len(solutions),calls=len(cs));json.dump(manifest,open(R/'build_manifest.json','w'),indent=2)

w=openpyxl.Workbook();w.remove(w.active)
tabs=[('case key','case_key.csv'),('added people','new_applicants.csv'),('spouse requests','joint_visit_requests.csv'),('joint date examples','joint_date_examples.csv'),('tentative date review','tentative_date_review.csv'),('capacity proof','capacity_witness.csv'),('roster','all_applicants_roster.csv'),('clinical coverage','clinical_coverage.csv'),('validation','final_validation.csv'),('source changes','change_audit.csv'),('missing data','source_missing_fields.csv'),('call identity','call_identity_audit.csv'),('source files','source_files.csv')]
for title,name in tabs:
    s=w.create_sheet(title)
    for row in csv.reader(open(R/name,encoding='utf-8-sig')):s.append(row)
    s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
    for c in s[1]:c.font=Font(bold=True,color='ffffff');c.fill=PatternFill('solid',fgColor='17365d')
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width=46
        for c in col:c.alignment=Alignment(wrap_text=True,vertical='top')
w.save(R/'challenge_review.xlsx')
assert all(c['result']=='pass' for c in CHECK),[c for c in CHECK if c['result']=='fail']
print('Validation',Counter(c['result'] for c in CHECK),'people',len(ALL),'calls',len(cs),'unique puzzle solutions',len(solutions))
