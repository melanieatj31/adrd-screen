"""Dates follow the latest corrected manual: visit1 through2028-08-01, MRI less than3calendar months later."""
from pathlib import Path
from collections import Counter
import datetime,json,openpyxl,csv,calendar
P=Path(__file__).parent;I=P/'inputs';R=P/'reviewer'
V1START=datetime.date(2027,1,1);V1END=datetime.date(2028,8,1);MRI_START=datetime.date(2027,10,31);MRI_END=datetime.date(2028,11,1)
M=json.load(open(R/'availability_constraints.json'));byid={e['applicant_id']:e for e in M}
def h(s):return [c.value for c in s[1]]
def rows(s):return [(n,dict(zip(h(s),r))) for n,r in enumerate(list(s.values)[1:],2)]
def setv(s,n,k,v):s.cell(n,h(s).index(k)+1,datetime.datetime.combine(v,datetime.time()) if isinstance(v,datetime.date) else v)
def months(d,n):
 m=d.year*12+d.month-1+n;y,m=divmod(m,12);return datetime.date(y,m+1,min(d.day,calendar.monthrange(y,m+1)[1]))
def blocked(e,d):
 md=d.strftime('%m-%d')
 if d.weekday() in e['blocked_weekdays'] or md in e['blocked_month_days']:return True
 for b in e['blocked_ranges']:
  if b['start']<=b['end'] and b['start']<=md<=b['end']:return True
  if b['start']>b['end'] and (md>=b['start'] or md<=b['end']):return True
 return False
extra={'mc1001':['06-09'],'mc1006':['02-22'],'mc1021':['04-16'],'mc1028':['06-23'],'mc1009':['05-04'],'mc1010':['11-25','11-26']}
for id,ds in extra.items():byid[id]['blocked_month_days']=sorted(set(byid[id]['blocked_month_days']+ds))
for id,b in [('mc1003',{'start':'07-12','end':'07-18'}),('mc1014',{'start':'03-08','end':'03-12'}),('mc1032',{'start':'11-01','end':'12-31'}),('mc-00ai',{'start':'09-01','end':'11-30'})]:
 if b not in byid[id]['blocked_ranges']:byid[id]['blocked_ranges'].append(b)
for e in M:e['blocked_ranges']=list({(x['start'],x['end']):x for x in e['blocked_ranges']}.values())
SOURCE_HOLDS={'mc-00ad':('contact pi','travel covers the first mri phase; return uncertain'),
 'mc-00ag':('contact pi','planned2027-11-02 knee implantation cannot meet first-phase mri and strict3month gap within visit1 data window'),
 'mc1029':('hold','caller away at least6months from2026-12-14 and will call on return'),
 'mc1030':('contact first','bereavement caller requests recontact next year before scheduling')}
w=openpyxl.load_workbook(I/'ADRD_Study_Eligibility_List.xlsx');s=w['applicants'];v1cap=Counter();mricap=Counter();DATES=[]
# Reserve deliberate test fixtures before allocating ordinary proposed dates.
fixtures={'mc1005':(datetime.date(2027,8,20),datetime.date(2027,11,3),'birthday-blocked visit1'),
 'mc1051':(datetime.date(2027,10,28),datetime.date(2027,11,4),'thursday mri')}
for id,(v,m,label) in fixtures.items():v1cap[v]+=1;mricap[m]+=1
for n,r in rows(s):
 id=r['applicant_id'];e=byid[id]
 if id in SOURCE_HOLDS:
  label,why=SOURCE_HOLDS[id];setv(s,n,'visit1_tentative_date',label);setv(s,n,'mri_tentative_date',label);DATES.append({'applicant_id':id,'visit1':label,'mri':label,'fixture':why});continue
 if e['weekend_only']:
  setv(s,n,'visit1_tentative_date','contact pi: weekend');setv(s,n,'mri_tentative_date','contact pi');DATES.append({'applicant_id':id,'visit1':'contact pi: weekend','mri':'contact pi','fixture':'weekend accommodation unresolved'});continue
 if id in fixtures:v,m,label=fixtures[id]
 else:
  label='baseline candidate; recheck classification and joint requests against calls'
  m=MRI_START;v=None
  while m<=MRI_END:
   if m.weekday() in [0,1,2,5] and (m.month,m.day) not in [(1,1),(12,25)] and mricap[m]<(1 if m.weekday()==5 else 3) and not blocked(e,m):
    d=max(V1START,months(m,-3))
    while d<min(m,V1END+datetime.timedelta(days=1)):
     if d.weekday()<5 and v1cap[d]<2 and not blocked(e,d) and m<months(d,3):v=d;break
     d+=datetime.timedelta(days=1)
    if v:break
   m+=datetime.timedelta(days=1)
  if v is None:raise RuntimeError('No compatible proposed dates',id)
  v1cap[v]+=1;mricap[m]+=1
 if not(V1START<=v<=V1END and v<m<months(v,3) and MRI_START<=m<=MRI_END):raise RuntimeError('Window/gap invalid',id,v,m)
 setv(s,n,'visit1_tentative_date',v);setv(s,n,'mri_tentative_date',m)
 DATES.append({'applicant_id':id,'visit1':v.isoformat(),'mri':m.isoformat(),'fixture':label})
assert max(v1cap.values())<=2
w.save(I/'ADRD_Study_Eligibility_List.xlsx')
# Original weekend-request challenge remains in2027, in notes only.
f=I/'ADRD_Study_Ineligibility_List.xlsx';w=openpyxl.load_workbook(f);s=w['applicants']
for n,r in rows(s):
 id=r['applicant_id'];e=byid[id]
 if id=='mc1049':e['notes']='my reception shifts run monday to friday. i asked for visit 1 on oct 23. contact pi.'
 if id=='mc-00am':e['notes']='weekdays are school days for me. sunday 10-24 is when i asked to come for visit 1. contact pi.'
 setv(s,n,'visit_availability_notes',e['notes'].lower())
w.save(f)
json.dump(M,open(R/'availability_constraints.json','w'),indent=2)
with open(R/'tentative_date_review.csv','w',newline='',encoding='utf-8-sig') as f:
 cw=csv.DictWriter(f,fieldnames=list(DATES[0]));cw.writeheader();cw.writerows(DATES)
manifest=json.load(open(R/'build_manifest.json'));manifest.update(status='latest corrected manual applied',visit1_window=['2027-01-01','2028-08-01'],mri_window=['2027-10-31','2028-11-01'],maximum_intervisit_gap='strictly less than3calendar months',manual_enrollment='2027-01-01 to2027-10-30');manifest.pop('visit1_deadline',None)
json.dump(manifest,open(R/'build_manifest.json','w'),indent=2)
print('Applied corrected manual: visit1 through2028-08-01, strict gap<3calendar months; known fixtures retained.')
