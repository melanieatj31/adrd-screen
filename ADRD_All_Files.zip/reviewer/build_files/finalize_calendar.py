"""Allocate provisional ordinary dates while keeping the three-couple answer private."""
from pathlib import Path
from collections import Counter
import csv, json, calendar, datetime as dt, openpyxl

P=Path(__file__).parent; I=P/'inputs'; R=P/'reviewer'
VSTART=dt.date(2027,1,1); VEND=dt.date(2028,8,1)
MSTART=dt.date(2027,10,31); MEND=dt.date(2028,11,1)
META=json.load(open(R/'availability_constraints.json'))
WEEKDAYS={name.lower():i for i,name in enumerate(calendar.day_name)}
for e in META:
    e['blocked_weekdays']=[WEEKDAYS[x] if isinstance(x,str) else x for x in e['blocked_weekdays']]
BYID={e['applicant_id']:e for e in META}

def months(d,n):
    y,m=divmod(d.year*12+d.month-1+n,12)
    return dt.date(y,m+1,min(d.day,calendar.monthrange(y,m+1)[1]))

def blocked(e,d):
    md=d.strftime('%m-%d')
    return d.weekday() in e['blocked_weekdays'] or md in e['blocked_month_days'] or any(
        b['start']<=md<=b['end'] if b['start']<=b['end'] else md>=b['start'] or md<=b['end']
        for b in e['blocked_ranges'])

def rows(s):
    keys=[c.value for c in s[1]]
    return [(n,dict(zip(keys,r))) for n,r in enumerate(list(s.values)[1:],2)]

def csvout(name,rs):
    with open(R/name,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0])); w.writeheader(); w.writerows(rs)

PUZZLE=json.load(open(R/'couple_puzzle_key.json'))
PUZZLEIDS={id for p in PUZZLE for id in [p['caller'],p['partner']]}
HOLDS={
    'mc-00ad':('contact pi','travel covers first mri phase; return uncertain'),
    'mc-00ag':('contact pi','planned knee implantation makes phase1 infeasible as planned'),
    'mc1029':('hold','away at least six months; return not confirmed'),
    'mc1030':('contact first','bereavement; recontact before scheduling')}
FIXTURES={
    'mc1005':(dt.date(2027,8,20),dt.date(2027,11,3),'intentional birthday blackout violation'),
    'mc1051':(dt.date(2027,10,28),dt.date(2027,11,4),'intentional thursday mri staffing violation')}
VCOUNT=Counter(); MCOUNT=Counter(); PROOF=[]; PAIRS=[]

def reserve(ids,v,m,kind):
    VCOUNT[v]+=len(ids); MCOUNT[m]+=len(ids)
    for id in ids:PROOF.append({'applicant_id':id,'visit1':v.isoformat(),'mri':m.isoformat(),'basis':kind})

for p in PUZZLE:
    v=dt.date.fromisoformat(p['v1_solution']); m=dt.date.fromisoformat(p['mri_solution'])
    reserve([p['caller'],p['partner']],v,m,'reviewer-only puzzle solution; raw dates intentionally blank')
    PAIRS.append({'caller_id':p['caller'],'partner_id':p['partner'],'shared_visit1':v.isoformat(),'shared_mri':m.isoformat(),'basis':'unique constrained solution, reviewer only'})
for id,(v,m,label) in FIXTURES.items():reserve([id],v,m,label)

def allocate(ids):
    m=MSTART
    while m<=MEND:
        cap=1 if m.weekday()==5 else 3
        if m.weekday() in [0,1,2,5] and MCOUNT[m]+len(ids)<=cap and all(not blocked(BYID[id],m) for id in ids):
            v=max(VSTART,months(m,-3))
            while v<min(m,VEND+dt.timedelta(days=1)):
                if v.weekday()<5 and VCOUNT[v]+len(ids)<=2 and m<months(v,3) and all(not blocked(BYID[id],v) for id in ids):
                    reserve(ids,v,m,'provisional, subject to clinical and call reconciliation')
                    return v,m
                v+=dt.timedelta(days=1)
        m+=dt.timedelta(days=1)
    raise RuntimeError('no feasible provisional pair',ids)

# Two other clear spouse pairs also receive shared provisional dates. The two
# remaining couples need safety clearance or PI accommodation before booking.
JOINT={}
for ids in [('mc1011','mc1014'),('mc1013','mc1016')]:
    v,m=allocate(ids)
    for id in ids:JOINT[id]=(v,m)
    PAIRS.append({'caller_id':ids[0],'partner_id':ids[1],'shared_visit1':v.isoformat(),'shared_mri':m.isoformat(),'basis':'conditional shared proposal; verify clearance and availability'})

w=openpyxl.load_workbook(I/'ADRD_Study_Eligibility_List.xlsx'); s=w['applicants']
headers=[c.value for c in s[1]]; DATES=[]
for n,r in rows(s):
    id=r['applicant_id']; e=BYID[id]
    if id in PUZZLEIDS:
        v=m='n/a'; label='three-couple puzzle; solve from availability and caller request'
    elif id in HOLDS:
        v,why=HOLDS[id]; m=v; label=why
    elif e['weekend_only']:
        v='contact pi: weekend'; m='contact pi'; label='weekend accommodation unresolved'
    elif id in FIXTURES:
        v,m,label=FIXTURES[id]
    elif id in JOINT:
        v,m=JOINT[id]; label='shared provisional dates for other clear spouse pair'
    else:
        v,m=allocate([id]); label='provisional; reconcile clinical status and latest calls'
    for key,val in [('visit1_tentative_date',v),('mri_tentative_date',m)]:
        c=s.cell(n,headers.index(key)+1,val)
        if isinstance(val,dt.date):c.number_format='yyyy-mm-dd'
    DATES.append({'applicant_id':id,'visit1':str(v),'mri':str(m),'fixture':label})
w.save(I/'ADRD_Study_Eligibility_List.xlsx')
assert max(VCOUNT.values())<=2
assert all(n<=(1 if day.weekday()==5 else 3) for day,n in MCOUNT.items())
json.dump(META,open(R/'availability_constraints.json','w'),indent=2)
csvout('tentative_date_review.csv',DATES)
csvout('capacity_witness.csv',PROOF)
csvout('joint_date_examples.csv',PAIRS)
manifest=json.load(open(R/'build_manifest.json'))
manifest.update(visit1_window=[str(VSTART),str(VEND)],mri_window=[str(MSTART),str(MEND)],maximum_intervisit_gap='strictly less than 3 calendar months',manual_enrollment='2027-01-01 to 2027-10-30',puzzle_answers_in_raw_inputs=False)
json.dump(manifest,open(R/'build_manifest.json','w'),indent=2)
print('Provisional dates allocated:',len(PROOF),'people including six private puzzle reservations; max visit1',max(VCOUNT.values()),'max MRI',max(MCOUNT.values()))
