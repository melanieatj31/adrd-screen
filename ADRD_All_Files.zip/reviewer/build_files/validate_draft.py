from pathlib import Path
from collections import Counter
import openpyxl,json,csv,datetime,re
P=Path(__file__).parent;I=P/'inputs';R=P/'reviewer';checks=[]
def ck(name,v,detail=''):
 checks.append({'check':name,'result':'pass' if v else 'fail','detail':detail})
 if not v:print('FAIL',name,detail)
def h(s):return [c.value for c in s[1]]
def rows(s):return [dict(zip(h(s),r)) for r in list(s.values)[1:]]
B={f.name:openpyxl.load_workbook(f,data_only=True) for f in I.glob('*.xlsx')};allids=[]
for f,w in B.items():
 for s in w:
  ck(f+'!'+s.title+' lowercase entries',all(not isinstance(v,str) or v.startswith('=') or v==v.lower() for r in s.values for v in r))
  ck(f+'!'+s.title+' no old availability heading','mri_availability_notes' not in h(s))
  ck(f+'!'+s.title+' concise device descriptions',all(not isinstance(v,str) or not re.search(r'\btemporary\b|\bpermanent\b|\bpermanant\b|with metal components|not assessed yet',v) for r in list(s.values)[1:] for v in r))
 if f.startswith('ADRD_Study_'):
  apps=[r for r in rows(w['applicants']) if r.get('applicant_id')];ids=[r['applicant_id'] for r in apps];allids+=ids
  ck(f+' unique applicant IDs',len(ids)==len(set(ids)))
  for sh in ['diagnoses','medications','surgery_history']:ck(f+'!'+sh+' exact applicant coverage',{r['applicant_id'] for r in rows(w[sh]) if r.get('applicant_id')}==set(ids))
  if 'Eligibility' not in f:ck(f+' no tentative columns',all('tentative' not in str(v) for s in w for v in h(s)))
  else:ck(f+' both visit date columns',{'visit1_tentative_date','mri_tentative_date'}<=set(h(w['applicants'])))
 if f=='applicant_demographics.xlsx':allids += [r['applicant_id'] for r in rows(w.active) if r.get('applicant_id')]
ck('352 unique people retained plus new eligible',len(allids)==len(set(allids))==352)
M=json.load(open(R/'availability_constraints.json'))
for g in ['eligibility','ineligibility','followup','wait','mc']:
 es=[e for e in M if e['group']==g];ct=Counter(e['role'] for e in es if e['role'])
 ck(g+' each requested role at most twice',all(n<=2 for n in ct.values()),str(dict(ct)))
 ck(g+' all weekend requests flag pi',all('contact pi' in e['notes'] for e in es if e['weekend_only']))
e=next(r for r in rows(B['ADRD_Study_Eligibility_List.xlsx']['applicants']) if r['applicant_id']=='mc1008')
ck('requested dangerous combination and diagnoses',all(t in e['medications'] for t in ['hydrocodone','xanax','escitalopram','bupropion']) and all(t in e['diagnoses'] for t in ['bipolar','anxiety','ptsd','insomnia','hypertension','diabetes','addiction']))
ass=B['mindcrowd_assessment_other.xlsx'];med=B['past_medical_and_surgical_history.xlsx']
get=lambda s,id:[r for r in rows(s) if r.get('applicant_id')==id]
ck('ad yes with mc92 and none history',get(ass['other_questions'],'mc-0262')[0]['ad_diagnosis']=='yes' and get(ass['mindcrowd_assessment'],'mc-0262')[0]['mc_score']==92 and get(med['medical_history'],'mc-0262')[0]['diagnoses']=='none' and get(med['medications'],'mc-0262')[0]['medications']=='none')
stim=[r for r in rows(med['surgery_clearance']) if 'spinal cord stimulator' in str(r.get('past_surgical_history'))]
ck('one mc spinal stimulator without future surgery clue',len(stim)==1 and stim[0]['scheduled_surgery']=='no')
ck('generic iud has no explanatory type qualifier',get(med['surgery_clearance'],'mc-0099')[0]['past_surgical_history']=='iud')
cs=rows(B['ADRD_Call_Log.xlsx'].active)
husband=[(i,r) for i,r in enumerate(cs) if r.get('applicant_id')=='mc1008' and 'corinne fairchild' in str(r.get('what_was_discussed'))]
wife=[(i,r) for i,r in enumerate(cs) if r.get('applicant_id')=='mc1007' and 'did i qualify' in str(r.get('what_was_discussed'))]
ck('wife own callback many entries below husband',len(husband)==len(wife)==1 and wife[0][0]-husband[0][0]>=8 and wife[0][1]['date_of_call']>husband[0][1]['date_of_call'])
ck('withdrawal wife report only under husband',all('corinne fairchild' not in str(r.get('what_was_discussed')) or r.get('applicant_id')=='mc1008' for r in cs))
ck('husband later reconsents',any(r.get('applicant_id')=='mc1008' and 'changed my mind' in str(r.get('what_was_discussed')) and r['date_of_call']>husband[0][1]['date_of_call'] for r in cs))
ix=rows(B['ADRD_Study_Ineligibility_List.xlsx']['applicants'])
ck('weekend cases tail with one person between',[r['applicant_id'] for r in ix[-3:]]==['mc1049','mc1050','mc-00am'])
ck('birthday requests omit year',all(not re.search(r'\b(?:19|20)\d{2}\b',r['what_was_discussed']) for r in cs if r.get('applicant_id')=='mc1034'))
with open(R/'draft_validation.csv','w',newline='',encoding='utf-8-sig') as f:
 cw=csv.DictWriter(f,fieldnames=list(checks[0]));cw.writeheader();cw.writerows(checks)
print(Counter(x['result'] for x in checks));assert all(x['result']=='pass' for x in checks)
print('Core case/data checks complete. Calendar rules and deliberate exceptions checked separately.')
