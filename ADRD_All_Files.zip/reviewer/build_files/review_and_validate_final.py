from pathlib import Path
from collections import Counter,defaultdict
import csv,json,datetime,calendar,openpyxl,hashlib,re
from openpyxl.styles import Font,PatternFill,Alignment
P=Path(__file__).parent;I=P/'inputs';R=P/'reviewer'
def h(s):return [c.value for c in s[1]]
def rows(s):return [(n,dict(zip(h(s),r))) for n,r in enumerate(list(s.values)[1:],2)]
def readcsv(f):return list(csv.DictReader(open(f,encoding='utf-8-sig')))
def csvout(f,rs):
 with open(f,'w',newline='',encoding='utf-8-sig') as o:
  w=csv.DictWriter(o,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def d(x):return x.date() if isinstance(x,datetime.datetime) else x

def addmonths(x,n):
 y,m=divmod(x.year*12+x.month-1+n,12);return datetime.date(y,m+1,min(x.day,calendar.monthrange(y,m+1)[1]))
M=json.load(open(R/'availability_constraints.json'));meta={e['applicant_id']:e for e in M}
def blocked(e,x):
 md=x.strftime('%m-%d')
 if x.weekday() in e['blocked_weekdays'] or md in e['blocked_month_days']:return True
 return any((b['start']<=b['end'] and b['start']<=md<=b['end']) or (b['start']>b['end'] and (md>=b['start'] or md<=b['end'])) for b in e['blocked_ranges'])
CHECKS=readcsv(R/'draft_validation.csv')
def ck(label,yes,detail=''):
 CHECKS.append({'check':label,'result':'pass' if yes else 'fail','detail':detail})
 if not yes:print('FAIL',label,detail)
B={p.name:openpyxl.load_workbook(p,data_only=True) for p in I.glob('*.xlsx')}
EW=B['ADRD_Study_Eligibility_List.xlsx']['applicants'];AP={r['applicant_id']:r for n,r in rows(EW)}
V1=Counter();MRI=Counter();bad_avail=[];bad_days=[];holds=[]
for id,r in AP.items():
 v=d(r['visit1_tentative_date']);m=d(r['mri_tentative_date'])
 if not isinstance(v,datetime.date):holds.append(id);continue
 ck(id+' visit1 in corrected data window',datetime.date(2027,1,1)<=v<=datetime.date(2028,8,1))
 ck(id+' mri within phase',datetime.date(2027,10,31)<=m<=datetime.date(2028,11,1))
 ck(id+' strict under3calendar-month interval',v<=m<addmonths(v,3))
 ck(id+' weekday visit1',v.weekday()<5)
 V1[v]+=1;MRI[m]+=1
 if blocked(meta[id],v):bad_avail.append((id,'visit1',str(v)))
 if blocked(meta[id],m):bad_avail.append((id,'mri',str(m)))
 if m.weekday() not in [0,1,2,5]:bad_days.append((id,str(m)))
ck('Visit1 daily capacity at most2',max(V1.values())<=2)
ck('MRI daily capacity3; Saturday at most1',all(n<=(1 if x.weekday()==5 else 3) for x,n in MRI.items()))
ck('Only designated Thursday MRI fixture violates staffed days',bad_days==[('mc1051','2027-11-04')],str(bad_days))
ck('Only designated birthday fixture violates availability',bad_avail==[('mc1005','visit1','2027-08-20')],str(bad_avail))
ck('New person has valid Thursday visit1 and ThursdayMRI fixture',d(AP['mc1051']['visit1_tentative_date']).weekday()==3 and d(AP['mc1051']['mri_tentative_date']).weekday()==3)
ck('Birthday fixture date has matchingactualDOB monthday',d(AP['mc1005']['dob']).strftime('%m-%d')=='08-20')
ck('Weekend and source-call holds not assigned invented dates',len(holds)==8,str(holds))
ck('Osvaldo excludes both November and December',d(AP['mc1032']['mri_tentative_date']).month not in [11,12])
ck('Irma scheduled after source holiday with revised data window',d(AP['mc-00ai']['visit1_tentative_date'])>datetime.date(2027,11,30) and d(AP['mc-00ai']['mri_tentative_date'])>datetime.date(2027,11,30))
# All source unique IDs retained after lowercase normalization; only exact duplicate mc1046 removed.
paths=json.load(open(P/'source_paths.json'));source_ids=set();source_manifest=[]
for key,p in paths.items():
 src=Path(p);source_manifest.append({'file':src.name,'source_path':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
 ck(src.name+' original upload archived exactly',hashlib.sha256(src.read_bytes()).hexdigest()==hashlib.sha256((P/'original_sources'/src.name).read_bytes()).hexdigest())
 if key in ['eligible','ineligible','followup','wait','demographics']:
  w=openpyxl.load_workbook(src,data_only=True)
  for n,r in rows(w['applicants'] if 'applicants'in w.sheetnames else w.active):
   if r.get('applicant_id'):source_ids.add(str(r['applicant_id']).lower())
output_ids=set();ROSTER=[];coverage=[];missing=[]
for f,w in B.items():
 if f.startswith('ADRD_Study_') or f=='applicant_demographics.xlsx':
  s=w['applicants'] if 'applicants'in w.sheetnames else w.active
  for n,r in rows(s):
   if r.get('applicant_id'):
    output_ids.add(r['applicant_id']);ROSTER.append({'applicant_id':r['applicant_id'],'name':r['name'],'dob':str(d(r['dob'])),'file':f,'sheet':s.title,'row':n})
 if f.startswith('ADRD_Study_'):
  ids={r['applicant_id'] for n,r in rows(w['applicants']) if r.get('applicant_id')}
  for sh in ['diagnoses','medications','surgery_history']:
   hh=h(w[sh]);vals=[r for n,r in rows(w[sh]) if r.get('applicant_id')]
   coverage.append({'file':f,'sheet':sh,'applicants':len(ids),'covered_ids':len({r['applicant_id'] for r in vals}),'rows':len(vals)})
   ck(f+' '+sh+' all IDs represented',ids=={r['applicant_id'] for r in vals})
  # Nonreference applicant medication lines match the child names precisely.
  medmap=defaultdict(list)
  for n,r in rows(w['medications']):medmap[r['applicant_id']].append(r['medications'])
  for n,r in rows(w['applicants']):
   text=r.get('medications')
   if text and not str(text).startswith('see '):ck(r['applicant_id']+' concise medication names align',str(text).split('\n')==medmap[r['applicant_id']])
 for s in w:
  for n,r in rows(s):
   if any(v is not None for v in r.values()):
    for k,v in r.items():
     if v is None:missing.append({'file':f,'sheet':s.title,'row':n,'applicant_id':r.get('applicant_id'),'field':k,'status':'source missing or uncollected; not invented'})
ck('All351 source people retained plus Inez',source_ids<=output_ids and output_ids-source_ids=={'mc1051'} and len(output_ids)==352)
# Hip-date clue agrees across both raw baseline fields/child record; no third date left in note.
IW=B['ADRD_Study_Ineligibility_List.xlsx'];hip=next(r for n,r in rows(IW['applicants']) if r.get('applicant_id')=='mc-00ap')
ck('Hip baseline exactly2days before screening',d(hip['screening_date'])-d(hip['conditional_past_surgical_history_date'])==datetime.timedelta(days=2))
ck('Hip initial note contains no stale third date','2026-11-12' not in str(hip['initial_screening_notes']))
cs=rows(B['ADRD_Call_Log.xlsx'].active)
hipcall=next(r for n,r in cs if r.get('applicant_id')=='mc-00ap' and '1996' in str(r.get('what_was_discussed')))
ck('Hip correction same monthday1996', '6 december 1996' in hipcall['what_was_discussed'])
# Seven caller-only spouse requests, all linking two distinct existing eligible-list people.
J=readcsv(R/'joint_visit_requests.csv');ck('Exactly7requesters and7couples',len(J)==len({x['caller_id'] for x in J})==7 and len({frozenset([x['caller_id'],x['partner_id']]) for x in J})==7)
ck('All14partners present in eligibility workbook',len({x for j in J for x in [j['caller_id'],j['partner_id']]})==14 and all(j['caller_id'] in AP and j['partner_id'] in AP for j in J))
for j in J:
 row=next(r for n,r in cs if n==int(j['call_row']));ck(j['caller_id']+' request only under caller',row['applicant_id']==j['caller_id'] and j['partner_name'] in row['what_was_discussed'])
ck('Hydrocodone husband re-entry remains safety concern','hydrocodone/acetaminophen' in AP['mc1008']['medications'] and 'xanax' in AP['mc1008']['medications'])
# Lowercase and preserved formulas: original source formula cache remains numeric after writing.
hist=B['past_medical_and_surgical_history.xlsx'];fout=openpyxl.load_workbook(I/'past_medical_and_surgical_history.xlsx',data_only=False);fin=openpyxl.load_workbook(paths['history'],data_only=False)
original_formulas=[(s.title,c.coordinate,c.value) for s in fin for row in s for c in row if c.data_type=='f']
ck('All381originalformula definitions preserved',len(original_formulas)==381 and all(fout[sn][co].value==v for sn,co,v in original_formulas))
ck('All381formula results cached',all(hist[sn][co].value is not None for sn,co,v in original_formulas))
# Caller linking audit prevents an inquiry-only entry being treated as a new application.
CALLAUDIT=[]
for n,r in cs:
 id=r.get('applicant_id')
 status='inquiry/unlinked at time of call' if id in [None,'','n/a'] else 'existing applicant'
 if status=='existing applicant':ck('Caller row'+str(n)+' ID exists',id in output_ids)
 CALLAUDIT.append({'call_row':n,'caller_id':id,'caller_name':r['name'],'status':status})
ck('Lyle retained inapplication and source call',any(x['applicant_id']=='mc-0022' and x['name']=='lyle preston' for x in ROSTER) and any(r['name']=='lyle preston' for n,r in cs))
# Extend reviewer key for source restrictions retained from the uploaded data.
KEY=readcsv(R/'case_key.csv')
extra=[
('mc-00ag','scheduled knee replacement after recruitment; revised3month rule','phase1 infeasible as planned; clarify any changed surgery plan','earliest safe mri after nov2,2028 is outside mri phase and cannot be within3months of visit1 by aug1,2028.'),
('mc-00ad','travel and uncertain return cover mri window','clarify participation feasibility; no invented appointment','do not schedule before caller can return; retain reported travel.'),
('mc1029','six-month absence with no fixed return','hold until return/availability confirmed','six months is a lower bound, not a confirmed return date.'),
('mc1030','bereavement; call next year','contact first; do not treat as permanent withdrawal','no new visit agreed yet.'),
('mc1032','november-december unavailable','find mri outside those months and linked visit1 under3months','january2028 mri with october2027 visit1 can fit.'),
('mc-00ai','holiday sept1-nov30 inclusive','both visits after return if needed within corrected data window','do not confuse october2027 enrollment end with august2028 data-collection end.'),
('mc-00ae','explicit mri decline after explanation','ineligibility list, identified as decline','for final xlsx use a distinct decline/withdrawal fill; csv cannot retain cell colors.'),
('mc-00ah','scheduled deep brain stimulator','ineligible under scheduled implantation and mri requirements','do not treat current willingness as proof future mri is possible.'),
('mc-00af','past date described as future arthroscopy','followup to clarify procedure date and plan','source call says january5,2026 in december2026; this pre-existing source inconsistency is retained as a history question.'),
('mc1006','piercing removal refused','clarify device/material and facility requirements','do not assume all piercings are automatically allowed or absolutely contraindicated.'),
('mc1034','yearless birthday differs from recorded dob monthday','verify identity/date; respect stated avoidance date','the prior full-year callback wording was removed as requested.'),
('mc-0022','lyle source dob conflicts with caller','followup identity/dob clarification','preserve both source statements; do not choose a date or copy an older same-id identity.')]
KEY=[r for r in KEY if r['id'] not in {x[0] for x in extra}]+[dict(zip(['id','case','expected','details'],x)) for x in extra]
csvout(R/'case_key.csv',KEY)
# Conditional paired-date feasibility example for the five pairs without the new clearance/PI blocker.
clear=[j for j in J if j['caller_id'] not in ['mc1007','mc1004']];clearids={id for j in clear for id in [j['caller_id'],j['partner_id']]}
vcounts=Counter();mcounts=Counter()
for id,r in AP.items():
 if id in clearids:continue
 v=d(r['visit1_tentative_date']);m=d(r['mri_tentative_date'])
 if isinstance(v,datetime.date):vcounts[v]+=1;mcounts[m]+=1
PAIR=[]
for j in clear:
 x,y=j['caller_id'],j['partner_id'];m=datetime.date(2027,11,1);found=None
 while m<=datetime.date(2028,11,1):
  if m.weekday() in [0,1,2] and mcounts[m]<=1 and not blocked(meta[x],m) and not blocked(meta[y],m):
   v=max(datetime.date(2027,1,1),addmonths(m,-3))
   while v<min(m,datetime.date(2028,8,2)):
    if v.weekday()<5 and not(v.month==9 and v.day==6 and v.year==2027) and vcounts[v]==0 and not blocked(meta[x],v) and not blocked(meta[y],v) and m<addmonths(v,3):found=(v,m);break
    v+=datetime.timedelta(days=1)
   if found:break
  m+=datetime.timedelta(days=1)
 assert found,j
 v,m=found;vcounts[v]+=2;mcounts[m]+=2
 PAIR.append({'caller_id':x,'partner_id':y,'example_shared_visit1':v.isoformat(),'example_shared_mri':m.isoformat(),'status':'reviewer-only conditional capacity example; confirm individual clearance and actual availability'})
ck('Five clearer couples have capacity-feasible shared alternatives',len(PAIR)==5 and max(vcounts.values())<=2 and all(n<=(1 if x.weekday()==5 else 3) for x,n in mcounts.items()))
assert all(r['result']=='pass' for r in CHECKS),[r for r in CHECKS if r['result']=='fail']
for f,rs in [('final_validation.csv',CHECKS),('clinical_coverage.csv',coverage),('all_applicants_roster.csv',ROSTER),('source_files.csv',source_manifest),('source_missing_fields.csv',missing),('call_identity_audit.csv',CALLAUDIT),('joint_date_examples.csv',PAIR)]:csvout(R/f,rs)
# Reviewer-only workbook; never include it in the model's input-only ZIP.
w=openpyxl.Workbook();w.remove(w.active)
for title,f in [('case key','case_key.csv'),('spouse requests','joint_visit_requests.csv'),('joint date examples','joint_date_examples.csv'),('tentative dates','tentative_date_review.csv'),('roster','all_applicants_roster.csv'),('clinical coverage','clinical_coverage.csv'),('validation','final_validation.csv'),('change audit','change_audit.csv'),('missing source fields','source_missing_fields.csv'),('caller linking','call_identity_audit.csv')]:
 s=w.create_sheet(title)
 for row in csv.reader(open(R/f,encoding='utf-8-sig')):s.append(row)
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 for c in s[1]:c.font=Font(bold=True,color='ffffff');c.fill=PatternFill('solid',fgColor='17365d')
 for col in s.columns:
  s.column_dimensions[col[0].column_letter].width=48
  for c in col:c.alignment=Alignment(wrap_text=True,vertical='top')
w.save(R/'challenge_review.xlsx')
print('Final validation:',Counter(r['result'] for r in CHECKS))
print('Roster',len(ROSTER),'calls',len(cs),'paired requests',len(J),'V1date holds',len(holds),'intentional date fixtures',bad_days,bad_avail)
