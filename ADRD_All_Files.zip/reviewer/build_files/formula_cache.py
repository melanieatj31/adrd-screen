from pathlib import Path
import zipfile,copy,xml.etree.ElementTree as ET
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
F='{'+NS['s']+'}f';V='{'+NS['s']+'}v'
def restore_formula_cache(source,output):
 with zipfile.ZipFile(source) as src,zipfile.ZipFile(output) as dst:
  replacements={}
  for name in src.namelist():
   if not(name.startswith('xl/worksheets/sheet') and name.endswith('.xml')):continue
   sourcexml=ET.fromstring(src.read(name));formulas={c.attrib['r']:c for c in sourcexml.findall('.//s:c',NS) if c.find(F) is not None}
   if not formulas:continue
   outxml=ET.fromstring(dst.read(name))
   for c in outxml.findall('.//s:c',NS):
    if c.attrib['r'] not in formulas:continue
    orig=formulas[c.attrib['r']]
    for child in list(c):
     if child.tag in [F,V]:c.remove(child)
    c.insert(0,copy.deepcopy(orig.find(F)))
    if orig.find(V) is not None:c.append(copy.deepcopy(orig.find(V)))
    if 't' in orig.attrib:c.attrib['t']=orig.attrib['t']
    elif 't' in c.attrib:del c.attrib['t']
   replacements[name]=ET.tostring(outxml,encoding='utf-8',xml_declaration=True)
  if not replacements:return
  entries=[(info,dst.read(info.filename)) for info in dst.infolist()]
 temp=Path(str(output)+'.cache-restored')
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
  for info,data in entries:z.writestr(info,replacements.get(info.filename,data))
 temp.replace(output)
