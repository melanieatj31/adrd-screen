from pathlib import Path
from collections import defaultdict,Counter
import json,openpyxl,csv,datetime,re,hashlib,shutil
from openpyxl.styles import Font,PatternFill,Alignment
P=Path('/workspace/adrd-challenge-v4');I=P/'inputs';O=P/'original_sources';R=P/'reviewer'
for p in [I,O,R]:p.mkdir(exist_ok=True)
paths=json.load(open(P/'source_paths.json'));books={};AUDIT=[];CASE=[];BANK=json.load(open(P/'availability_bank.json'))['entries']
for key,p in paths.items():
 p=Path(p);shutil.copy2(p,O/p.name)
 if p.suffix=='.xlsx':books[key]=openpyxl.load_workbook(p,data_only=False)
 else:shutil.copy2(p,I/p.name)

def headers(ws):return [c.value for c in ws[1]]
def rows(ws):
 h=headers(ws);return [(n,dict(zip(h,r))) for n,r in enumerate(list(ws.values)[1:],2)]
def cell(ws,rn,k):return ws.cell(rn,headers(ws).index(k)+1)
def excel(x):
 if isinstance(x,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',x):return datetime.datetime.fromisoformat(x)
 return x

def append(ws,r):ws.append([excel(r.get(h,'n/a')) for h in headers(ws)]);return ws.max_row

def update(ws,rn,k,v,reason):
 c=cell(ws,rn,k);before=c.value;after=excel(v)
 if before!=after:AUDIT.append({'file':ws.parent._filename_tag,'sheet':ws.title,'cell':c.coordinate,'applicant_id':str(cell(ws,rn,'applicant_id').value) if 'applicant_id' in headers(ws) else '', 'field':k,'before':str(before),'after':str(after),'reason':reason});c.value=after

def byid(ws,id):
 matches=[(n,r) for n,r in rows(ws) if str(r.get('applicant_id','')).lower()==id]
 assert len(matches)==1,(ws.title,id,len(matches));return matches[0]
def setid(ws,id,k,v,reason):n,r=byid(ws,id);update(ws,n,k,v,reason)
def replace_id_rows(ws,id,newrows):
 for n,r in reversed(rows(ws)):
  if str(r.get('applicant_id','')).lower()==id:ws.delete_rows(n)
 for r in newrows:append(ws,{'applicant_id':id,**r})
for k,w in books.items():w._filename_tag=Path(paths[k]).name
# Rename availability fields everywhere; preserve original missing data, lowercase all raw entries.
for key,w in books.items():
 for ws in w:
  for c in ws[1]:
   if c.value=='mri_availability_notes':c.value='visit_availability_notes'
  if key=='calls' and ws.max_column==6 and ws.cell(1,6).value is None:ws.cell(1,6,'visit_availability_notes')
  for row in list(ws)[1:]:
   for c in row:
    if isinstance(c.value,str) and not c.value.startswith('='):
     old=c.value;v=old.strip().lower()
     if v.startswith('not supplied') or v.startswith('not assessed'):v=None
     else:
      v=re.sub(r'\b(?:temporary|permanent|permanant)\s+','',v)
      v=v.replace('with metal components','').replace('of unspecified type','').replace('; type not entered on questionnaire','').strip()
      if 'type not entered' in v:v=v.split(';')[0]
      if v=='hysteroscopy and mirena fitted':v='iud'
      if v=='levonorgestrel (mirena)':v='levonorgestrel'
      if c.column<=len(headers(ws)) and headers(ws)[c.column-1]=='medications':v='\n'.join(re.sub(r'\s+(?:as needed.*|weekly)$','',line).strip() for line in v.split('\n'))
     if v!=old:AUDIT.append({'file':w._filename_tag,'sheet':ws.title,'cell':c.coordinate,'applicant_id':str(ws.cell(c.row,1).value),'field':headers(ws)[c.column-1],'before':old,'after':str(v),'reason':'Concise lowercase exercise data; missing source information remains missing'});c.value=v
# Remove an exact duplicate supplied applicant row without removing the person.
fw=books['followup']['applicants'];seen={}
for n,r in reversed(rows(fw)):
 id=r.get('applicant_id')
 if not id:continue
 if id in seen:
  assert r==seen[id],('Nonidentical duplicate needs review',id)
  AUDIT.append({'file':fw.parent._filename_tag,'sheet':'applicants','cell':str(n),'applicant_id':id,'field':'row','before':'duplicate applicant row','after':'one retained applicant row','reason':'Identical supplied duplicate; person retained'})
  fw.delete_rows(n)
 else:seen[id]=r
# Only eligibility keeps tentative-date columns.
for key in ['followup','ineligible','wait']:
 ws=books[key]['applicants']
 for col in range(ws.max_column,0,-1):
  if 'tentative' in str(ws.cell(1,col).value).lower():ws.delete_cols(col)
ew=books['eligible']['applicants']
if 'visit1_tentative_date' not in headers(ew):ew.cell(1,ew.max_column+1,'visit1_tentative_date')
# Add one otherwise eligible person for the distinct Thursday visit/MRI scheduling challenge.
NEW={'applicant_id':'mc1051','name':'inez montrose','dob':'1953-10-27','sex':'female','race_ethnicity':'white','living_place':'sarasota, florida','language':'english (native)','screening_date':'2026-12-17','ad_diagnosis':'no','metal_in_body':'no','eye_injury':'no','metal_in_eye':'no','conditional_explain_metal_in_body':'n/a','conditional_eye_injury_agent':'n/a','conditional_metal_in_eye_removed':'n/a','mri_ability':'yes','dose':'n/a','past_surgical_history':'no','conditional_past_surgical_history_date':'n/a','assessment_date':'2026-12-16','mc_score':87,'completion_status':'completed','scheduled_surgery':'no','conditional_surgery_date':'n/a','diagnoses':'hyperlipidemia','diagnosis_date':'2015-02-09','medications':'rosuvastatin','medication_duration':11.8,'medication_start_date':'2015-02-20','conditional_explain_metal_in_body_date':'n/a','visit_availability_notes':'n/a','mri_tentative_date':'n/a','visit1_tentative_date':'n/a'}
assert not any(r.get('applicant_id')=='mc1051' for n,r in rows(ew));append(ew,NEW)
# Drug-safety husband; all raw medication cells contain medication names only.
DX=[('low back pain','2010-04-13'),('bipolar depression','2012-08-22'),('anxiety','2013-03-04'),('ptsd','2014-06-17'),('insomnia','2015-10-08'),('hypertension','2009-11-19'),('type 2 diabetes','2018-02-26'),('past pain pill addiction','2016-07-12'),('smoking','2011-01-24'),('plaque psoriasis','2022-04-13'),('history of left meniscal tear','2009-01-15')]
MED=[('hydrocodone/acetaminophen','2021-03-16'),('xanax','2020-09-29'),('escitalopram','2022-05-12'),('bupropion','2023-02-07'),('lamotrigine','2018-11-13'),('amlodipine','2009-12-03'),('metformin','2018-03-12'),('calcipotriene','2024-03-07')]
for k,v in {'diagnoses':'\n'.join(d for d,t in DX),'diagnosis_date':'\n'.join(t for d,t in DX),'medications':'\n'.join(d for d,t in MED),'medication_start_date':'\n'.join(t for d,t in MED),'medication_duration':'\n'.join(str(round((datetime.date(2026,12,8)-datetime.date.fromisoformat(t)).days/365.25,1))+' years' for d,t in MED)}.items():setid(ew,'mc1008',k,v,'Requested medication-safety and withdrawal/re-entry case')
# MC-only AD contradiction and spinal cord stimulator.
clinical=books['history'];assessment=books['assessment']
replace_id_rows(clinical['medical_history'],'mc-0262',[{'diagnoses':'none','diagnosis_date':'n/a'}])
replace_id_rows(clinical['medications'],'mc-0262',[{'medications':'none','medication_duration_years':'n/a','medication_start_date':'n/a','screening_date_yyyy_mm_dd':'2026-12-27'}])
setid(assessment['other_questions'],'mc-0262','ad_diagnosis','yes','Requested conflicting AD answer')
setid(assessment['mindcrowd_assessment'],'mc-0262','mc_score',92,'Requested completed MC score92')
replace_id_rows(clinical['surgery_clearance'],'mc-0261',[{'past_surgical_history':'spinal cord stimulator','conditional_past_surgical_history_date':'2021-07-14','scheduled_surgery':'no','conditional_scheduled_surgical_date':'n/a'},{'past_surgical_history':'cheek filler injections','conditional_past_surgical_history_date':'2026-11-26','scheduled_surgery':'no','conditional_scheduled_surgical_date':'n/a'}])
for k,v in {'metal_in_body':'yes','conditional_explain_metal_in_body':'spinal cord stimulator','conditional_explain_metal_in_body_date':'2021-07-14'}.items():setid(clinical['metal_clearance'],'mc-0261',k,v,'Requested MC-only stimulator case without future surgery clue')
# Hip-date correction: baseline appears two days before screening; a later call supplies1996.
iw=books['ineligible']['applicants'];screen=byid(iw,'mc-00ap')[1]['screening_date'].date();wrong=screen-datetime.timedelta(days=2)
for k in ['conditional_past_surgical_history_date','conditional_explain_metal_in_body_date']:setid(iw,'mc-00ap',k,wrong.isoformat(),'Requested hip operation year correction')
setid(iw,'mc-00ap','initial_screening_notes','recent hip replacement','Keep baseline note consistent with the deliberately incorrect hip date')
# The two ineligible weekend request cases will be last and separated by one other person.
records=[r for n,r in rows(iw) if r.get('applicant_id')];by={r['applicant_id']:r for r in records};tail=['mc1049','mc1050','mc-00am']
ordered=[r for r in records if r['applicant_id'] not in tail]+[by[x] for x in tail]
iw.delete_rows(2,iw.max_row-1)
for r in ordered:append(iw,r)
# Apply diverse, primarily hard-unavailability notes with role limits.
META=[];DOB_KEYS={}
for group,key,ws in [('eligibility','eligible',ew),('ineligibility','ineligible',iw),('followup','followup',fw),('wait','wait',books['wait']['applicants']),('mc','demographics',books['demographics'].active)]:
 entries=[(n,r) for n,r in rows(ws) if r.get('applicant_id')]
 bank=[e for e in BANK if e['list']==group];assert len(entries)==len(bank),(group,len(entries),len(bank))
 for (n,r),e in zip(entries,bank):
  e=dict(e);id=r['applicant_id'];e.update(applicant_id=id,group=group,file=ws.parent._filename_tag,sheet=ws.title,row=n)
  if 'my bday' in e['notes']:
   dob=r['dob'];md=dob.strftime('%B %-d').lower();e['notes']=f'my bday is on {md}. i do not want a visit on that day.';e['blocked_month_days']=[dob.strftime('%m-%d')]
  if e['weekend_only']:e['notes']+=' contact pi.'
  update(ws,n,'visit_availability_notes',e['notes'],'Varied concise unavailability; all-visit scope')
  META.append(e);DOB_KEYS[id]=r['dob']
# Only the intended two ineligibles retain explicit weekend requirements/visit1 requests.
for e in META:
 if e['group']=='ineligibility' and e['weekend_only']:
  e.update(role=None,weekend_only=False,blocked_weekdays=[],notes='i will be out of town 4-19 through 4-23.',blocked_ranges=[{'start':'04-19','end':'04-23'}],blocked_month_days=[])
for id,role,text in [('mc1049','weekday_worker','my reception shifts run monday to friday. i asked for visit 1 on {saturday}. contact pi.'),('mc-00am','school_teacher','weekdays are school days for me. sunday {sunday} is when i asked to come for visit 1. contact pi.')]:
 e=next(e for e in META if e['applicant_id']==id);e.update(role=role,weekend_only=True,blocked_weekdays=[0,1,2,3,4],notes=text,blocked_ranges=[],blocked_month_days=[])
# A hard birthday conflict, separate from the Thursday case.
e=next(e for e in META if e['applicant_id']=='mc1005');e.update(role=None,weekend_only=False,blocked_weekdays=[],blocked_ranges=[],blocked_month_days=['08-20'],notes="8-20 is my birthday. don't book a visit that day.")
# Preserve the original birthday discrepancy without putting a year in the birthday request.
e=next(e for e in META if e['applicant_id']=='mc1034');e['blocked_month_days']=sorted(set(e['blocked_month_days']+['11-03']))
# Refresh notes after targeted changes and synchronize duplicate MC availability fields.
for e in META:
 w=next(w for w in books.values() if w._filename_tag==e['file']);ws=w[e['sheet']];setid(ws,e['applicant_id'],'visit_availability_notes',e['notes'],'Availability fixture/PI flag')
for n,r in rows(assessment['other_questions']):
 e=next(e for e in META if e['group']=='mc' and e['applicant_id']==r['applicant_id']);update(assessment['other_questions'],n,'visit_availability_notes',e['notes'],'Consistent MC availability across exports')
# Scheduling-only existing callbacks are kept applicant-linked and made concise.
cs=books['calls'].active;names={r['applicant_id']:r['name'] for w in [ew,iw,fw,books['wait']['applicants']] for n,r in rows(w) if r.get('applicant_id')}
for n,r in rows(cs):
 id=r.get('applicant_id');text=str(r.get('what_was_discussed') or '')
 if id=='mc1034':update(cs,n,'what_was_discussed',"please don't book november 3. that's my birthday.",'Yearless birthday request; discrepancy remains against full DOB field')
 elif text.startswith('scheduling query only:') or (id in [f'mc{x}' for x in range(1029,1033)] and ('will be away' in text or 'contact me after' in text)):
  e=next((e for e in META if e['applicant_id']==id),None)
  if e:update(cs,n,'what_was_discussed',e['notes'].replace(' contact pi.',''),'Natural applicant availability callback')
 if 'visit_availability_notes' in headers(cs):
  extra=r.get('visit_availability_notes')
  if id=='mc1031' and extra:update(cs,n,'visit_availability_notes',"kids' recitals on 9/18/2028 and 11/6/2028.",'Retain supplied extra date note concisely')
  elif extra is None:update(cs,n,'visit_availability_notes','n/a','Unused optional call field')
# New calls: dates are provisional2027 until the required deadline clarification is resolved.
# Wife's withdrawal is reported ONLY under her husband; her own call is many entries later.
NEWCALLS=[
 ('mc1008','2027-01-12',"we've decided against it, me and my wife corinne fairchild."),
 ('mc1001','2027-01-15','please leave june 9 off my visit dates.'),
 ('mc1003','2027-01-17','i have booked a trip for 7-12 through 7-18.'),
 ('mc1006','2027-01-24','feb 22 is no good for me.'),
 ('mc1014','2027-01-28','away mar 8 to march 12, both days included.'),
 ('mc1021','2027-02-02','please keep 04/16 clear.'),
 ('mc1028','2027-02-07','my calendar is full on june 23.'),
 ('mc1011','2027-01-08','nothing else is booked. yes, i still want to take part.'),
 ('mc1011','2027-01-20','my hip replacement is booked for march 16.'),
 ('mc-00ap','2027-01-23',f"i found the discharge papers. my hip operation was {wrong.strftime('%-d %B').lower()} 1996, not last month."),
 ('mc1008','2027-02-15',"i changed my mind. i'd like to take part after all."),
 ('mc1009','2027-02-19','family funeral on may 4. please avoid that day.'),
 ('mc1010','2027-02-24','not here nov 25; 11-26 is out too.'),
 ('mc1007','2027-03-02',"did i qualify? i'm still waiting to hear when i can come."),
 ('mc1011','2027-02-04',"i cancelled the march operation. surgeon's office confirmed the cancellation.")]
for i,(id,d,text) in enumerate(NEWCALLS):append(cs,{'applicant_id':id,'name':names[id],'date_of_call':d,'what_was_discussed':text,'researcher_initials':['l.a.','s.n.','r.k.'][i%3],'visit_availability_notes':'n/a'})
# Rebuild/align the four supporting clinical tabs, preserving ID-linked existing histories unless an inline case was intentionally changed.
for key in ['eligible','ineligible','followup','wait']:
 w=books[key];apps=[r for n,r in rows(w['applicants']) if r.get('applicant_id')]
 for sheet in ['diagnoses','medications','surgery_history']:
  sh=w[sheet];existing=defaultdict(list)
  for n,r in rows(sh):
   if r.get('applicant_id'):existing[r['applicant_id']].append(r)
  out=[]
  for a in apps:
   id=a['applicant_id'];rebuild=id in ['mc1008','mc1051'] or (id=='mc-00ap' and sheet=='surgery_history')
   if id in existing and not rebuild:out+=existing[id];continue
   def ls(k):
    v=a.get(k)
    if v is None:return [None]
    if isinstance(v,str):return [s.strip() for s in v.split('\n')]
    return [v]
   if sheet=='diagnoses':
    vals=ls('diagnoses');dates=ls('diagnosis_date');assert len(vals)==len(dates)
    out += [{'applicant_id':id,'diagnoses':v,'diagnosis_date':dates[j]} for j,v in enumerate(vals)]
   elif sheet=='medications':
    vals=ls('medications');dates=ls('medication_start_date');dur=ls('medication_duration');assert len(vals)==len(dates)==len(dur)
    out += [{'applicant_id':id,'medications':v,'medication_start_date':dates[j],'medication_duration_years':float(str(dur[j]).replace(' years','')) if re.fullmatch(r'\d+(?:\.\d+)?(?: years)?',str(dur[j])) else dur[j]} for j,v in enumerate(vals)]
   else:out += [{'applicant_id':id,'past_surgical_history':a['past_surgical_history'],'conditional_past_surgical_history_date':a['conditional_past_surgical_history_date'],'scheduled_surgery':a['scheduled_surgery'],'conditional_scheduled_surgical_date':a['conditional_surgery_date']}]
  sh.delete_rows(2,sh.max_row-1)
  for r in out:append(sh,r)
# Eligibility dates remain unassigned until the contradictory year is clarified.
for n,r in rows(ew):
 if r.get('applicant_id'):
  update(ew,n,'visit1_tentative_date','n/a','Date assignment blocked on deadline clarification')
  update(ew,n,'mri_tentative_date','n/a','Recalculate linked two-visit schedule after deadline clarification')
# Input patient notes should never be confused with reviewer guidance.
for e in META:
 if e['weekend_only'] and 'contact pi' not in e['notes']:raise AssertionError(e)
for key,w in books.items():
 for ws in w:
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:
   if isinstance(c.value,str):c.value=c.value.lower()
   c.font=Font(bold=True,color='ffffff');c.fill=PatternFill('solid',fgColor='17365d');c.alignment=Alignment(wrap_text=True,vertical='top')
  for row in list(ws)[1:]:
   for c in row:
    if isinstance(c.value,str) and not c.value.startswith('='):c.value=c.value.lower()
    c.alignment=Alignment(wrap_text=True,vertical='top')
    if isinstance(c.value,(datetime.datetime,datetime.date)):c.number_format='yyyy-mm-dd'
  for t in ws.tables.values():t.ref=ws.dimensions
 w.save(I/Path(paths[key]).name)
# Preserve cached original formula results; unchanged source dates keep the same underlying values.
import sys
sys.path.insert(0,'/workspace/adrd-rebuilt-v2')
from formula_cache import restore_formula_cache
for key,w in books.items():restore_formula_cache(Path(paths[key]),I/Path(paths[key]).name)

def csvout(name,data):
 if not data:return
 with (R/name).open('w',newline='',encoding='utf-8-sig') as f:
  cw=csv.DictWriter(f,fieldnames=list(data[0]));cw.writeheader();cw.writerows(data)
CASES=[
 {'id':'mc1008','case':'hydrocodone and xanax; spouse withdrawal; later renewed interest','expected':'followup after re-entry: medication safety remains unresolved','details':'bupropion is not treated as established opioid-addiction therapy; nicotine dependence and bipolar depression are recorded. opioid/benzodiazepine combination needs clinical review.'},
 {'id':'mc1007','case':'wife mentioned by husband; later own inquiry','expected':'confirm her own intent; eligible if remaining criteria satisfied','details':'husband report does not itself establish wife voluntary withdrawal. no separate wife withdrawal call was fabricated.'},
 {'id':'mc-0262','case':'ad yes, no diagnoses/no medications, mc92','expected':'followup for direct contradiction','details':'high mc score and absent ad medication do not disprove ad. confirmed ad would exclude.'},
 {'id':'mc-0261','case':'spinal cord stimulator, no scheduled procedure','expected':'ineligible under nis neurostimulator policy','details':'mc only; implantation date does not override device exclusion.'},
 {'id':'mc-0099','case':'iud only','expected':'followup for device clarification if needed for mri safety review','details':'no type or uncertainty commentary supplied. no automatic eligibility or exclusion based on generic iud label.'},
 {'id':'mc-00ap','case':'hip surgery date corrected to same day/month1996','expected':'implant timing exclusion resolved after verification if otherwise eligible','details':'original incorrect date remains in baseline; call correction is applied during screening.'},
 {'id':'mc1011','case':'eligible to ineligible to eligible by dated calls','expected':'eligible if no other concerns after verified cancellation','details':'jan8 no surgery; jan20 planned march16 hip replacement; feb4 office-confirmed cancellation before surgery date.'},
 {'id':'mc1051','case':'new eligible person with thursday scheduling','expected':'thursday visit1 is allowed; thursday mri conflicts with adrd staffing','details':'the thursday mri conflicts with adrd staffing; a scheduling defect does not make the person clinically ineligible.'},
 {'id':'mc1005','case':'visit1 on prohibited birthday','expected':'reschedule visit1; do not alter clinical eligibility','details':'birthday request has month/day only.'},
 {'id':'mc1049','case':'saturday visit1 request near end of ineligibility list','expected':'retain clinical exclusion; weekend accommodation requires pi','details':'no tentative-date column outside eligibility; request is in notes.'},
 {'id':'mc-00am','case':'sunday visit1 request at end of ineligibility list','expected':'retain clinical exclusion; weekend accommodation requires pi','details':'one applicant between the two weekend cases.'}]
csvout('case_key.csv',CASES);csvout('change_audit.csv',AUDIT)
json.dump(META,open(R/'availability_constraints.json','w'),indent=2,default=str)
json.dump({'status':'draft: deadline clarification required','visit1_deadline':None,'manual_enrollment':'2027-01-01 to2027-10-30','manual_mri_window':'2027-10-31 to2028-11-01','counts':{'mc':250,'eligible':59,'ineligible':13,'followup':17,'wait':13},'duplicate_removed':'one exact extra mc1046 row; person retained'},open(R/'build_manifest.json','w'),indent=2)
print('Draft noncalendar edits complete. Calendar and publication remain blocked on visit1 deadline clarification.')
