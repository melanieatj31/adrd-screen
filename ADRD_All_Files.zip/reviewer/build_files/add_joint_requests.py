from pathlib import Path
import openpyxl,datetime,csv
P=Path(__file__).parent;I=P/'inputs';R=P/'reviewer';f=I/'ADRD_Call_Log.xlsx'
w=openpyxl.load_workbook(f);s=w.active;headers=[c.value for c in s[1]]
requests=[
 ('mc1007','corinne fairchild','mc1008','conrad whitfield','2027-03-12','can conrad whitfield and i come on the same dates for visit 1 and the mri?'),
 ('mc1001','zelda delaney','mc1002','zachary underwood','2027-03-15','my husband zachary underwood is on the list too. please put us together for both visits.'),
 ('mc1004','ambrose espinosa','mc1003','anita macias','2027-03-17',"i'd like to attend visit 1 with my wife anita macias, and have our scans on the same day as each other too."),
 ('mc1010','dominic galloway','mc1009','delphine ortega','2027-03-19','delphine ortega is my wife. could we share a day for the blood tests and ultrasound, then another day for our mris?'),
 ('mc1011','eunice yamamoto','mc1014','francisco zimmerman','2027-03-22',"please match my visit dates with my husband francisco zimmerman's, for the first visit as well as the scan."),
 ('mc1013','florence hawthorne','mc1016','gilbert ibarra','2027-03-25','my husband gilbert ibarra and i need to arrange transport together. same dates for visit 1 and visit 2, please.'),
 ('mc1017','helene aguirre','mc1018','hugo serrano','2027-03-29','hugo serrano, my husband, applied too. we would prefer to come as a couple for each of the two visits.')]
# Idempotent: remove only these exact seven previously inserted request texts.
texts={r[-1] for r in requests}
for n in range(s.max_row,1,-1):
 if s.cell(n,headers.index('what_was_discussed')+1).value in texts:s.delete_rows(n)
key=[]
for j,(id,name,partner,pname,d,text) in enumerate(requests):
 row={'applicant_id':id,'name':name,'date_of_call':datetime.datetime.fromisoformat(d),'what_was_discussed':text,'researcher_initials':['r.k.','l.a.','s.n.'][j%3],'visit_availability_notes':'n/a'}
 s.append([row.get(h,'n/a') for h in headers])
 status='joint planning requires medication-safety clearance for husband' if id=='mc1007' else 'pi accommodation needed for weekday restriction; cannot scan both partners on saturday under nis cap1' if id=='mc1004' else 'find common dates for both visits after individual eligibility review'
 key.append({'caller_id':id,'caller_name':name,'partner_id':partner,'partner_name':pname,'call_row':s.max_row,'call_date':d,'request':'same visit1 date and same visit2 date','review_action':status})
s.auto_filter.ref=s.dimensions;w.save(f)
with open(R/'joint_visit_requests.csv','w',newline='',encoding='utf-8-sig') as f:
 cw=csv.DictWriter(f,fieldnames=list(key[0]));cw.writeheader();cw.writerows(key)
print('Added exactly7 caller-linked joint requests, identifying14 existing applicants.')
