# Corrected ADRD expanded dataset — version2

This package supersedes the earlier expansion. The user confirmed that the participant information is synthetic. It is rebuilt from the ten files most recently supplied by the user, rather than the earlier source versions.

## Lyle Preston is preserved

- inputs/applicant_demographics.xlsx, applicant_demographics row2: mc-0022, Lyle Preston, DOB1963-06-12.
- inputs/ADRD_Call_Log.xlsx, call_log row24: Lyle Preston, no linked applicant ID, DOB1971-06-12 and age55 reported.

Both entries remain exactly as supplied. The date/identity discrepancy is a deliberate source challenge requiring follow-up. Do not silently change his DOB, equate same-name records without verification, or exclude him solely by choosing the caller DOB. If the call is confirmed to be his and1971 is correct, the age criterion would fail; if1963 is confirmed, age alone would not exclude. Other study and safety criteria still apply.

The previously supplied source used the same mc-0022 ID for Robert Caldwell. That older identity is NOT transferred into this package. No source cells in the current ten-file set were edited to match that older version.

## What is in each folder

- original_sources: exact byte-for-byte copies of all ten files supplied for this rebuild, including the call log under its original filename ADRD_Call_Log not this onw.xlsx.
- inputs: the eight expanded XLSX workbooks and the two current manuals. The supplied call workbook is canonically named ADRD_Call_Log.xlsx here; its original contents and every original row are preserved. Use only this input folder as the screening exercise so original and expanded files are not accidentally imported twice.
- reviewer: every added person, ID crosswalk, source provenance, source discrepancies, added calls, a reviewer-only scheduling feasibility example, and validation results. This is the answer/review key, not participant input.
- rebuild.py, formula_cache.py and validate_and_package.py: the local generation/verification scripts used for this corrected package. Their paths describe the cloud workspace; they are audit artifacts and not promised standalone setup scripts for another machine.

The previous merged53-person eligibility workbook is not included: it used the older pasted screening decisions and cannot serve as the corrected source of truth. Raw current source list labels are preserved as part of the screening exercise; original149 people have not been silently reclassified by this expansion.

## Counts

| Batch | Original current source | Added synthetic | Expanded |
|---|---:|---:|---:|
| Current MC |100|150|250|
| Prior lists |49|50|99|
| Total applicants |149|200|349|

Prior source list counts are24eligibility,3wait,11followup and11ineligibility. With additions, raw prior-list counts become58eligibility,13wait,15followup and13ineligibility. Initial raw list placement is not a final screening conclusion; some call updates intentionally change it.

There are47call entries:26original and21added. Call-only inquiries remain calls, not invented MC applications. Calls referring to Marcus Hill and Henry Brown lack matching applicant rows in this source set and are flagged, without inventing their demographics from older files. The original unassigned medication cell in eligibility row26 is preserved and flagged; it is not counted as an applicant.

## Added people and requested challenges

The150current-MC additions now use IDs mc-0121 through mc-0270. Forty earlier synthetic IDs would have collided with this source's mc-0081 through mc-0120; the entire synthetic MC block was rekeyed. The reviewer inventory records every old/new synthetic ID. All100source MC records retain their original IDs and fields.

The50prior additions retain IDs mc1001 through mc1050. Among all200additions, expected reviewed outcomes are136eligible,32wait,22followup and10ineligible. Most new MC applicants are eligible (104of150); most additions to the prior eligibility sheet remain eligible after calls (32of34).

Requested examples:

- mc-0124: Mirena in current MC; no corresponding IUD/Mirena challenge added to previous-MC lists or calls.
- mc-0251: Spanish-only answer with passing English-only MC, confined to current MC.
- mc1046: caller knows device is an ICD but cannot recall original implantation date; battery change date does not establish initial date.
- mc1045: caller does not know lamotrigine indication.
- mc1033: caller reports colchicine for heart failure; verify actual indication rather than automatically diagnosing gout or treating every cardiac use as erroneous.
- mc1049: ineligible pacemaker applicant requests avoiding2027-12-08; this does not restore eligibility.
- mc1034: birthday call DOB1962-11-03 differs from eligibility-sheet DOB1954-04-12; a stale tentative MRI date2027-11-03 is deliberately retained for review. Reconcile identity/DOB, preserve both source statements and do not book on the requested birthday.

The32added waits comprise22reaching age60 during recruitment and10with planned external-frame removal within recruitment. They are not travel-only holds or routine dental/breast-marker exceptions. Two synthetic birthdates were moved by one day to avoid duplicate dates in the current source; no source person's DOB changed, and wait birthdays remain correct.

## Revised MRI scheduling rules

The new NIS manual adds research scanning Monday-Thursday, with a Saturday exception limited to ONE participant per study, within8AM-3PM. The ADRD team works Monday-Wednesday,Friday,Saturday. Applying both yields:

- Monday,Tuesday,Wednesday: maximum3participants/day.
- Saturday: maximum1participant/day.
- No Friday research scans, no Thursday ADRD staffing, no Sunday scans.

New availability notes and the reviewer feasibility example use that intersection. Existing source availability is retained verbatim even where it creates a conflict; a scheduler must reconcile it rather than rewriting patient answers.

The MRI phase remains2027-10-31 through2028-11-01. The example accommodates152new eligible-or-wait cases after their wait factors resolve, using alternate dates and Saturday capacity1. Sixteen otherwise-eligible additions have no availability until after the first phase and require a documented scheduling hold; no next-phase start date is invented. The example is for additions only: it does not reserve capacity for the original149people or claim the full349-person queue has been scheduled. No appointments were booked, no participants contacted, and scan durations/times must be confirmed within8AM-3PM.

## Validation and limitations

Every original cell value and all381original formulas are retained; their displayed cached values are also restored. Original files are archived without modification. No source applicant was removed. Workbook headings, richer histories, availability notes, orphan cells and incomplete fields were preserved. Added medications remain names only; patient descriptions do not contain classifier jargon such as temporary/permanent or with metal components. Repeated no/n/a values and genuine overlapping availability dates are intentional; full clinical histories were not copied as blocks.

Recruitment end remains assumed2027-10-30 because the last year digit in the study PDF is unreadable. Confirm the protocol date before making date-dependent final decisions. External official medication reference retrieval was blocked in this session, so new scenarios must not be described as independently label-verified. The review folder retains the source-verification limitation and official references to check.
