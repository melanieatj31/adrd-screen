# ADRD clinical-sheet completion — version 3

This package fixes the incomplete supporting sheets in the user's latest eight uploaded workbooks. The information was confirmed synthetic by the user. It supersedes the previous downloaded package.

## What was fixed

The previous files had diagnoses, medications and surgery_history records for the 50 added prior-list applicants only. They did not contain supporting records for the 49 original prior-list applicants. This version fills those gaps from the clinical details on each applicant row, preserving each diagnosis/date, medication/start/duration and surgical history/plan association.

Two missing pre-call follow-up entries supplied by the user were restored:

- MC-00H — Marcus Hill (old numeric ID mc009).
- MC-00D — Henry Brown (old numeric ID mc0006).

Peta Nguyen, Sharon Bell and Beatrice James already existed under current alphanumeric IDs. Their rows and richer current clinical details were retained; old numeric IDs were recorded as aliases, not duplicate applicants. The review folder includes the exact supplied table, identity crosswalk and any differences retained from the current workbook.

All supporting sheets are grouped in applicant-sheet order, and the applicant ID sets match exactly. No existing applicant was removed or moved between lists. This is clinical-sheet synchronization and baseline restoration, not a fresh eligibility adjudication.

## Coverage

| Workbook | Applicant rows | IDs in diagnoses | IDs in medications | IDs in surgery_history |
|---|---:|---:|---:|---:|
| Eligibility | 58 | 58 | 58 | 58 |
| Ineligibility | 13 | 13 | 13 | 13 |
| Followup | 17 | 17 | 17 | 17 |
| Wait | 13 | 13 | 13 | 13 |
| Total prior-list applicants | 101 | 101 | 101 | 101 |

The unchanged current-MC exports retain 250 applicants. Total source applicants in the package: 351, comprising the previous 349 plus the two restored baseline records. All original applicant rows and all existing supporting records remain present. The update adds 351 missing supporting records across the 12 clinical tabs; this record count happens to equal the applicant total, but they are different measures.

## Unknown details and call information

The supplied baseline entries for Marcus and Henry do not provide complete clinical histories. Missing diagnoses, medication details and dates were marked `not supplied`, not converted into `none`, `no disease`, or invented diagnoses. Tamsulosin is present for Henry because it is explicitly named in his supplied baseline note. Marcus's cardiac-device procedure and its date come from his supplied baseline entry.

Nine supporting-field values are explicitly unknown, all in those two restored baseline histories. Their details are listed in reviewer/EXPLICIT_UNKNOWNS.csv. A row marked `not supplied` establishes coverage and preserves missingness; it is not a complete medical history or a negative screening response.

Call updates remain in the unchanged call log so the screening exercise can reconcile them against baseline records. Marcus's call confirms a pacemaker, which establishes NIS ineligibility when applied. Henry's call resolves tamsulosin as treatment for BPH and names Cataflam for recorded osteoarthritis; Elaine's own dementia/diabetes disclosure in that call belongs to her record. Call-confirmed diagnoses were not silently backfilled into pre-call baseline histories, which would erase the discrepancies being screened.

Lyle Preston is retained unchanged in the current MC demographics and call log, including the conflicting DOB statements. His application was not replaced by the older same-ID identity from earlier inputs.

The original current-MC medication export has no rows for mc-0063. That genuine source gap is preserved, rather than filled with a fabricated negative medication history.

## Package folders

- inputs: four corrected study-list workbooks, the unchanged call log and MC exports, and the current two study manuals. Use this folder for the screening exercise.
- original_sources: exact, unmodified copies of the eight workbooks supplied for this correction and the two manuals retained from the latest source set. Do not import these alongside inputs, because they are source snapshots of the same people.
- reviewer: coverage table, restoration audit, ID aliases, row-level population provenance, explicit unknowns, validation, updated locations of the original 200 synthetic additions and their reviewer-only scheduling example.
- complete_supporting_sheets.py and verify_and_report.py: audit scripts used in the cloud workspace. The provided files are ready to open in Excel; no script needs to be run to use them.

## Preservation and validation

- Every original applicant cell is unchanged; only Marcus and Henry were appended to the follow-up applicant sheet.
- Every pre-existing supporting record is retained. Supporting tabs are now grouped by the applicant-sheet sequence.
- Multiline clinical histories are split into separate records with dates and medication durations aligned by source position. Reported numeric durations in years are represented numerically; source text and provenance remain in original_sources and the population audit.
- Every supporting sheet has exactly the same set of IDs as its applicant sheet, without extra people or new identical record duplicates.
- All unedited MC exports and the call log are byte-identical to the latest uploads, including all 381 original clinical formulas and their cached values.
- 136 validation checks passed. The validation report and Excel review workbook are in reviewer.

## Existing study and scheduling limitations

The recruitment end is still assumed to be October 30, 2027 because the final year digit in the study manual is unreadable. The revised NIS manual and ADRD staffing together allow research scanning Monday-Wednesday at no more than three per day, plus Saturday at one study participant; scan times must fit within 8AM-3PM. The retained reviewer scheduling example covers additions only and is not an actual appointment schedule or proof of capacity for the entire source queue. No participants were contacted and no appointments booked.

External official medication-reference retrieval remained blocked in the earlier task, so the synthetic clinical scenarios must not be described as independently label-verified. The previously provided references-to-check file is retained. This correction adds no invented diagnoses, medicines, dates or safety clearances.
