# harder adrd screening and two-visit scheduling exercise — version 4

## use the correct files

`inputs` contains the eight exercise spreadsheets and the two latest manuals. Give a model ONLY those ten files, together with your task prompt. Do not include `reviewer`, this author README, the case key or the source archive in the model's input.

`reviewer` contains the audit workbook, constructed-case expectations, spouse-request crosswalk, example shared dates, tentative-date review, roster, original-upload reference archive and validation results. The key covers the constructed cases and audited source issues; it is not a claim that all352people have been independently adjudicated.

All participant information is synthetic, as confirmed by the user. No person was contacted and no appointment was booked. Initial study-list labels and proposed dates are exercise inputs, not final clinical clearance.

## latest corrected manual applied

The last supplied study manual supersedes the earlier visit1 ambiguity and one-year interval:

- enrollment: january1,2027 through october30,2027.
- non-mri/visit1 data collection: january1,2027 through august1,2028.
- visit1: weekdays only, at most two people per day. Weekend-only availability is flagged to contact the pi; no approval is invented.
- mri phase: october31,2027 through november1,2028.
- mri must be strictly LESS THAN THREE CALENDAR MONTHS after visit1. This is not an approximate90-day or one-year rule.
- combining the adrd staffing days with nis research availability permits routine mri monday/tuesday/wednesday and saturday; saturday is limited to one participant per study. Exact times still need confirmation within facility hours.

The ordinary visit1 proposals are mostly august/september2027. Irma's source holiday requires a later first visit; the corrected manual permits her december2027 visit1, followed by mri within three months. Do not confuse enrollment end with the later data-collection end.

## roster and clinical-sheet integrity

There are352unique applicants:250current-mc plus102prior-list people. The prior-list workbooks contain59eligibility,13ineligibility,17followup and13wait applicants. One extra identical supplied row for yosef salazar(mc1046) was removed; the person and all linked histories remain. One new otherwise-eligible person, inez montrose(mc1051), was added for the thursday scheduling case.

Every prior-list applicant is represented on diagnoses, medications and surgery_history, with literal matching lowercase IDs and aligned dates/durations. Marcus and Henry, and Lyle in the current mc export, remain present. Genuine missing/uncollected fields remain blank rather than having medical facts invented. Source blanks are listed in the review report. The known mc-0063 missing medication rows remain a source-data challenge.

All exercise spreadsheet text, including IDs, is lowercase. Formula expressions retain their original definitions/cached results; displayed data are unchanged. Availability headings are `visit_availability_notes` everywhere in exercise workbooks. Only eligibility has `visit1_tentative_date` and `mri_tentative_date`. Other lists have no tentative-date column.

Free-text device descriptions are concise. No patient response spells out temporary/permanent/metal-components/type-uncertainty classifications. The iud entry is simply `iud`; actual unspecified device information must be recognized by the screener. Birthday availability requests use month/day without a year; actual DOB fields retain full dates for identity/age screening.

## constructed cases to inspect

| id | case |
|---|---|
| mc1008 | conrad whitfield: hydrocodone/acetaminophen plus xanax, with additional psychiatric/general diagnoses and medications; reports that he and his wife withdraw; later personally asks to rejoin |
| mc1007 | corinne fairchild: wife remains on the eligibility input list; her own later inquiry is13call-log rows below the husband's statement; she later asks to coordinate both visits |
| mc-0262 | ad=yes, medical history=none, medications=none, completed mc score92 |
| mc-0261 | spinal cord stimulator in mc only; no planned future surgery provides a classification hint; unrelated prior cheek-filler history retained |
| mc-0099 | `iud` with no type supplied; no added sentence announces missing type |
| mc-00ap | initial hip date2026-12-06 is two days before screening; callback reads the same day/month in1996 from discharge papers; baseline note has no stale third date |
| mc1011 | jan8: no procedure booked; jan20: hip replacement booked for march16; feb4: cancellation confirmed by surgical office. Eligibility changes must use dated evidence |
| mc1051 | new otherwise-eligible inez montrose: valid thursday visit1 and deliberately invalid thursday mri under adrd staffing |
| mc1005 | visit1 proposed on august20 despite an explicit yearless birthday prohibition |
| mc1049 / mc-00am | ineligible saturday/sunday visit1 requests in availability notes only; the final three applicant rows are mc1049,mc1050,mc-00am, so exactly one person separates them |

The drug case includes bipolar depression, anxiety, ptsd, insomnia, hypertension, diabetes and addiction/smoking history. Drug names alone are in medication cells. Lamotrigine and unrelated original psoriasis treatment are retained; bupropion is not presented as established opioid-addiction treatment. The opioid/benzodiazepine risk requires clinical review. Renewed willingness does not itself clear that risk.

A spouse's reported withdrawal is not automatically the other competent adult's own withdrawal. The wife's later personal statement must be considered separately. The revised manual's withdrawal/decline handling belongs to the model's screened outputs; final csv files cannot store row fills, so a color-based grading requirement needs an xlsx companion or an explicit decline/status field.

## seven joint-visit requests

Seven distinct callers ask to attend together with existing applicant spouses for BOTH visit1 and visit2. No new query-only applicant IDs were created, and each request is recorded only under the caller. Fourteen existing people are linked:

| caller | partner |
|---|---|
| mc1007 corinne fairchild | mc1008 conrad whitfield |
| mc1001 zelda delaney | mc1002 zachary underwood |
| mc1004 ambrose espinosa | mc1003 anita macias |
| mc1010 dominic galloway | mc1009 delphine ortega |
| mc1011 eunice yamamoto | mc1014 francisco zimmerman |
| mc1013 florence hawthorne | mc1016 gilbert ibarra |
| mc1017 helene aguirre | mc1018 hugo serrano |

One pair's initial dates already match, providing a positive control. Other stale individual proposals need coordination. A joint visit1 consumes both daily slots. A joint saturday mri for two people would violate nis's one-person saturday limit. The drug-review and pi-accommodation pairs cannot be automatically booked together. The reviewer pack provides conditional shared-date examples for the other five pairs, not mandatory exact answers or actual bookings. Any same-day combined visit1/mri arrangement requires confirmation of durations and times; the manual does not specify those.

## availability variation

The notes vary in vocabulary and date format, are primarily hard exclusions, and avoid repeating fallback offers. School teachers, lesson teachers, toddler-grandchild carers and weekday workers occur no more than twice per input list, with dispersed and different wording. Weekend-only notes flag the pi. Original clinically relevant call disclosures are retained alongside concise rewritten scheduling callbacks.

## scheduling defects versus source review

Two new otherwise-eligible date defects are deliberate: mc1051's thursday mri and mc1005's birthday visit1. The two ineligible weekend entries are requests, not booked appointments. Other people may need their proposals cancelled or held when the screener applies existing call disclosures, clinical risks or withdrawal statements. The source call restrictions about travel, later surgery, uncertain return and bereavement have their own review-key entries and are not silently treated as confirmed availability.

Eight eligibility rows carry concise holds/pi/contact notes rather than invented dates. Concrete proposals obey the revised period, capacity and strict three-calendar-month interval, apart from the two designated date tests. Proposed dates are not final appointments or a claim of eligibility.

## review and limitations

482validation checks passed, including roster preservation, all supporting-ID sets, lowercase/concise fields, role caps, case chronology, caller linking, both visit windows, strict calendar-month interval, daily capacities, the exact intended defects, all seven spouse links and preservation of381original mc formula definitions/cached results.

The previous external official-drug-reference retrieval was blocked by network policy. Clinical examples are synthetic training cases, not prescribing recommendations or independently label-verified regimens. A completed mc score is not a diagnosis. Medical/MRI clearance remains a clinical decision in any real study.
