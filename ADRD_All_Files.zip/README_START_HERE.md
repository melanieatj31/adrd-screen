# ADRD synthetic challenge package — version 5

All people and clinical details in this package are synthetic. This version starts from the eight workbooks most recently uploaded for the version-5 request and retains the latest corrected study manual and NIS manual.

Use only `inputs/` when running the screening task. It contains eight Excel workbooks and two PDF manuals. The study lists contain initial screening states, not final adjudications. Calls can correct or supersede earlier information. Tentative dates require review. Read the actual manuals for criteria; the corrected manual distinguishes enrollment ending October 30, 2027 from non-MRI data collection ending August 1, 2028.

There are 369 unique applicant IDs: 253 MC applicants and 116 prior-list applicants (68 initially eligible, 14 initially ineligible, 20 initially on followup, 14 initially waiting). All 352 source applicants are retained. Seventeen people were added, including eight straightforward eligible applicants arranged in two short runs. There are 83 call entries. Inquiry-only source calls remain inquiries, without invented applications.

The added cases cover a prescription never started; a historical six-year phenelzine course followed by sertraline after a 19-day gap; reading a spouse's device card; an unresolved ICD implantation date; a breast-marker clarification that leaves a dated pacemaker exclusion; cancelling only one of two hip operations; cancelling recent fingerplate removal; two distant August 1/November 2 requests; and two distinct Lesley Houston records sharing a name and date of birth. Use applicant IDs and other identity evidence rather than merging by name and DOB.

The three constrained spouse pairs are dispersed through the eligible workbook and call log. Their raw tentative dates are left as `n/a`, so the model must derive the joint solution from the requests. Other tentative appointments leave room for that solution. Two other clear spouse pairs have shared provisional dates. Two remaining couples need clinical review or PI accommodation. The earlier withdrawal/re-entry, birthday, Thursday-MRI, ineligible weekend-request, score, AD, device, and chronology cases remain.

The human-entered source text is lowercase, brief, and varied. Clinical supporting sheets cover every applicant in each of the four study lists. Genuine original missing information remains missing, including the original MC medication gap for `mc-0063`. The new ICD case deliberately omits its implantation date. All 381 original MC medication formulas and cached results are preserved.

For the author, `reviewer/challenge_review.xlsx` combines the case key, added-person list, identity audit, source changes, clinical coverage, scheduling review, capacity witness, and 939 passing validation checks. `reviewer/new_applicants.csv` lists every added ID. The reviewer material contains answers: do not include it in the model's input. The key addresses constructed cases and does not replace a full manual-based screening of all source applicants.

`reviewer/original_uploads_reference_only.zip` contains the unedited source workbooks and manuals for comparison. Those files are an archive, not the current challenge inputs. Reproduction scripts are in `reviewer/build_files/`; their source paths refer to the originating workspace and must be adjusted if rebuilding elsewhere.

The input-only ZIP contains exactly the ten files in `inputs/`, with no answer key. The full ZIP contains the inputs, this README, and reviewer material.
