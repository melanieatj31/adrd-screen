# ADRD MC51 — enriched medical histories, version2

The uploaded medical/surgical history workbook is the source for this revision. The other two input workbooks remain byte-for-byte identical to the completed51-person batch. Participant IDs, recruitment order, campaign codes, demographic details, baseline scores, MRI answers and all metal/eye responses are unchanged.

Added119 varied diagnosis/history entries across50 profiles and6 medication entries. Not every older person needs multiple diagnoses; these are deliberately enriched synthetic benchmark profiles. The one deliberately negative history remains intact:0035e00000vLPfoAAG reports AD but no diagnoses/medicines. This exception preserves its original followup challenge.

Eight recorded-female profiles have9 added historical C-section entries with varied dates and wording. Names remain blank as provided; sex and plausible age at the procedure were used rather than assumed from names. These entries do not report any retained implant or new procedure plan.

The existing followup applicant0035e00000xG5ZpAAK has documented hypertension, type2 diabetes and hyperlipidemia plus warfarin, carvedilol, hctz and metformin. Their anticoagulation indication is not documented. Do not infer AF from warfarin: clarify AF, prior thromboembolism, valve history or another indication. Their original unresolved MRI-ability answer remains unchanged. The other existing diagnoses and medicines are retained.

All51 intended screening outcomes remain29 eligible,12 followup,6 ineligible and4 wait. Added conditions are not new protocol exclusions; the existing clinical concerns and exceptions remain. Eligible additions were selected to avoid introducing new protocol exclusions or additional medication-safety concerns. Drug-interaction cases retain their original medicines; added untreated/remote conditions do not imply that any particular drug must be prescribed.

Use the three files in inputs/ for the model; keep reviewer/ separate. The review workbook includes every addition, before/after diagnosis counts and validation results. Registration dates are not screening dates. Newly added medication durations were calculated from their clinical screening dates.

350 consistency checks passed. No new model-performance score is claimed.
