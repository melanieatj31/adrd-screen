# ADRD — 51 current MC applicants and20 prior-list applicants

This version implements the requested reduction to exactly20 distinct people across the four prior-batch study lists:8 eligible,7 followup,3 waiting and2 ineligible. The51-person current MC batch is separate. There are71 distinct applicants in the combined model task.

The prior identities are20 exact IDs/first_name/last_name values selected from help.xlsx. The67 unused IDs are not applications in this package. No identity was fabricated. The duplicate ICD source row was removed without removing that person. Clinical sex/DOB and case profiles are retained from the selected synthetic source profiles; first/last names come from the user's identity sheet. Current MC first/last names remain blank as supplied.

All clinical tabs are keyed by participant_id with exact identifier capitalization. The clinical summaries are populated from their structured diagnoses, medications and surgical-history rows. All original selected clinical details are retained except deliberate scenario adjustments described below. Unknown ICD dates and genuine source missing fields remain unknown, not invented. Only eligibility has tentative-date columns. Availability is named visit_availability_notes throughout.

All created_date_participant values are before2026-11-16. Prior registration dates use the original month/day and time with year2026. The51 MC registrations use their original month/day shifted back6days in2026, so the final record is2026-11-15; original times and UTC offsets are preserved. Screening, assessment, diagnosis and procedure dates are separate clinical fields. Campaign codes are unchanged.

The call log contains26 entries,8 of them inquiry-only entries. Inquiry-only callers do not receive participant IDs. A nonparticipant wife supplies collateral MRI-panic information about an existing applicant; this requires followup, not an inferred personal withdrawal. Her name is not the applicant's name and her ID remains n/a. Several calls concern an additional family member identified in the narrative; don't attribute their medical history to the primary caller.

Requested challenges:
- John Irving personally withdraws and reports that his wife Arleen Abreu also wants to withdraw. She supplies no later own callback. His own decline applies to him; his report alone does not withdraw her.
- Elizabeth Thomas clarifies hypothyroidism diagnosed2020 but reports levothyroxine beginning2012. The indication is partly resolved, while the earlier treatment history still requires verification.
- Ronald Pereira first reads a pacemaker card and later says it was his wife's. His own device is an ICD; the original implantation date remains missing. The battery-replacement date is not treated as original implantation.
- Tatiana Kvak has a fingerplate placed2026-11-04. On2027-01-04, exactly2calendar months later, she says she has decided to leave it in and declines removal. This is an affirmative retention decision, rather than a cancelled appointment with no explanation. The recent-implant exclusion applies on the available facts; a later documented change could justify re-screening.
- Raymond Place says frame removal has moved from2027-02-23 to2027-05-11. The wait-list researcher note says recontact2027-05-12. The original structured date is retained as baseline evidence for reconciliation.

Other cases include a sister's own withdrawal versus her request to remove her brother; own MRI decline after explanation; a nonparticipant wife's report of an interrupted MRI; clarification of medication indications; AD confirmed on a callback; a verified hip implant-year correction; verified non-AD Parkinson disease; documented complete hardware removal; and a coordinator-verified repeat MC score after an assessment error.

To make the wait examples internally consistent, Raymond's frame placement is2026-11-21 and Richard Toledo's is2026-11-20, both after the fixed initial-screening cutoff. Their fracture and related date fields agree. Tatiana's previous lower-leg-frame template has been replaced with the finger-fracture/plate history; the insertion, fracture and analgesic dates are aligned. The original full source pool is not a required coverage set after this explicit reduction to20.

The four input study lists are starting states. They are not already reconciled final answers. The model should apply dated callbacks and move people where indicated. After those callbacks, the reviewer key expects10 prior eligible,4 followup,5 ineligible and1 wait:14/20 are eligible or followup. Later callbacks do not by themselves establish that unrelated participants' planned procedures occurred. Use documented facts and applicant-specific re-screen actions.

The full model-input ZIP contains11 files:3 current-MC workbooks,4 prior study-list workbooks,1 call log,1 prior identity register and2 manuals. The prior identity register repeats the same20 identities and does not add applicants. Replace older versions; do not combine this reduced source set with the old larger study lists or current-MC exports.

For reviewers only: prior20_case_key.csv and ADRD_Prior20_Review.xlsx contain the identity crosswalk, expected outcomes and supporting reasons; current_mc51/ contains the preserved current-batch case key. Do not give the model this README or reviewer/ files. Source_missing_fields.csv distinguishes genuine missing data. No calls or bookings were made.

725 consistency checks passed.
