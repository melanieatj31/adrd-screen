# ADRD current MC batch — 51 participants

This package replaces only the three current-batch MC input workbooks. Existing prior-batch lists, the call log and manuals are not revised in this package.

The participant IDs, first_name/last_name fields, original registration timestamps and campaign codes come from the supplied recruitment export plus the two final IDs/timestamps supplied in chat. IDs retain exact capitalization. Campaign strings, including percent encoding, remain unchanged; uncollected campaigns and names remain blank. No names were invented.

Clinical and demographic screening profiles are synthetic selections from the earlier expanded MC dataset. The originally blank race column is populated from each selected synthetic profile. The original six headings remain first in the recruitment workbook; clinical demographic fields follow them. The former name field is replaced by first_name and last_name, race_ethnicity is represented by race, and all current-batch joins use participant_id rather than applicant_id. The title row was removed so the column headings occupy row 1. Source row order is unchanged, with the two extra identities appended.

created_date_participant records registration in2022. It is not the clinical screening date. Use screening_date_yyyy_mm_dd and the study manual's recruitment boundaries for age and timing decisions. No medical dates were shifted to2022.

The selected profiles contain29 otherwise-eligible,12 followup,6 ineligible and4 wait-list cases. Positions1–5,21–25 and40–44 are eligible stretches; remaining cases are dispersed. Positions50–51 are two further eligible controls. These expected classifications assume the supplied manual and the available current-batch evidence; reassess if new individual evidence is added.

For the model, use only the three files in inputs/, alongside your study manuals and separately maintained prior-batch materials. Update the task wording to name miami_recruitment_list_export-4.xlsx as the current demographic source and participant_id as its join key. Do not supply the reviewer folder or this author README as model inputs. The reviewer workbook maps new IDs to old case profiles and explains the intended classifications.

The model-input ZIP contains exactly three XLSX files and no answer key. The author ZIP includes those inputs plus the reviewer workbook, detailed validation and case crosswalk. The original49-record upload is retained locally for provenance, not mixed with the replacement inputs.

Completed checks: 367 passed. They verify51 unique identities, joins on all clinical/assessment tabs, exact transfer of selected source clinical records, original registration fields/campaigns in the builder, eligibility-run positions and the additional IDs/timestamps. Clinical formula results are transferred as stored values to avoid stale references after subsetting and remapping. No score against Astra has been measured for this smaller batch.
